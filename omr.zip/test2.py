# @bot.on_message(filters.command("compress"))



import glob

from PIL import Image

import os



all_files = []



def comp(dir = ""):

    if not dir.endswith("/"):

        dir = dir + "/"



    uncomp_fold = f"{dir}uncomp_files/"

    os.system(f"mkdir -p {uncomp_fold}")

    dir += "eval_files/"

    os.system(f"cp -f {dir}*.jpg {uncomp_fold}")



    # for files in glob.glob(uncomp_fold + '*.jpg'):

    #     all_files.append(files)

    all_files = os.listdir(uncomp_fold)



    for file in all_files:

        compress_image(uncomp_fold + file, dir + file)









def compress_image(input_path, output_path, target_size_kb = 90):

    quality = 95  # Start with high quality

    while quality > 0:

        with Image.open(input_path) as img:

            img.save(output_path, 'JPEG', quality=quality)

        if os.path.getsize(output_path) <= target_size_kb * 1024:

            break

        quality -= 5



comp("class-10/class-10_english_3")


