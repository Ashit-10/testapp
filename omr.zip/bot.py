import os
from pyrogram import *
from pyrogram.types import *
import datetime
from random import randint as rain
import pytz
from apscheduler.schedulers.background import BackgroundScheduler
import glob
from PIL import Image
import cv2
import json
import requests



tz = pytz.timezone("Asia/kolkata")
sj = BackgroundScheduler(timezone="Asia/kolkata")
from omr_utils import *
import omr_utils2

git_token = "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"
year = 2024



import base64
bot_token = '6530315910:AAEAQ_v672zLnw_6LwAsPPVxmiPmuznbVoI'
api_id = '6810439'
api_hash = '66ac3b67cce1771ce129819a42efe02e'

tz = pytz.timezone("Asia/kolkata")
import os.path

bot = Client(
    'pyro-boiit',
    bot_token=bot_token,
    api_id=int(api_id),
    api_hash=api_hash
)
api_id2 = 2613713
api_hash2 = "f615f10d7410ce9ba757f211cf1fb84b"

bot2 = Client(
    "redirect_bot_for_omr",
    api_id=api_id2,
    api_hash=api_hash2
)

from convopyro import Conversation, listen_message

Conversation(bot)


sep = "/"
Owner = 1602293216
group_id = -1001774957665
iron_man = 1848113090
ADMINS = [1602293216, 1845525834, 809293242, 19371046] #, 740538095]

@bot.on_message(filters.command(["hi"]))
def js(c, m):
   m.reply_text("hello")


@bot2.on_message(filters.command(["d"]))
async def down(client, message):
        try:  
            with open("default_folder.txt", "r") as rd:
                fol_told = rd.read().strip()
            roll = message.text.split()[1].split("_")[0]
            cls = fol_told.split("_")[0]
            name = f"{cls}/{fol_told}/eval_files/" + (message.text.split()[1]).strip() + ".jpg"
            os.system(f"rm {cls}/{fol_told}/eval_files/{roll}_*")
            await message.reply_to_message.download(name)
            await message.reply_text("Done !")
        except Exception as cd:
            await message.reply_text(str(cd))

from github import Github



@bot.on_message(filters.command("git"))
async def git_(c,m):
    if len(m.text) > 10:
        aa = await m.reply_text("Processing ...")
        fol_told = m.text.split()[1].lower()
        class_name = fol_told.split("_")[0]

        g=Github(git_token)
        repo=g.get_repo("Ashit-10/omr_exams")
        message = "Update files"
        branch = "main"

        try:
            for file in os.listdir(f"{class_name}/{fol_told}/eval_files"):
                file_path = f"{class_name}/{fol_told}/eval_files/{file}"
                image_data = None
                with open(file_path, "rb") as image:
                    f = image.read()
                    image_data = bytearray(f)
                if image_data:
                    repo.create_file(file_path, message, bytes(image_data), branch)
            await aa.edit(f"Successfully uploaded {fol_told}")        
        except Exception as e:
            await aa.edit(str(e))

import os

html_str = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Answer sheet</title>
</head>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<body>


"""

@bot.on_message(filters.command(["html", "upload"]))
async def up_html(c, m):
        # aa = await c.send_message(m.chat.id, "Making ...")
        # fol_told = m.text.split()[1].lower()
        with open("default_folder.txt", "r") as rd:
            fol_told = rd.read().strip()
        global year
        await m.reply_text(f"Do you like to upload all files under {fol_told} ?\nChoose your tutorial :", reply_markup=InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = "MVM",
            callback_data= f"year_MVM/{year}_{fol_told}"
        ),
        InlineKeyboardButton(
            text = "WSC",
            callback_data= f"year_WSC/{year}_{fol_told}"
        )
    ],
    [
        InlineKeyboardButton(
            text = "cancel",
            callback_data= f"cancel"
        )
    ]
]))
            


async def up_files_to_git(c, m, year, fol_told):
    # with open("default_folder.txt", "r") as rd:
    #     fol_told = rd.read().strip()

   
    print("fol told", fol_told)
    main_fold = fol_told.split("_")[0]

    pdf_location = main_fold + "/" + fol_told +"/" + fol_told + "_question.pdf"
    pdf_location_file = fol_told +"/" + fol_told + "_question.pdf"

    g=Github(git_token)
    repo=g.get_repo("Ashit-10/omr_exams")
    message = "new page"
    branch = "main"
    file_path = f"{fol_told}.html"
    image_data = None
    with open(file_path, "rb") as image:
        f = image.read()
        image_data = bytearray(f)
    if image_data:
        repo.create_file(f"{year}/{main_fold}/{file_path}", message, bytes(image_data), branch)
        await m.edit("Successfully build the page and updated in github.")
        os.remove(file_path)

    fcc_msg = f"All files under {fol_told} are being uploaded ..."
    cc = await c.send_message(m.chat.id, fcc_msg)
    try:
        file_paths = []
        f_no = 1
        for file in os.listdir(f"{main_fold}/{fol_told}/eval_files"):
            file_paths.append(f"{main_fold}/{fol_told}/eval_files/{file}")
            file_paths.sort()
        total_files = len(file_paths)
        print(file_paths)
        
        for file_path in file_paths:
            image_data = None
            with open(file_path, "rb") as image:
                f = image.read()
                image_data = bytearray(f)
            if image_data:
                try: 
                    repo.create_file(f"{year}/{file_path}", message, bytes(image_data), branch)
                except Exception as e:
                    print(e)
                f_no += 1
            if not (f_no % 5):
                fcc_msg += f"\nUploading **{f_no}/{total_files}"
                await cc.edit(fcc_msg)
        file_path = f"{main_fold}/{fol_told}/{fol_told}_ans_key.txt"
        link_path = f"{main_fold}/{fol_told}"
        
        with open(file_path, "rb") as image:
                f = image.read()
                image_data = bytearray(f)
        if image_data:
                try:
                    repo.create_file(f"{year}/{file_path}", message, bytes(image_data), branch)
                except Exception as e:
                    try:
                        cont = repo.get_contents(f"{year}/{file_path}")
                        repo.delete_file(f"{year}/{file_path}", "delete", cont.sha, branch)
                        repo.create_file(f"{year}/{file_path}", message, bytes(image_data), branch)

                    except Exception as e:
                        print(e)

        try:
            with open(pdf_location, "rb") as image:
                    f = image.read()
                    image_data = bytearray(f)
            if image_data:
                    try:
                        repo.create_file(f"{year}/{pdf_location}", message, bytes(image_data), branch)
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)
        await cc.edit(f"Successfully uploaded {fol_told} , {total_files} files.\nashit.xyz/{year}/{link_path}\n\nThe link will activate in 5 minutes.")        

    except Exception as e:
        await cc.edit(str(e))


@bot.on_message(filters.command(["up"]))
async def upp(client, message):
    if message.from_user.id == Owner:
         
        try:
            await client.send_document(chat_id=message.chat.id, document=str(message.text.split(' ', 1)[1]))
            await message.reply_text("Done !")
        except Exception as e:
            await message.reply_text(str(e))
            

class_9_students = 35  # Total loop time for asking omr sheets

 
@bot.on_message(filters.command("set") & filters.user(ADMINS))
async def set_deefault_folder(c, m):
    if len(m.text) > 8:
        fold = m.text.lower().split()[1]
        with open("default_folder.txt", "w+") as ri:
                ri.write(str(fold))
        await m.reply_text(f"Successfully set the default path to `{fold}`")
    elif len(m.text) > 5 and m.text.lower().split()[1] == "0":
        os.remove("default_folder.txt")
        await m.reply_text(f"Successfully deleted the default path.")
    else:
        btnss = []
        for fold in os.scandir("."):
                if fold.is_dir():
                    folder_name=fold.path.split("/")[-1]
                    if folder_name not in ["null", "__pycache__"]:
                        btnss.append([InlineKeyboardButton(
                                text = folder_name,
                                callback_data= f"folder_{folder_name}"
                            )]
                            )
        set_btn1 = InlineKeyboardMarkup(btnss)
        await m.reply_text("Choose from following", reply_markup=set_btn1)



@bot.on_message(filters.command("auto_save") & filters.user(ADMINS))
async def ato(c, m):
    auto_save = "False"
    if os.path.isfile("auto_save.txt"):
        with open("auto_save.txt", "r") as red:
            auto_save = red.read()

    else:
        with open("auto_save.txt", "w+") as red:
            red.write('False')
            auto_save = "False"

    stat1, stat2 = "On", "Off"
    if "True" in str(auto_save):
        stat1 += "✅"
    else:
        stat2 += "✅"

    await m.reply_text(f"Toggle auto_save feature! [{auto_save.strip()}]", reply_markup=InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = stat2,
            callback_data= f"auto_save_off"
        ),
        InlineKeyboardButton(
            text = stat1,
            callback_data= "auto_save_on"
        )
    ],
    [
        InlineKeyboardButton(
            text = "cancel",
            callback_data= f"cancel"
        )
    ]
]))

@bot.on_message(filters.command("year") & filters.user(ADMINS))
async def yea(c, m):
    if " " in m.text:
        yeat = m.text.split(" ")[1]
        with open("default_year.txt", "w+") as wr:
            wr.write(yeat.strip()) 
        await m.reply_text(F"Default Tutorial: {yeat}")
    else:
        await m.reply_text("give folder name.")


@bot.on_callback_query()
async def call(c, m):
    if "year_" in m.data:
        data = m.data.split("_")[1]
        default_folder = m.data.split(f"year_{data}_")[1]
     
        await up_files_to_git(c, m.message, data, default_folder)

    if "auto_save_" in m.data:
        data = m.data
        if "on" in data:
            stat1 = "On ✅"
            stat2 = "Off"
            auto_save = "True"
        elif "off" in data:
            stat1 = "On"
            stat2 = "Off ✅"
            auto_save = "False"

        with open("auto_save.txt", "w+") as red:
            red.write(auto_save)
        await m.message.edit(f"Toggle auto_save feature! [{auto_save}]", reply_markup=InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = stat2,
            callback_data= f"auto_save_off"
        ),
        InlineKeyboardButton(
            text = stat1,
            callback_data= "auto_save_on"
        )
    ],
    [
        InlineKeyboardButton(
            text = "cancel",
            callback_data= f"cancel"
        )
    ]
]))
    if m.data.startswith("folder_"):
        folder_name = m.data.split("_")[1]
        btns = []
        for fold in os.scandir(f"{folder_name}"):
                if fold.is_dir():
                    folder_name2 =fold.path.split("/")[-1]
                    print(folder_name2)
                    btns.append([InlineKeyboardButton(
                            text = folder_name2,
                            callback_data= f"folder2__{folder_name2}"
                        )]
                        )
        set_btn1 = InlineKeyboardMarkup(btns)
        await c.send_message(m.message.chat.id, "Choose from following", reply_markup=set_btn1)
        await m.message.delete()

    if m.data.startswith("folder2_"):
        folder_name = m.data.split("__")[1]
        class_name = folder_name.split("_")[0]
        yes_no_btn = InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = "yes",
            callback_data= f"set__{folder_name}"
        ),
        InlineKeyboardButton(
            text = "No",
            callback_data= "cancel"
        )
    ]
])
        await c.send_message(m.message.chat.id, f"Select `{folder_name}` ?", reply_markup = yes_no_btn)
        await m.message.delete()

    if m.data.startswith("set"):
        folder_name = m.data.split("__")[1]
        with open("default_folder.txt", "w+") as wr:
            wr.write(folder_name)
        await m.message.edit(f"Default folder has been set to : `{folder_name}`")

    if m.data == "update_data_file":
        file_name = m.message.document.file_name
        msg = await m.message.edit(f"Processing ...")
        await m.message.download(file_name)

        g=Github(git_token)
        repo=g.get_repo("Ashit-10/omr_exams")
        message = "Update files"
        branch = "main"

        try:
            file_path = file_name
            print(file_path)
            image_data = None
            with open(file_path, "rb") as image:
                f = image.read()
                image_data = bytearray(f)
            if image_data:
                try:
                    # Check if the file already exists
                    contents = repo.get_contents(f"{file_path}", ref=branch)
                    # If it exists, update the file
                    repo.update_file(contents.path, message, bytes(image_data), contents.sha, branch)
                except Exception as e:
                    # If the file does not exist, create it
                    repo.create_file(f"{file_path}", message, bytes(image_data), branch)

            await msg.edit(f"Successfully updated !")

        except Exception as e:
            await m.message.edit(str(e))



    if m.data == "update_file":
        try:
            file_name = (m.message.caption.split("\n")[1]).strip()
        except:
            file_name = (m.message.text.split("\n")[1]).strip()
       
        global year
        file_name_og = file_name
        fna = file_name.split(str(year))[1]
        file_name = fna[1:]
        print("update file", file_name)
        await m.message.download(file_name)

        g=Github(git_token)
        repo=g.get_repo("Ashit-10/omr_exams")
        message = "Update files"
        branch = "main"

        try:
            file_path = file_name
            print(file_path)
            image_data = None
            with open(file_path, "rb") as image:
                f = image.read()
                image_data = bytearray(f)
      
            if image_data:
                try:
                    # Check if the file already exists
                    contents = repo.get_contents(f"{year}/{file_path}", ref=branch)
                    # If it exists, update the file
                    repo.update_file(contents.path, message, bytes(image_data), contents.sha, branch)
                except Exception as e:
                    # If the file does not exist, create it
                    repo.create_file(f"{file_name_og}", message, bytes(image_data), branch)
            await m.message.edit(f"Successfully uploaded `{file_name}` to GitHub.")

        except Exception as e:
            await m.message.edit(str(e))

        os.system("rm -f null/*")

        folder_name = file_name.split("/")[1]
        with open("default_folder.txt", "r") as dekh:
            default_name = dekh.read()
        if folder_name != default_name:
            await m.message.reply_text(f"Make `{folder_name}` as default folder ?", reply_markup=InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = "No",
            callback_data= "cancel_"
        ),
        InlineKeyboardButton(
            text = "yes",
            callback_data= f"default_{folder_name}"
        ) 
    ]
])) 
        return

    if m.data.startswith("default_"):
        folder_name = m.data.split("default_", 1)[1]
        try:
            with open("default_folder.txt", "w+") as wr:
                wr.write(folder_name)
            await m.message.edit(f"Default folder set successfully: `{folder_name}`\nPlease change the settings if needed: ashit.xyz/select.html?exam_folder={folder_name}")
            await m.message.pin()
        except Exception as e:
            await m.message.edit(str(e))

    if m.data == "save_photo":
         file_name = m.message.text
         actual_file_name = file_name.rsplit("/")[-1]

         fold = file_name.split("/")[1]
         pre_fold = file_name.split("/")[0]
         all_files = os.listdir(f"{pre_fold}{sep}{fold}")

         for file in all_files:
            if actual_file_name.startswith(file.split("_")[0] + "_"):     
        #  if os.path.isfile(file_name):
                await m.message.edit(f"File already available !\nOld file: `{fold}{file}`\nNew file: `{file_name}`\nStill save it ?", reply_markup = InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = "yes",
            callback_data= f"save_file_{file_name}"
        ),
        InlineKeyboardButton(
            text = "No",
            callback_data= "cancel"
        )
    ]
]))
                break
         else:
            await m.message.reply_to_message.download(file_name)
            await m.message.edit(f"Successfully saved to: `{file_name}` ✅")

    if m.data.startswith("save_file"):
        file_name = m.data.split("save_file_")[1]
        og_file_name = file_name
        del_file_name = file_name.replace(file_name.rsplit("_")[-1], "")
        os.system(f"rm {del_file_name}*")
        await m.message.reply_to_message.download(og_file_name)
        await m.message.edit(f"Successfully saved file: `{og_file_name}`")
        return
       
    if m.data.startswith("cancel"):
       await m.message.delete()
       if not "_" in m.data:
            try:
                    await m.message.reply_to_message.delete()
            except:
                pass


@bot.on_message(filters.document & filters.user(ADMINS))
async def docs(c, m):
    chat = m.chat.id
    fol_told=None
    if ".pdf" not in m.document.file_name:
       return
    if os.path.exists("default_folder.txt"):
        with open("default_folder.txt", "r") as re:
            fol_told=re.read()
        class_name = f"{fol_told.split('_')[0]}" 
        file_name = class_name + "/" + fol_told + "/" + fol_told + "_question.pdf"
        with open("default_year.txt", "r") as red:
            year_name = red.read().strip()
        global year
        await c.send_document(chat, document=m.document.file_id, caption=f"Update this as question file with name:\n`{year_name}/{year}/{file_name}`", reply_markup=InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = "cancel",
            callback_data= f"cancel"
        ),
        InlineKeyboardButton(
            text = "update to git",
            callback_data= f"update_file"
        )
    ]
]))

        
    
@bot.on_message(filters.command("compress"))
async def comp_on_off(c, m):
    if " " in m.text:
        on_off = m.text.split()[1].lower().strip()
        if on_off in ["on", "off"]:
            with open("compress.txt", "w+") as wr:
                wr.write(on_off)
            await m.reply_text(f"Compresson: {on_off}")
            return
    await m.reply_text(f"Please give an argument between on or off.")



async def compress_image(input_path, output_path):
    try:
        with open("compress_size.txt", "r") as red:
            target_size_kb = int(red.read().strip())
    except:
        target_size_kb = 150

    quality = 95  # Start with high quality
    same_path = None
    
    if input_path == output_path:
        same_path = output_path
        output_path = "web/x.jpg" 
    os.system(f"rm -f {output_path}")
    while quality > 0:
        print("compressing", quality)
        with Image.open(input_path) as img:
            img.save(output_path, 'JPEG', quality=quality)
        if os.path.getsize(output_path) <= target_size_kb * 1024:
            break
        quality -= 5

    image = cv2.imread(output_path)
    bilateral_filter = cv2.bilateralFilter(image, 9, 75, 75)
    compression_params = [cv2.IMWRITE_JPEG_QUALITY, 50]
    cv2.imwrite(output_path, bilateral_filter, compression_params)

    if same_path:
       os.system(f"mv -f {output_path} {same_path}")
    return 

@bot2.on_message(filters.command("save"))
async def save_photo(c, m):
    print("ok")
    if m.reply_to_message and m.reply_to_message.photo:
        text = m.reply_to_message.caption
        text_list = text.split(" ")
        new_file_name = ""
        text_list.reverse()
        for file_name in text_list:
            if ".jpg" in file_name:
                file1 = (file_name.split(".jpg")[0]).strip()
                new_file_name = file1 + ".jpg"
                print(new_file_name)
                file2 = (file1.replace((file1.rsplit("_")[-1]), "")).strip()
                os.system(f"rm {file2}*")
                break

        cap = text.split("File already")[0].strip()
        
        try:

            await m.reply_to_message.download(new_file_name)
            cap += f"\n\nFile saved: {new_file_name}  ✅"
            try:
                with open("compress.txt", "r") as red:
                    comp_on_off = red.read().strip()
                if comp_on_off == "on":
                    fsize = os.path.getsize(new_file_name) / 1024
                    cap += f"\n[Compresson: ON] {fsize:.2f} kb"
            except:
                pass
        except:
            cap += "\n\nError while saving the file."

        await m.reply_to_message.edit(cap)
        await m.delete()
        # print(m.reply_to_message.caption)



@bot2.on_message(filters.command("coords"))
async def coord(c, m):
    # cap = """[[[62, 132], [56, 56]],[[1173, 137], [56, 56]],[[51, 475], [56, 56]],[[1181, 448], [56, 56]]] Image: [1280,640]"""
    if " " in m.text:
        new_width = 960
        cap = m.text.split(" ",1)[1]
        custom_cods = json.loads(cap.split('Image:')[0])
        img_json = json.loads(cap.split('Image:')[1])
        got_width = img_json[1]
        new_cods = []
        ratio = new_width / got_width
        for cod in custom_cods:
            xx = int(cod[0][0] * ratio)
            yy = int(cod[0][1] * ratio)
            ww = int(cod[1][0] * ratio)
            hh = int(cod[1][1] * ratio)
            new_cods.append([[xx, yy], [ww, hh]])

        await forwarn(c, m.reply_to_message, m, new_cods)



@bot2.on_edited_message(filters.photo & filters.chat(group_id) & filters.user(iron_man))
@bot2.on_message(filters.photo & filters.chat(group_id) & filters.user(iron_man))
async def forwarn(c, m, n = 0,  new_cods = []):
    comp_on = None

    fmsg = await c.send_message(m.chat.id, "processing ...")
    await m.download("./img.png")

    width = m.photo.width
    height = m.photo.height 

    print(width, height)
    with open("default_folder.txt", "r") as red:
        fold = red.read()
    main_fold = fold.split("_")[0]   
    fol_told =  fold.split("_")[1] 
    eval_file = await omr_utils2.read_img(f"img.png",
        f"web/img_out", 
        f"{main_fold}/{fold}/{fold}_ans_key.txt", 
        f"web/", m.caption, width, height, new_cods)
    
    try:
        total_mark = eval_file[4]
        correct = eval_file[2]
        wrong = eval_file[3]
        not_sel = eval_file[5]
        roll = eval_file[7]
        caption = f"""Exam: #{fold}
Roll: {roll}
Total mark: {total_mark}
Correct: **{correct}**
wrong: {wrong}
Not selected: {not_sel}
"""
        error_msg = eval_file[9]
        if error_msg:
            caption += "\n\n" + str(error_msg)
        else:
            file_name = main_fold + "/" + fold + "/eval_files/" + str(roll) + "_" + str(correct) + ".jpg"
            auto_save = "False"
            file_available = False
            if os.path.isfile("auto_save.txt"):
                with open("auto_save.txt", "r") as red:
                    auto_save = red.read()
            try:
                with open("compress.txt", "r") as red:
                    comp_on_off = red.read().strip()
                if comp_on_off == "on":
                    comp_on = True
                    await compress_image("web/img_out.jpg", "web/img_out.jpg")
            except Exception as e:
                print(e)
                pass

            if "True" in str(auto_save):
                # actual_file_name = file_name.rsplit("/")[-1]
                all_files = os.listdir(f"{main_fold}{sep}{fold}/eval_files/")

                for file in all_files:
                    if file.startswith(roll + "_"):
                        file_available = True     
                        caption += f"\nFile already available !\nOld file: `{main_fold}{sep}{fold}/eval_files/{file}`\nNew file: `{file_name}`\n\nStill save it ?"
                        break

                if not file_available:
                    # copy image to file path
                    # os.system(f"cp -f web/img_out.jpg {file_name}")
                    os.system(f"cp -f web/img_out.jpg {file_name}")
                    caption += f"\nFile saved: {file_name}  ✅"

            if comp_on:
                fsize = os.path.getsize(file_name) / 1024
                caption += f'\n[Compresson: ON] {fsize:.2f} kb'
        if n:
            await n.reply_photo("web/img_out.jpg", caption=caption)
        else:
            await m.reply_photo("web/img_out.jpg", caption=caption)
        await fmsg.delete()
    except:
        if n:
            await n.reply_text(eval_file[0])   
        else:
            await m.reply_text(eval_file[0])   
        await fmsg.delete()         
   # try:
   #     os.remove("web/img_out.jpg") 
   # except:
    #    pass


@bot.on_message(filters.photo & filters.chat(group_id) & filters.user("@dephendor"))
async def send_btn(c, m):
    auto_save = "False"
    if os.path.isfile("auto_save.txt"):
        with open("auto_save.txt", "r") as red:
            auto_save = red.read()

    if auto_save != "False":
        return
    xdata = m.caption.split("\n")
    class_name = xdata[0].split()[1][1:]
    fold = class_name.split("_")[0]
    roll = xdata[1].split(" ",1)[1]
    mark = xdata[3].split(" ",1)[1]
    
    file_name = fold + "/" + class_name + "/eval_files/" + roll + "_" + mark + ".jpg"
    auto_save = "False"
    if os.path.isfile("auto_save.txt"):
        with open("auto_save.txt", "r") as red:
            auto_save = red.read()

    if auto_save == "True":
         actual_file_name = file_name.rsplit("/")[-1]

         all_files = os.listdir(f"{fold}{sep}{class_name}/eval_files/")

         for file in all_files:
            if actual_file_name.startswith(file.split("_")[0] + "_"):     
        #  if os.path.isfile(file_name):
                await m.reply_text(f"File already available !\nOld file: `{fold}{sep}{class_name}/eval_files/{file}`\nNew file: `{file_name}`\n\nStill save it ?", reply_markup = InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = "yes",
            callback_data= f"save_file_{file_name}"
        ),
        InlineKeyboardButton(
            text = "No",
            callback_data= "cancel"
        )
    ]
]))
                break
         else:
            await m.reply_to_message.download(file_name)
            await m.reply_text(f"Successfully saved to: `{file_name}`")
    else:
        await m.reply_text(file_name, reply_markup=reply_btn)


reply_btn = InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = "cancel",
            callback_data= f"cancel"
        ),
        InlineKeyboardButton(
            text = "save",
            callback_data= f"save_photo"
        )
    ]
])

@bot2.on_message(filters.chat(group_id) & filters.text& filters.user(iron_man))   
async def setting_text(c, m):
    full_text = m.text.strip()
    if "autoSave" in full_text:
        await m.delete()
        full_text_json = json.loads(full_text)
        autosave = full_text_json["autoSave"]
        compression = full_text_json["compression"]
        compression_size = full_text_json["compressionSize"]
        default_folder = full_text_json["examFolder"]
        sign = full_text_json["signature"]
        default_year = full_text_json["tuition"]
        text =f"""
autosave: {autosave}
compression: {compression}
compression size: {compression_size}
exam folder: {default_folder}
signature: {sign}
tuition: {default_year}
        """

        with open("data.txt", "w+") as wr: 
            json.dump(full_text_json, wr, indent=6)
        await bot.send_document(chat_id=m.chat.id, document="data.txt", caption=text, reply_markup=InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = "cancel",
            callback_data= f"cancel"
        ),
        InlineKeyboardButton(
            text = "confirm",
            callback_data= f"update_data_file"
        )
    ]
]))
        try:
            if autosave == "On":
                autosave = "True"
            else:
                autosave = "False"
            with open("auto_save.txt", 'w+') as red:
                red.write(autosave)

            if compression == "On":
                compression = "on"
            else:
                compression = "off"
            with open("compress.txt", 'w+') as red:
                red.write(compression)    
            
            if compression_size in ['100 KB', '150 KB', '200 KB']:
                compression_size = compression_size[:-2]
                with open("compress_size.txt", 'w+') as red:
                    red.write(compression_size.strip())

            with open("default_folder.txt", 'w+') as red:
                    red.write(default_folder.lower().strip())

            if default_year.lower() == "mvm":
                default_year = "2024"
            else:
                default_year = default_year.upper()
            with open("default_year.txt", 'w+') as red:
                    red.write(default_year.strip())

            if sign.lower() == "ashit":
                os.system("cp -f ashit_sign.png sign.png")
            if sign.lower() == "rupa":
                os.system("cp -f rupa_sign.png sign.png")
            if sign.lower() == "lakhia":
                os.system("cp -f lakhia_sign.png sign.png")

        except Exception as e:
            await m.reply_text(f"Error: {e}")

@bot2.on_message(filters.chat(group_id) & filters.document & filters.user(iron_man))   
async def ans_file(c, m):
    filename = m.document.file_name.lower()
    if filename.endswith("_ans_key.txt"):
       # filename = filename.replace(".json", "")
        og_name = filename
        fold1 = filename.split("_")[0]
        fold2 = filename.replace("_ans_key.txt", "")

        await m.download(f"null/{og_name}")
        new_og_name = m.caption
      #  new_og_name = fold1 + sep + fold2 + sep + og_name
        await bot.send_document(m.chat.id, document=f"null/{og_name}", caption=f"Update new Answer file ?:\n`{new_og_name}`", reply_markup=InlineKeyboardMarkup([
    [
        InlineKeyboardButton(
            text = "cancel",
            callback_data= f"cancel"
        ),
        InlineKeyboardButton(
            text = "update to git",
            callback_data= f"update_file"
        )
    ]
]))
        await m.delete()
    # elif filename.endswith("rolls.txt"):


@bot.on_message(filters.photo & filters.user(ADMINS))
async def fil_photo(c, m):
#   if len(m.text) < 10:
    chat = m.chat.id
    fol_told=None
    if os.path.exists("default_folder.txt"):
        with open("default_folder.txt", "r") as re:
            fol_told=re.read().strip()
        class_name = f"{fol_told.split('_')[0]}" 
        print("hi")   
    else:
            await c.send_message(chat,"Please set default folder.")
            return
        
    if fol_told:
        main_fold = f"{class_name}/{fol_told}"
        cap_given = None
        if m.caption:
            file_name = m.caption
            cap_given = True
        else:
            file_name = "1"          
        aa = await c.send_message(chat, f"Downloading ...")
        img_name = f"{main_fold}/og_files/{file_name}.jpg"
        await m.download(img_name)
        await aa.edit(f"Scanning ... {file_name}")

        if m.photo.width < m.photo.height:
            img = cv2.imread(img_name)
            img2 = cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
            cv2.imwrite(img_name, img2)

        eval_file = await read_img(f"{main_fold}/og_files/{file_name}.jpg",
                                    f"{main_fold}/eval_files/{file_name}", f"{main_fold}/{fol_told}_ans_key.txt", f"{main_fold}/eval_files", file_name, cap_given)
        
        if eval_file[1] == "error":
            await c.send_message(chat, eval_file[0])
            await aa.delete()
            return
        selected = eval_file[1]
        correct = eval_file[2]
        wrong = eval_file[3]
        total_keys = eval_file[4]
        actual_roll = eval_file[6]
        file_name = eval_file[5]
        already = eval_file[7]
        hash_class = class_name.split("-")[1]

        new_file_name = f"{file_name}_{correct}.jpg"
        if os.path.isfile(new_file_name):
            replace_msg = await m.reply_text(f"{new_file_name} already exists,\nReplace it ? \n[y/n]")
            get_con = await listen_message(c, chat, timeout=10)
            if get_con:
                if get_con.text.lower() != "y":
                    await c.send_message(chat, "Operation abroated !")
                    await replace_msg.delete()
                    return
                else:
                    await replace_msg.delete()
            else:
                await c.send_message(chat, "No responce got, proceeding with replacing the oler file.")
            await replace_msg.delete()
            await get_con.delete()
            cv2.imwrite(new_file_name, eval_file[0])
        else:
            cv2.imwrite(new_file_name, eval_file[0])

        if os.path.isfile(new_file_name):
            bb = await aa.edit("successfully Evaluated .\nUploading ...")
            if int(selected) == 0:
                await bb.edit("Student didnt answer anything, so it will count as absent .")
                return
            if os.path.exists(f"{class_name}{sep}{class_name}_rolls.txt"):
                with open(f"{class_name}{sep}{class_name}_rolls.txt", "r") as ro:
                    roll_names = json.load(ro)
                    if actual_roll.startswith("0"):
                        actual_roll = actual_roll[1:]
                        print(actual_roll, "replaced roll 0")
                    kid_name = roll_names.get(actual_roll)
                    
            await m.reply_photo(f"{file_name}_{correct}.jpg", caption = f""" 
Class: #class-{hash_class}    
Exam: #{fol_told.replace("-", "_")}
Name: __{kid_name}__
Roll no: {actual_roll}  
Total_mark: {total_keys}                                          
correct: **{correct}**
Wrong: {wrong}
Not selected: {total_keys - selected}

""")
            await aa.delete()

        else:
            await m.reply_text("Error in writing the eval file.")



import os


@bot.on_message(filters.command("result"))
async def show_result(c, m):
    chat = m.chat.id
    await c.send_message(chat, "Enter class :") 
    
    cls_name = None
    mark_list = {}
    fans={}
    cls_name = await listen_message(c, chat, timeout=10)
    if cls_name:
        class_name = f"class-{cls_name.text}"
        folder_name = None
        if not cls_name.text.isdigit():
            await c.send_message(chat, "Error in class name !")
            return
        all_folders = []
        for fold in os.scandir(class_name):
            if fold.is_dir():
                folder_name=fold.path.split(sep)[1]
                all_folders.append(folder_name)
              #  print(folder_name)
        fol_name_str = ""
        avail_folds = []
        for fo in all_folders:
            fol_name_str += f"**{all_folders.index(fo) + 1}**. `{fo}`" + "\n"
            avail_folds.append(fo)
        await c.send_message(chat, f"select folder name:\n{fol_name_str}")
        fol_tell = None
        fol_tell = await listen_message(c, chat, timeout=10)
        if fol_tell:
            if fol_tell.text.isdigit():
                fol_told = avail_folds[int(fol_tell.text) - 1]
            else:
                fol_told = fol_tell.text.lower()
            print(fol_told)
            if fol_told in all_folders:
                await c.send_message(chat, f"Selected folder: {fol_told}")
            else:
                await c.send_message(chat, f"Folder {fol_told} not found ! ")
                return
            main_fold = f"{class_name}/{fol_told}"
            res = {}
            rank_list = []
            ev = await c.send_message(chat, "Evaluating ...")

            for fold in os.listdir(f"{main_fold}{sep}eval_files"):
                if os.path.isfile(f"{main_fold}{sep}eval_files{sep}{fold}"):
                    file = fold
                    # print(file)
                    roll = file.split("_")[0]
                    mark = file.split("_")[1].split(".")[0]
                    res.update({roll : mark})
                    rank_list.append([roll, mark])

            rank_roll = {}
            seriel_rank = sorted(rank_list, key=lambda k : [int(k[0]), k])
           # print(seriel_rank)
            rank_list_sort = sorted(rank_list, key=lambda k : [int(k[1]), k])
            rank_list_sort.reverse()
           # print(rank_list_sort)
            rank_str = f"**{class_name}**\n{fol_told}\n--Roll--    --mark--\n"
            
            roll_N = None
            rannk = 1
            for ra in rank_list_sort:
                hi = ra[1]  #mark
                rank_str += f" {ra[0]}   -   {hi}\n"
                if roll_N:
                    if (hi != roll_N):
                        rannk += 1
                rank_roll.update({ra[0] : rannk})
                roll_N = hi


            await ev.edit(rank_str)
            for i in seriel_rank:
                fans.update({i[0] : i[1]}) 

            os.system(f"rm {main_fold}/{fol_told}_result.txt")
            with open(f"{main_fold}/{fol_told}_result.txt", "w+") as r:
                json.dump(fans, r, indent=6)  
            await c.send_document(chat, f"{main_fold}{sep}{fol_told}_result.txt")    
            
            # print(rank_str)
            img = cv2.imread("sheet.jpg")
            with open(f"{main_fold}{sep}{fol_told}_ans_key.txt", "r") as red:
                total_que_file = json.load(red)
            # print(len(total_que_file))
            total_que = str(len(total_que_file))
            x1 = 50
            y1 = 190

            fol_told2 = (fol_told.split("_")[1] + " [unit test - " + fol_told.split("_")[-1] + "]").capitalize()

            # fol_told2 = (fol_told[fol_told.find("_") + 1 :]).replace("_", " - ")
            c_date = datetime.datetime.now()
            exam_date = c_date.strftime("%d-%m-%Y")
            cv2.putText(img, cls_name.text, (180, 90), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,0), 2, cv2.LINE_AA)
            cv2.putText(img, fol_told2, (430, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,0), 2, cv2.LINE_AA)
            cv2.putText(img, f"Date: {exam_date}", (430, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,0), 2, cv2.LINE_AA)
            
            if os.path.exists(f"{class_name}{sep}{class_name}_rolls.txt"):
                with open(f"{class_name}{sep}{class_name}_rolls.txt", "r") as ro:
                    roll_names = json.load(ro)
            print(seriel_rank)
            y2 = None
            res_list = []
            for aa in roll_names: #seriel_rank:
                a = None
                for i in seriel_rank:
                    if str(i[0]) == aa:
                        a = i
     
                try:
                        total_marks = str(total_que)
                        got_mark = str(a[1])
                        his_rank = str(rank_roll.get(a[0]))
                except:
                         total_marks = "--"
                         got_mark = "--"
                         his_rank = "--"
                if his_rank == "1":
                     his_rank = "1" # + str(emo.emojize(':1st_place_medal:'))
                elif his_rank == "2":
                    his_rank = "2" # + str(emo.emojize(':2nd_place_medal:'))
                elif his_rank == "3":
                    his_rank = "3" #3+ str(emo.emojize(':3rd_place_medal:'))


                # string = f"{a[0]} {roll_names[a[0]]}         {total_que}                 {a[1]}            {rank_roll.get(a[0])}"
                cv2.putText(img, f"{aa}", (x1, y1), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,0), 2, cv2.LINE_AA)
                cv2.putText(img, f"{roll_names[aa]} ", (x1 + 80, y1), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,0), 2, cv2.LINE_AA)
                cv2.putText(img, total_marks, (x1 + 350, y1), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,0), 2, cv2.LINE_AA)
                cv2.putText(img, got_mark, (x1 + 450, y1), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,0), 2, cv2.LINE_AA)
                cv2.putText(img, his_rank, (x1 + 560, y1), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,0), 2, cv2.LINE_AA)

                res_list.append([aa, roll_names[aa], total_marks, got_mark, his_rank])


                y1 += 35
                y2 = y1
            # cv2.imshow("ll", img)   
            pdf_location_file = fol_told + "/" + fol_told + "_question.pdf"
            # global html_str1
            html_str1 = html_str_top

            html_str1 += f"""
<h1 id="heading">{fol_told2}</h1>
<nav id="navbar-example2" class="navbar bg-body-tertiary px-3 mb-3">
  <ul class="nav nav-pills">
        <li id="down-btn" class="nav-item">

        <button class="btn btn-outline-warning" onclick="document.location='{pdf_location_file}'">View question paper </button>
    </li>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <li id="down-btn" class="nav-item">

     <button type="button" class="btn btn-outline-success"
     onclick="document.location='{pdf_location_file}'">Download question paper </button>
    </li>
    &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
 
  </ul>
</nav>
    
        
<body>
""" 
            html_str1 +=  html_str2
            html_str1 += f"""
    <h4 style="color: rgb(7, 1, 14);"><u style=" text-decoration-line: underline; text-decoration-style: wavy;">
    Total Students: {len(rank_roll)}</u></h4>"""
            for i in rank_roll:
                roll = i
                rank = rank_roll.get(roll)
                got = None
                for ii in seriel_rank:
                    if str(ii[0]) == roll:
                        got = str(ii[1])
                        
                if not got:
                    got = "---"
                    rank = "---"
                    total_que = "---"

                try:
                    name = roll_names[roll]
                except:
                    name = "---"
                html_str1 += f"""<tr>
                <td><a href="{fol_told}/eval_files/{roll}_{got}.jpg">{name}</a></td>
                <td>{total_que}</td>
                <td>{got}</td>
                <td>{rank}</td>
            </tr>"""
            html_str1 += html_str3

            for i in res_list:
                roll = i[0]
                got = i[3]
                alt_name = i[1]
                # if not got == "---":
                html_str1 += f"""
    <a id="imgs">
    <h4>Roll: {roll}</h4>
    <img class="lazy" data-src="{fol_told}/eval_files/{roll}_{got}.jpg" alt="{alt_name}" width="380" loading="lazy"> </a>
    <br>
    <br>
    <br>
    <br> <br>
                    """

            html_str1 += html_str4
            html_str1 += "</body>  </html>"
            os.system(f"rm {fol_told}.html")

            with open(f"{fol_told}.html", "w+") as ed:
                ed.write(html_str1)
            await m.reply_document(f"{fol_told}.html")
            print(y2)
            shape = img.shape
            crop = img[0:y2 + 50, 0:980]
            # cv2.imshow("kki", crop)
            # cv2.waitKey(0)
            cv2.imwrite(f"{main_fold}{sep}result.png", crop)
            await c.send_photo(chat, f"{main_fold}{sep}result.png")
            # cv2.imshow("kki", img)
            # cv2.waitKey(0)
            print(res_list)
import re

@bot.on_message(filters.command("update"))
async def update_ans_key(c, m):
    if m.reply_to_message:
        texts = m.reply_to_message.text.lower()
        try:
            class_name_ = texts.split("\n")[0] 
            class_name_got = class_name_.split("_")[0]
            astr =texts.split("\n")[1]
        except:
            await m.reply_text("Write class and exam name on the first line.\neg: `class-10_english_2`")
            return
        
        astr = astr.replace(" ", "").replace(" ", "").replace(" ", "").replace(",", "")
        ans_key = {}
        bstr = re.findall(r"\d+", astr)
        for aa in bstr:
            astr = astr.replace(aa, "", 1)

        dstr = astr.split("-")
        dstr.pop(0)
        for cc in bstr:
            opts = dstr[bstr.index(str(cc))]
            multi_opts = []
            for multi in opts:
                multi_opts.append(multi.upper())

            ans_key.update({cc: multi_opts})

        with open(f"{class_name_got}{sep}{class_name_}{sep}{class_name_}_ans_key.txt", "w+") as wr:
                        json.dump(ans_key, wr, indent=6)

        await c.send_message(m.chat.id, f"Successfully updated the file {class_name_got}{sep}{class_name_}{sep}{class_name_}_ans_key.txt")
        await c.send_document(m.chat.id, f"{class_name_got}{sep}{class_name_}{sep}{class_name_}_ans_key.txt")


@bot.on_message(filters.command("start"))
async def start(c, m):
    chat_id = m.chat.id
    aa = await c.send_message(chat_id, "Enter class name: ")
    class_name = None
    subject = None
    ans_key_file = None
    year_name = year
    with open("default_year.txt", "r") as red:
            year_name = red.read().strip()
    class_name = await listen_message(c, m.chat.id, timeout=10)
    class_name_got = f"class-{class_name.text}"
    if class_name:
        print(class_name.text) 
        await c.send_message(chat_id, f"Class = {class_name_got}\nEnter subject :")
        subject = await listen_message(c,m.chat.id, timeout=10)
        if subject:
            subject_name = subject.text.lower()
            for f in range(1, 100):
                folder_name = f"{class_name_got}_{subject_name}_{f}"
                if not os.path.exists(f"{class_name_got}"):
                    os.mkdir(class_name_got)
                if not os.path.exists(f"{class_name_got}/{folder_name}"):
                    make_fold = os.mkdir(f"{class_name_got}/{folder_name}")
                    os.mkdir(f"{class_name_got}/{folder_name}/og_files")
                    os.mkdir(f"{class_name_got}/{folder_name}/eval_files")

                    break

            wait_msg = await subject.reply_text(f"""Folder **{class_name_got}/{folder_name}** has been created and ready to use .
                                     \nYou can Now send the Answer key ..\n(Within 20 seconds)""")

            ans_key_file_name = f"{folder_name}_ans_key.txt"
            alink = f"ashit.xyz/answer_file.html?filename={year_name}{sep}{class_name_got}{sep}{folder_name}{sep}{ans_key_file_name}"
            await subject.reply_text(f"OR click this link and update your answers. {alink}")

            ans_key_file = await listen_message(c, chat_id, timeout=20)

            if ans_key_file:
                    try:
                        astr = ans_key_file.text.split("\n")[1]
                    except:
                        astr = ans_key_file.text

                    astr = astr.replace(" ", "").replace(" ", "").replace(" ", "").replace(",", "")
                    ans_key = {}
                    bstr = re.findall(r"\d+", astr)
                    for aa in bstr:
                        astr = astr.replace(aa, "", 1)

                    dstr = astr.split("-")
                    dstr.pop(0)
                    for cc in bstr:
                        opts = dstr[bstr.index(str(cc))]
                        multi_opts = []
                        for multi in opts:
                            multi_opts.append(multi.upper())
                        ans_key.update({cc: multi_opts})

                    with open(f"{class_name_got}/{folder_name}/{ans_key_file_name}", "w+") as wr:
                        json.dump(ans_key, wr, indent=6)
                    print(ans_key)
                    await c.send_message(chat_id, f"Answer key has been successfully saved, you should check the file below once.")
                    await c.send_document(chat_id, f"{class_name_got}/{folder_name}/{ans_key_file_name}")

                    # with open("locations.txt") as ed:
                    #     locs = json.load(ed)
                 
                    # image = cv2.imread("blank_sheet.jpg")
                    # for ser_num in ans_key:
                    #     x = int(ser_num)
                    #     [pre_y] = ans_key[ser_num]
                   
                    #     y = None
                    #     if pre_y == "A":
                    #        y = 1
                    #     elif pre_y == "B":
                    #        y = 2
                    #     elif pre_y == "C":
                    #        y = 3
                    #     elif pre_y == "D":
                    #        y = 4
                    #     else:
                    #         print("didnt get the y")
                    #         y = None
                    #     if y:
                    #         opt_num = 4 * (x - 1) + y
                    #         [a, b] = locs.get(str(opt_num))
                     
                    #         cv2.circle(image, (a, b), 2, (238, 48, 167), 7)  # pink 
                    # cv2.imwrite("ans.jpg", image)
                    # await c.send_document(chat_id, "ans.jpg")
                    # os.remove("ans.jpg")
                    try:
                        with open("default_folder.txt", "w+") as writ:
                            writ.write(folder_name)
                        mes = await m.reply_text(f"Default folder has been changed to : `{folder_name}`")
                        await mes.pin()
                    except Exception as e:
                        print(e)
                    eval_file = await read_img(f"blank_sheet.jpg",
                                                    f"99", f"{class_name_got}/{folder_name}/{ans_key_file_name}", None, None, True)
                    cv2.imwrite("99_0.jpg", eval_file[0])
                    await c.send_photo(chat_id, "99_0.jpg")
                    
                        

            else:
                await wait_msg.delete()

        else:
            await c.send_message(chat_id, "timeout")

    else:
        await c.send_message(chat_id, "timeout")
import shutil
    
# const chatId = "-1001774957665"; // Replace with your Telegram chat ID
#                 const token = "1848113090:AAHt8IFMRQ5JD4DjKe-AihZJuiD48u-uyp0";


@bot.on_message(filters.command("absent"))
async def delet(c, m):
    yes_or_no = None
    class_num = m.text.lower().split(" ")[1]
    with open("default_folder.txt", "r") as re:
            fol_told=re.read()
    try:
        class_got = class_num.split("/")[0]
        roll_got = class_num.split("/")[1]
    except:
        class_got = fol_told.split("_")[0]
        roll_got = class_num
    
    if roll_got.isdigit():
        to_del = class_got + "/" + fol_told + "/eval_files" + "/" + roll_got + "*"
        print(to_del)
        bb = await m.reply_text(f"Delete {to_del} ?\nAre you sure ?\n[y/n]")
        yes_or_no = await listen_message(c, m.chat.id, timeout=10)
        if yes_or_no and yes_or_no.text.lower() == "y":
           os.system(f"rm -rf {to_del}")
           await bb.edit("successfully deleted.")
        else:
            await m.reply_text("Aborted .")
    else:
        await m.reply_text("PLease give class number and his roll number.\n class-9/17")


@bot2.on_message(filters.command("roll"))
def chnge(c, m):
    try:
        rid = m.reply_to_message.id
        cap = m.text.split()[1]
        cap_int = int(cap)
        if cap_int > 0 and cap_int < 100:
        # add check fro integer from 1 to 99

            chat_id = m.chat.id
            iron_token = "1848113090:AAHt8IFMRQ5JD4DjKe-AihZJuiD48u-uyp0"
            api_url = f"https://api.telegram.org/bot{iron_token}/editMessageCaption"
            payload = {
                'chat_id': chat_id,
                'message_id': rid,
                'caption': cap
            }
            # stri = f"""?chat_id={chat_id}&&message_id={rid}&&caption={cap}"""
            resp = requests.post(api_url, data=payload)
            true_or_not = resp.json()['ok']
            if str(true_or_not) == "True":
                m.delete()
            else:
                m.reply_text(str(true_or_not))
        else:
            m.reply_text("Give a valid number from 1 to 99.")
    except Exception as e:
        if str(e) == "list index out of range":
            m.reply_text("Give roll number along with command.")
        else:
            m.reply_text(str(e))



@bot.on_message(filters.command("del"))
async def dele(c, m):
     yes_or_no = None
     fname = m.text.lower()
     class_name = fname.split()[1].split("_")[0]
    #  print(class_name)
    #  print(fname)
     main_file = f"{class_name}/{fname.split()[1].lower()}"
     await m.reply_text(f"Delete {main_file} ?\nAre you sure ?\n[y/n]")
     yes_or_no = await listen_message(c, m.chat.id, timeout=10)
     if yes_or_no and yes_or_no.text.lower() == "y":
          try:
            shutil.rmtree(main_file) 
            await c.send_message(m.chat.id, f"Successfully deleted {main_file}")
          except Exception as e:
               await c.send_message(m.chat.id, str(e))

     else:
          await c.send_message(m.chat.id, "TImeout")


def exc(client, m):
    if m.text.startswith(' '):
        cmd = m.text[1:]
        tes = m.reply_text('`Processing ...`')
        idk = str(rain(0000000000, 9999999999))

        output=os.system(f"{cmd} > null/{idk}.txt")
        if output or str(output) == "0":
           with open(f"null/{idk}.txt", 'r') as se:
             output = se.read()
        try:
            tes.edit(str(output))
        except Exception as e:
            if str(e) == """Telegram says: [400 MESSAGE_TOO_LONG] - The message text is over 4096 characters (caused by "messages.EditMessage")""":
               tes.delete()
               m.reply_document(f"null/{idk}.txt")
            elif str(e) == """Telegram says: [400 MESSAGE_EMPTY] - The message sent is empty or contains invalid characters (caused by "messages.EditMessage")""":
               tes.edit("Empty output !")
            else:
                tes.edit(str(e))
        finally:
           os.system(f"rm -rf null/{idk}.txt")


@bot.on_message(filters.user(Owner) & filters.regex("$"))
def okey(c, m):
    if m.text and m.text.startswith("$"):
        exc(c, m)
   


html_str_top = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Answer sheets</title>
    <style>
    #heading{
            display: flex;
            justify-content: center;
             padding-top: 20px;
              padding-right: 10%;
        }
        #down-btn {
            padding: 5px;
        }
        body {
            font-family: Arial, sans-serif;
            padding: 5px;
        }
        #search-bar {
            margin-bottom: 20px;
            width: 100%;
            padding: 10px;
            font-size: 16px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            text-align: left;
            padding: 8px;
            vertical-align: middle; /* Align values to the middle */
        }
        th {
            /* background-color: #babdba; */
            color: rgb(1, 8, 14);
        }
    
        tr:nth-child(even) {
            background-color: #eee9e9;
        }
        td:not(:first-child){
            padding-left: 20px;
        }
        #not-found {
            display: none;
            color: red;
            font-weight: bold;
        }
        a {
            text-decoration: none !important;
            color: blue;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

"""
html_str2= """


    <input type="text" id="search-bar" placeholder="Search for names...">
    <p id="not-found">Not found</p>
    <table id="name-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Total mark</th>
                <th>Secured mark</th>
                <th>Rank</th>
            </tr> 
        </thead>

        <tbody>
"""

html_str3 = """  </tbody>
    </table>
    <br>
    <br>
    <br>
    <h2 id="heading2">&nbsp;&nbsp;&nbsp;All student's answer sheeets (Roll number wise).</h2>"""

html_str4 = """
   <script>
 const searchBar = document.getElementById('search-bar');
        const nameTable = document.getElementById('name-table').getElementsByTagName('tbody')[0];
        const notFound = document.getElementById('not-found');
        const rows = nameTable.getElementsByTagName('tr');
        const images = document.querySelectorAll('img');
        const imageContainer = document.getElementById('imgs');

        searchBar.addEventListener('input', () => {
            const filter = searchBar.value.trim().toLowerCase();
            let matchFound = false;
            let visibleImageCount = 0;

              heading2.style.display = 'none';
            // Search in the table
            for (let i = 0; i < rows.length; i++) {
                const name = rows[i].getElementsByTagName('td')[0].textContent || rows[i].getElementsByTagName('td')[0].innerText;
                if (name.toLowerCase().includes(filter)) {
                    rows[i].style.display = '';
                    matchFound = true;
                } else {
                    rows[i].style.display = 'none';
                }
            }

            // Search in the images
            images.forEach((img) => {
                const altText = img.alt.toLowerCase();
                if (altText.includes(filter)) {
                    img.style.display = '';
                    visibleImageCount++;
                    matchFound = true;
                } else {
                    img.style.display = 'none';
                }
            });

            // Remove all existing <br> tags
            const brTags = document.querySelectorAll('br');
            brTags.forEach((br) => {
                br.remove();
            });

            // Add two <br> tags after each visible image except for the last one
            if (visibleImageCount > 1) {
                let brCount = 0;
                images.forEach((img, index) => {
                    if (img.style.display === '') {
                        if (brCount < visibleImageCount - 1) {
                            const br1 = document.createElement('br');
                            const br2 = document.createElement('br');
                            img.parentNode.insertBefore(br1, img.nextSibling);
                            img.parentNode.insertBefore(br2, img.nextSibling);
                            brCount++;
                        }
                    }
                });
            }

            // Toggle visibility of 'Not found' message
            notFound.style.display = matchFound ? 'none' : 'block';
        });

document.addEventListener("DOMContentLoaded", function() {
            let lazyImages = document.querySelectorAll('img.lazy');
            let imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        let img = entry.target;
                        img.src = img.dataset.src;
                        img.onload = () => {
                            img.classList.remove('placeholder');
                        };
                        observer.unobserve(img);
                    }
                });
            });

            lazyImages.forEach(image => {
                imageObserver.observe(image);
            });
        });
    </script>
"""


bot.start()
bot2.start()
print("started")
idle()
bot.stop()
bot2.stop()
