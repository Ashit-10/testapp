
from PIL import Image as pi_image

def yu(x):
    pi_filename = "green.png"
    pi_filename1 = "image.jpg"
    frontimage = pi_image.open(pi_filename)
    background= pi_image.open(pi_filename1)

    frontimage = frontimage.resize((40, 40))

    frontimage = frontimage.convert("RGBA")
    background = background.convert("RGBA")
    background.paste(frontimage, (260, 120), frontimage)
    background.save("new.png", format="png")
    
yu("ok")
