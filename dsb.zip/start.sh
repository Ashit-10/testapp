#!/bin/bash
pip3 install -r requirements.txt
python3 dsb.py
