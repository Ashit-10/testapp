import os
import time
import subprocess as su




key_path = "/root"

def sign(file, final):
  #  os.system(f"jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore cert.keystore -storepass dsb@69  {file}.apk cert >> logs.txt")
    os.system(
        f"jarsigner -verbose -keystore {key_path}/cert.keystore -storepass dsb@69  {file}.apk cert >> logs.txt")
    os.system(f"zipalign -v 4 {file}.apk {final}.apk >> logs.txt")
    print(f"Signed {final}.apk")


def dc_rc(path, *args):
    portrait_height = "38.0dip"
    string = "M73,72 C34.5904014,71.9994844 10.2575195,71.9993984 0.00135404332,71.9997422 C-10.2556836,72.0000859 -34.5894683,72.0001719 -73,72 L-73,0 L73,0 L73,72 Z"
    top_padding = "4.0dip"
    
    cpath = os.getcwd()
    os.chdir(str(path))
    if args:
        if "b" in str(args[0]):
            portrait_height = "92.0px"
            top_padding = "0.0dip"
        if "a11" in str(args[0]):
            string = "M 0,0 L 0, 0 C -1,34 0,0 0,0 Z @dp @right"
            top_padding = "3.0dip"
    if os.path.isfile("DevicesAndroidOverlay.apk"):
        os.system("apktool d -f DevicesAndroidOverlay.apk > logs.txt")

    if os.path.isfile("DevicesOverlay.apk"):
        os.system("apktool d -f DevicesOverlay.apk >> logs.txt")

    folds = []
    for file in os.listdir():
        if os.path.isdir(file):
            if str(file).startswith("Devices"):
                folds.append(file)

    if folds:
        for folder in folds:
            if "DevicesOverlay" in str(folder):
                path1 = folder
                os.system(
                    f"cd {path1}/res/ && ls values*/dimens.xml > ../../dms.txt")
                os.system(f"cd {path1}/res/ && rm -rf values*/public.xml")

                if os.path.isfile("dms.txt"):
                    with open("dms.txt", "r") as dm:
                        odm = dm.readlines()
                for xmls in odm:
                    xml = xmls.strip()
                    with open(f"{path1}/res/{xml}", "r") as xd:
                        dxml = xd.read()
                    xmlines = dxml.split('\n')
                    x = 0
                    for xmline in xmlines:
                       
                        if '<dimen name="notch_status_bar_padding_top">' in str(xmline):
                            xmlines[x] = f'''    <dimen name="notch_status_bar_padding_top">{top_padding}</dimen>'''

                        elif '<dimen name="status_bar_padding_top">' in str(xmline):
                            xmlines[x] = f'''    <dimen name="status_bar_padding_top">{top_padding}</dimen>'''

                        elif '<dimen name="recents_task_view_rounded_corners_radius">' in str(xmline):
                            xmlines[x] = '''    <dimen name="recents_task_view_rounded_corners_radius">3.0dip</dimen>'''

                        elif '<dimen name="incall_round_cornor_padding">' in str(xmline):
                            xmlines[x] = '''    <dimen name="incall_round_cornor_padding">5.0dip</dimen>'''

                        elif '<dimen name="round_cornor_padding">' in str(xmline):
                            xmlines[x] = '''    <dimen name="round_cornor_padding">7.0dip</dimen>'''

                        elif '<dimen name="rounded_corner_content_padding">' in str(xmline):
                            xmlines[x] = '''    <dimen name="rounded_corner_content_padding">15.0dip</dimen>'''

                        elif '<dimen name="notch_hole_type_status_bar_padding_top>' in str(xmline):
                            xmlines[x] = f'''    <dimen name="notch_hole_type_status_bar_padding_top">{top_padding}</dimen>'''

                        elif 'APKTOOL_DUMMY' in str(xmline):
                            xmlines[x] = ""

                        x += 1
                        
                    if "</resources>" not in xmlines:
                        xmlines.append("\n</resources>")
                        
                    fxml = "\n".join(xmlines)
                    with open(f"{path1}/res/{xml}", "w+") as w:
                        w.write(fxml)

                print("DevicesOverlay.apk done.")
                os.system(
                        f"apktool b DevicesOverlay >> logs.txt")
                os.system("mv DevicesOverlay/dist/*.apk do.apk")
                os.system("rm -rf DevicesOverlay.apk")
                sign("do", "DevicesOverlay")

    if folds:
        for folder in folds:
            if "DevicesAndroidOverlay" in str(folder):
                path1 = folder
                os.system(
                    f"cd {path1}/res/ && ls values*/dimens.xml > ../../dms.txt")
                os.system(f"cd {path1}/res/ && rm -rf values*/public.xml")

                if os.path.isfile("dms.txt"):
                    with open("dms.txt", "r") as dm:
                        odm = dm.readlines()
                for xmls in odm:
                    xml = xmls.strip()
                    with open(f"{path1}/res/{xml}", "r") as xd:
                        dxml = xd.read()
                    xmlines = dxml.split('\n')
                    x = 0
                    for xmline in xmlines:
                        if '<dimen name="status_bar_height_portrait">' in str(xmline):
                            xmlines[x] = f'''    <dimen name="status_bar_height_portrait">{portrait_height}</dimen>'''

                        elif 'APKTOOL_DUMMY' in str(xmline):
                            xmlines[x] = ""

                        x += 1

                    if 'name="status_bar_height_portrait"' not in str(xmlines):
                        del xmlines[(len(xmlines) - 2)]
                        xmlines.append(
                            f'''    <dimen name="status_bar_height_portrait">{portrait_height}</dimen>\n</resources>\n''')

                    fxml = "\n".join(xmlines)
                    with open(f"{path1}/res/{xml}", "w+") as w:
                        w.write(fxml)
                 
                    path2 = str(
                        f"{path1}/res/{xml}").replace("dimens", "strings")
                    strlines = []
                    if os.path.isfile(path2):
                        with open(f"{path2}", "r") as xds:
                            dstr = xds.read()
                        strlines = dstr.split('\n')
                    if strlines:
                        s = 0
                        for strline in strlines:
                            if '<string name="config_mainBuiltInDisplayCutout">' in str(strline):
                                strlines[s] = f'''    <string name="config_mainBuiltInDisplayCutout">{string}</string>'''

                            elif 'APKTOOL_DUMMY' in str(xmline):
                                strlines[s] = ""

                            s += 1
                            
                        if 'name="config_mainBuiltInDisplayCutout"' not in str(strlines):
                            del strlines[(len(strlines) - 2)]
                            strlines.append(
                                f'''    <string name="config_mainBuiltInDisplayCutout">{string}</string>\n</resources>\n''')

                        if "</resources>" not in xmlines:
                            xmlines.append("\n</resources>")
                        
                        fstr = "\n".join(strlines)
                        with open(f"{path2}", "w+") as w:
                            w.write(fstr)

            print("DevicesAndroidOverlay.apk done.")
            os.system(
                "apktool b DevicesAndroidOverlay >> logs.txt")
            os.system("mv DevicesAndroidOverlay/dist/*.apk da.apk")
            os.system("rm -rf DevicesAndroidOverlay.apk")
            sign("da", "DevicesAndroidOverlay")

   
    os.system("rm -rf dms.txt do.apk da.apk DevicesOverlay DevicesAndroidOverlay")

    os.chdir(str(cpath))
