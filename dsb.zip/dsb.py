import os
import logging
from pyrogram import *
import time
import datetime
from pyrogram.types import *
from pyrogram.types.bots_and_keyboards import reply_keyboard_markup
from pyrogram.types.messages_and_media import document
import subprocess as sub
import string, random
from random import randint as rain
from apscheduler.schedulers.background import BackgroundScheduler
import pytz
import time
from datetime import timedelta

tz = pytz.timezone("Asia/kolkata")
sj = BackgroundScheduler(timezone="Asia/kolkata")

import sys
import apk
from apk import dc_rc
import base64
bot_token = '2036412422:AAGbVjBVTyCPVX8pOygMH5bGFgTmYapHxik'
api_id = '6810439'
api_hash = '66ac3b67cce1771ce129819a42efe02e'

import pytz

tz = pytz.timezone("Asia/kolkata")
import os.path
import pickle
import sys
from io import BytesIO

from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
import re
import json




bot = Client(
    'pyro-bot',
    bot_token=bot_token,
    api_id=int(api_id),
    api_hash=api_hash
)

bot1 = Client(
    'pyro-bot1',
    bot_token="2083150939:AAEXx69yWFkMyf3RWtghtiDChPFdGSGw6Go",
    api_id=int(api_id),
    api_hash=api_hash
)

ADMINS = [1602293216, 1845525834, 809293242, 19371046]
MIUI_CHAT = -1001542320014
MIUI_CHAT1 = -1001605236910
MIUI_CHANNEL = -1001205981587
MIUI_CHAT3 = -1001349019437
MIUI_LOG = -1001621501101
BOT_ID = 2036412422
MIUI_BARN = -1001621501101
conversations = {}
infos = {}
user_inputs = {}

OWNER = "1602293216"

@bot.on_message(filters.command(["gj"]))
def js(c, m):
   try:
      m.reply_text(sj.get_job(f"{MIUI_CHAT1}_{m.text.split()[1]}_del"))
   finally:
      m.reply_text(sj.get_job(f"{MIUI_CHAT1}_{m.text.split()[1]}_e"))
   


sche_done = InlineKeyboardMarkup([
    [InlineKeyboardButton(
        text=f"1 hour", callback_data="sch_3600"), InlineKeyboardButton(
        text=f"4 hours", callback_data="sch_14400")],
    [InlineKeyboardButton(
        text=f"8 hours", callback_data="sch_28800"), InlineKeyboardButton(
        text=f"24 hours", callback_data="sch_86400")],
    [InlineKeyboardButton(
        text=f"cancel scheduled msg", callback_data="sch_cancell")]])
        
        
def gdrive_service():
    CLIENT_SECRET_FILE = "client_secrets.json"
    API_SERVICE_NAME = "drive"
    API_VERSION = "v3"
    SCOPES = ['https://www.googleapis.com/auth/drive.metadata.readonly',
          'https://www.googleapis.com/auth/drive.file']
    cred = None

    pickle_file = f'token_{API_SERVICE_NAME}_{API_VERSION}.pickle'
    # print(pickle_file)

    if os.path.exists(pickle_file):
        with open(pickle_file, 'rb') as token:
            cred = pickle.load(token)

    if not cred or not cred.valid:
        if cred and cred.expired and cred.refresh_token:
            cred.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
            cred = flow.run_local_server()

        with open(pickle_file, 'wb') as token:
            pickle.dump(cred, token)

    try:
        service = build(API_SERVICE_NAME, API_VERSION, credentials=cred)
        return service 
    except:
       return None


DSB_POSTING_MESSAGE = """**Android** : 12
**Downloads** :- [Click Here](https://dualstatusbar.in/miui)
- by [#DsbTeam](https://t.me/DSB_Team)

**Support group** - @miuiDsb_support
(check notes if instructions needed or request if dsb needed for your device) 

**Follow our Channel for more** - @DualstatusbarMiui"""

postdb = {}

@bot.on_message(filters.command(["post"]) & filters.user(ADMINS))
def post(client, message):
    qwe = message.reply_text("Processing ")
    if not " " in message.text and len(message.command) < 4:
        qwe.edit("Invalid name or missing infos !\n`/post <base> <version> <Device name>`", parse_mode="md")
        return 
    if message.reply_to_message and not message.reply_to_message.photo:
        qwe.edit("Reply to a photo when ?")
        return 
    BASE = message.command[1]
    VERSION = message.command[2]
    DNAME = message.text.split(" ",3)[3]
    PHOTO = message.reply_to_message.photo.file_id
    preview = bot.send_photo(chat_id=message.chat.id,
                                             parse_mode='md',
                                             reply_to_message_id=None,
                                             reply_markup=InlineKeyboardMarkup(
                                                 [
                                                     [InlineKeyboardButton(
                                                        text=f"""Download Dsb""",
                                                         url=f"www.dualstatusbar.in/miui",
                                                     )]]),
                                             photo=PHOTO,
                                             caption=f""" Dual Status Bar Miui\n\n**ROM** : {BASE} {VERSION}\n**DEVICE** : {DNAME}\n{DSB_POSTING_MESSAGE}""")

    postdb.update({message.from_user.id: PHOTO})
    bot.send_message(message.chat.id, "post to Miui channel ?", reply_to_message_id=preview.message_id, reply_markup=InlineKeyboardMarkup(
                                                 [
                                                     [InlineKeyboardButton(
                                                        text=f"""Post""",
                                                         callback_data=f"post_post",
                                                     )],
                                                     [InlineKeyboardButton(
                                                        text=f"""Cancel""",
                                                         callback_data=f"post_cancel",
                                                     )]
                                                     ]))
    qwe.delete()
     



#import github
#from github import Github
#from github import InputGitTreeElement

def gitpush(file, file_to_update):
    repo_token = "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"
    branch = "main"
    ct = time.time()
    now = datetime.datetime.now(tz)
    nowfile = str(now).replace(' ', '_')
    gh = github.Github(repo_token)
    repository = "DualStatusBar/dualstatusbar.github.io"
    elements = []
    remote_repo = gh.get_repo(repository)
    data = base64.b64encode(open(file_to_update, "rb").read())
    blob = remote_repo.create_git_blob(data.decode("utf-8"), "base64")
    element = github.InputGitTreeElement(
        path=file_to_update, mode='100644', type='blob', sha=blob.sha)
    elements.append(element)

    commit_message = f'Updated files at {now}'

    branch_sha = remote_repo.get_branch(branch).commit.sha

    base_tree = remote_repo.get_git_tree(sha=branch_sha)

    tree = remote_repo.create_git_tree(elements, base_tree)

    parent = remote_repo.get_git_commit(sha=branch_sha)

    commit = remote_repo.create_git_commit(commit_message, tree, [parent])

    branch_refs = remote_repo.get_git_ref(f'heads/{branch}')

    branch_refs.edit(sha=commit.sha)
    

def make_page(device_name, link) -> str:

    with open("demo.html", 'r') as miui:
        miui_text = miui.read()
    miui_text = miui_text.replace(
        'DEMO_DEVICE', device_name).replace('DEMO_LINK', link)
    file_name = (''.join(device_name.split())).lower().strip()
    os.system("mkdir -p miui")
    with open(f'miui/{file_name}.html', 'w+') as new:
        new.write(miui_text)
    gitpush(f'{file_name}.html', f"miui/{file_name}.html")
   # update miui.html
   
    with open('demo_miui.html', 'r') as demo:
        miui_html = demo.readlines()
    for line in miui_html:
        if (device_name.split()[0]).lower() in line.lower():
            new_line = '<li> <a href="https://dualstatusbar.github.io/miui/' + file_name + '">' + device_name + '</a></li>'
            miui_html[miui_html.index(line)] = line + new_line
            with open('miui.html', 'w+') as rit:
                rit.write(''.join(miui_html))
            break
    
    gitpush("miui.html", "miui.html")
    
    print('Successfully commited new github page')
    



@bot.on_message(filters.command(["github"], ["/", "!"]) & filters.user(ADMINS))
def github_(client, m):
    proc = m.reply_text("Processing..")
    if ' ' in m.text:
         link = m.text.split()[1]
         device_name = m.text.split(' ', 2)[2]
         make_page(device_name, link)
         proc.edit("Done")








roms = ["mi9se", "mi9lite", "mi9pro", "mi9tpro", "mi9t", "mi9", "x3pro", "x3", 
    "k20pro", "k20s", "k20", "k30pro", "k30sultra", "k30s", "k30",
     "mi10ultra","mi10tpro", "mi10s", "mi10t", "mi10", "mi11lite5gne", 
     "mi11lite5g", "mi11lite", "mi11ultra", "mi11lite", "mi11le", "mi11tpro", 
     "mi11x", "mi11i", "mi11", "mia1","mia2", "note10promax", "note10pro", "note10s", "note10", "redmi10",
     "note5pro", "realme5pro", "5pro", "pocof3gt", "pocof3", "pocof4gt", 
     "redmik40", "pocof4", "redmik50g", "redmik50", "m2pro", "m3pro", "pocom3", "pocom5s"
     "pocox3pro", "pocox3gt", "pocox3", "pocox4pro5g", "x4pro5g", "note9promax", "note9pro", "note9s", "note9", "redmi9t", "redmi9c", "redmi9",
     "note7pro", "10x4g", "note7s", "note7", "note8pro", "note8t", "note8", "note11s",
    "note11", "xiaomi12tpro", "xiaomi12x", "xiaomi12", "f2pro", "redmi5"]


@bot.on_message(filters.command(["gs"], ["/", "!"]) & filters.user(ADMINS))
def serch(client, m):
    if not m.reply_to_message:
       m.delete()
       return
    if m.reply_to_message.text:      
        strs = m.reply_to_message.text
    elif m.reply_to_message.caption:
        strs = m.reply_to_message.caption 
    else:
        return
    strs1 = ""
    if len(m.command) > 1:
        strs1=m.text.split(" ", 1)[1]
   
    strs = strs + str(strs1)
    strsP = strs + " " + str(strs1)
    qwe = m.reply_text("searching ..")
    version = None
    okk=re.compile(r'(\d{1,2}\.\d{1,2}\.\d{1,2})|(\d{1,2}\.\d{1,2}\.\d{1,2}\.\d{0,2})')
    for i in okk.finditer(strs):
       version = i.group(0)
       break
    if not version:
        qwe.edit("Error finding version code.")
        return
    strs = strs.replace(" ", "")
    strs = strs.replace(" ", "")
    device = None

    rls = ""
    for j in roms:
       if j in strs.lower():                      
           device = j      
           break
          
      
    if not device:
        qwe.edit("Error finding device name.")
        return
    strs=strs.replace(device, "")
    base = None
    if "eu" in strs.lower():
        base = "eu"
    elif "cn" in strs.lower():
        base = "cn"
    elif "eea" in strs.lower():
        base = "eu"
    elif "vn" in strs.lower():
        base = "vn"    
    elif "india" in strsP.lower():
        base = "in"
    elif "vietsub" in strs.lower():
        base = "vn"
    elif "ru" in strs.lower():
        base = "ru"
    elif "sr" in strs.lower():
        base = "sr"
    elif "global" in strs.lower():
        base = "global"
    elif "china" in strs.lower():
        base = "cn"
    elif "id" in strsP.lower():
        base = "id"
    elif "in" in strsP.lower():
        base = "in"
    try:
        service = gdrive_service()
        
               
        trigger = device
        with open("roms.txt") as red:
               romname = json.load(red)              
        try:
              parent_id = romname[trigger]
        except:
              qwe.edit(f"folder not found for `{trigger}`")
              if "d" in m.text.lower() or "del" in m.text.lower():
                m.delete()
                time.sleep(5)
                qwe.delete()
              return        
   
        query = f"parents = '{parent_id}'"
        res = service.files().list(q=query).execute()
        files = res.get("files")
        files_list = ""
        files_list_b = ""
        if not files:
             qwe.edit("Not found !")
             if "d" in m.text.lower() or "del" in m.text.lower():
               m.delete()
               time.sleep(5)
               qwe.delete()
             return 
        for i in files:
             iname = i["name"]
             if version in iname:
                 if base:
                    if base in iname.lower():
                        files_list += ">> `" + str(i["name"]) + "`\n"
                    else:
                        files_list_b += ">> `" + str(i["name"]) + "`\n"
        bully = None
        if files_list:       
            bully = qwe.edit(f"**File found in gdrive:-**\n{files_list}")
        elif files_list_b:
            qwe.edit(f"File not found in gdrive, here are some similar results:-\n{files_list_b}")
        else:
           qwe.edit("File not found in gdrive.")

        
    except Exception as e:
        qwe.edit(str(e))     
    if bully and ("bully" in m.text.lower() or "b" in m.text.lower()):
        replied = m.reply_to_message
        id = replied.from_user.id
        m.delete()
        replied.reply(f"Hello [retard](tg://user?id={id}), File already available in [website](https://t.me/MiuiDSB_Support/48748), always check `#downloads` before spamming ", disable_web_page_preview=True)
    elif "d" in m.text.lower() or "del" in m.text.lower():
        m.delete()
        time.sleep(5)
        qwe.delete()

roms_dict = {"mi9se": "Mi9 SE", "mi9lite": "Mi9 Lite", "mi9pro": "Mi9 Pro", "mi9tpro": "Mi 9T Pro", "mi9t":"Mi 9T", "x3pro": "Poco X3 Pro", "x3": "Poco X3", 
    "k20pro": "K20 Pro", "k20s": "Redmi K20S", "k20": "Redmi K20", "k30pro": "K30 Pro", "k30sultra": "K30S Ultra", "k30s": "Redmi K30S", "k30": "Redmi K30",
     "mi10ultra": "Mi10 Ultra","mi10tpro": "Mi 10T Pro", "mi10s": "Mi 10S", "mi10t": "Mi 10T", "mi10": "Mi 10", "mi11lite5gne": "Mi11 Lite 5G NE", 
     "mi11lite5g": "Mi11 Lite 5G", "mi11lite": "Mi 11 Lite", "mi11ultra": "Mi 11 Ultra", "mi11lite": "Mi 11 Lite", "mi11le": "Mi 11 LE", "mi11tpro": "Mi 11T Pro", 
     "mi11x": "Mi 11X", "mi11i": "mi 11i", "mi11": "Mi 11", "mia1": "Mi A1","mia2": "Mi A2", "note10promax": "Note 10 ProMax", "note10pro": "Note 10 Pro", "note10s": "Redmi Note 10S", "note10": "Redmi Note 10", "redmi10": "Redmi 10",
     "note5pro": "Note 5 Pro", "realme5pro": "Realme 5 Pro", "5pro": "Note 5 Pro", "pocof3gt": "Poco F3 GT", "pocof3": "Poco F3", "pocof4gt": "Poco F4 GT", 
     "redmik40": "Redmi K40", "pocof4": "Poco F4", "redmik50g": "Redmi K50G", "redmik50": "Redmi K50", "m2pro": "Poco M2 Pro", "m3pro": "Poco M3 Pro", "pocom3": "Poco M3", "pocom5s": "Poco M5s",
     "pocox3pro": "Poco X3 Pro", "pocox3gt": "Poco X3 GT", "pocox3": "Poco X3", "pocox4pro5g": "Poco X4 Pro 5G", "x4pro5g": "Poco X4 Pro 5G", "note9promax": "Note 9 ProMax", "note9pro": "Note 9 Pro", "note9s": "Redmi Note 9S", "note9": "Redmi Note 9", "redmi9t": "Redmi 9T", "redmi9": "Redmi 9",
     "note7pro": "Note 7 Pro", "10x4g": "Redmi 10X 4G", "note7s": "Redmi Note 7S", "note7": "Redmi Note 7", "note8pro": "Note 8 Pro", "note8t": "Redmi Note 8T", "note8": "Redmi Note 8", "note11s": "Redmi Note 11S",
    "note11": "Redmi Note 11", "xiaomi12": "Xiaomi 12", "f2pro": "Poco F2 Pro",
    "mi9": "Mi9", "redmi5": "Redmi 5", "redmi9c": "Redmi 9C", "xiaomi12tpro": "Xiaomi 12T Pro", "xiaomi12x": "Xiaomi 12X"}
    
copy_data = {}



left_notch = {}
right_notch = {}


@bot.on_message(filters.command(["autopaste"]) & filters.user(int(OWNER)))
def cp(client, message):
         user_id=message.from_user.id
         if not copy_data.get(user_id):
             copy_data.update({user_id: "turned on"})
             message.reply_text("Autopaste: `OFF`")
         else:
             copy_data.pop(user_id)
             message.reply_text("Autopaste: `ON`")

@bot.on_message(filters.command(["p", "paste"], ["/", "!"]) & filters.user(ADMINS))
def serch(client, m):
    name = copy_data.get(1)
    if not name:
       name = "Clipboard is empty."
  #  if m.reply_to_message and m.reply_to_message.from_user.id == BOT_ID:
         
    m.reply_text(name)
  
    
@bot.on_message(filters.command(["c", "copy"], ["/", "!"]) & filters.user(ADMINS))
def serch(client, m):
    err = ""
    try:
       m.delete()
    except:
       pass
    if not m.reply_to_message:       
       return
    if m.reply_to_message.text:      
        strs = m.reply_to_message.text
    elif m.reply_to_message.caption:
        strs = m.reply_to_message.caption 
    else:
        return
    strs1 = ""
    if len(m.command) > 1:
        strs1=m.text.split(" ", 1)[1]
   
    strs = strs + str(strs1)
    strsP = strs + str(strs1)
    version = None
    okk=re.compile(r'(\d{1,2}\.\d{1,2}\.\d{1,2})|(\d{1,2}\.\d{1,2}\.\d{1,2}\.\d{0,2})')
    for i in okk.finditer(strs):
       version = i.group(0)
       break
    if not version:
        err += "Error finding version code.\n"
    
    strs = strs.replace(" ", "")
    strs = strs.replace(" ", "")
    device = None
    
    for j in roms:
       if j in strs.lower():                      
           device1 = j      
           break
           
    else:
        err += "Error finding device name\n"
    
    device = roms_dict.get(device1)
    strs=strs.replace(device1, "")
    base = None
    if "eu" in strs.lower():
        base = "EU"
    elif "cn" in strs.lower():
        base = "CN"
    elif "eea" in strs.lower():
        base = "EU"
    elif "vn" in strs.lower():
        base = "VN"    
    elif "india" in strsP.lower():
        base = "IN"
    elif "vietsub" in strs.lower():
        base = "VN"
    elif "ru" in strs.lower():
        base = "RU"
    elif "sr" in strs.lower():
        base = "SR"
    elif "global" in strs.lower():
        base = "Global"
    elif "miuipro" in strs.lower():
        base = "MiuiPro"
    elif "china" in strs.lower():
        base = "CN"
    
    elif "in" in strsP.lower():
        base = "IN"
    elif "mi" in strsP.lower():
        base = "Global"
    elif "id" in strsP.lower():
        base = "ID"
    

    if not base:
       err += "Error finding base\n"
    av = None
    if "a11" in strs.lower() or "android11" in strs.lower():
        av = "A11"
    elif "a12" in strs.lower() or "android12" in strs.lower():
        av = "A12"
    else:
       av = "A12"
        
    try:
      if base and version and av and device:
        full_name = f"{base} {version} {av} ({device})"
        copy_data.update({1: full_name})
        print(full_name)
        if not copy_data.get(int(OWNER)):
             pas = client.send_message(MIUI_CHAT1, f"<code>{full_name}</code>", parse_mode="html")
             det = datetime.datetime.now(tz)+timedelta(seconds=60)
             sj.add_job(del_mes, "date", run_date=det, args=[
                f"{MIUI_CHAT1}_{pas.message_id}"], id=f"{MIUI_CHAT1}_{pas.message_id}_del")

      else:
         client.send_message(MIUI_CHAT1, f"{m.from_user.mention}\n{err}")
                               
    except Exception as e:
        client.send_message(MIUI_CHAT1, f"{m.from_user.mention}\n{e}")

@bot.on_message(filters.command(["re"], ["/", "!"]) & filters.chat([MIUI_CHAT1, MIUI_CHAT1]))
async def done(client, message):       
        try:
            ok = await message.reply_text("processing ..")
            id = message.reply_to_message.document.file_id
            if not " " in message.text:
                new_name = (str(copy_data.get(1))[1:-24]).strip()
                copy_data.pop(1)
            else:
                 new_name = (message.text.split(' ',1)[1]).strip()     
              
            file_name = message.reply_to_message.document.file_name
            await client.download_media(id, file_name=file_name)
            

            os.rename(f'downloads/{file_name}',  f"{new_name} @dualstatusbarMiui.zip")
            reply = await message.reply_document(f"{new_name} @dualstatusbarMiui.zip", caption= f"Renamed [This zip]({message.reply_to_message.link})\n`{new_name} @dualstatusbar.zip`")
            filename = f"{new_name} @dualstatusbarMiui.zip"
                                              
            await check_check(message, filename, reply.message_id)
                        
        except Exception as cd:
            await message.reply_text(str(cd))
        finally:
            await ok.delete()

        
@bot.on_message(filters.command(["list", "l"]) & filters.user(ADMINS))
def serch(client, message):
    qwe = message.reply_text("Processing ")
    if len(message.command) < 2:
        qwe.edit("No name given !")
        return     

    try:
        service = gdrive_service()
        with open("roms.txt") as red:
               romname = json.load(red)    
        name = message.text.split(" ",1)[1]
        fq = re.search(r'\(([^\(]*)\)', name)
        if fq:
           trigger = (fq.group(0)[1:-1]).strip()
           trigger = trigger.replace(" ", "").lower()
           trigger = trigger.replace(" ", "").lower()
           with open("roms.txt") as red:
               romname = json.load(red)              
           try:
              parent_id = romname[trigger]
           except:
              qwe.edit(f"folder not found for `{trigger}`")
              return        
        else:         
           trigger = (name.replace(" ", "")).lower()
           with open("roms.txt") as red:
               romname = json.load(red)              
           try:
              parent_id = romname[trigger]
           except:
              qwe.edit(f"folder not found for `{trigger}`")
              return        
        query = f"parents = '{parent_id}'"
        res = service.files().list(q=query).execute()
        files = res.get("files")
        file_name = ""
        
        if files:
           for file in files:             
               fname = str(file["name"])
               file_name += f"**>>** `{fname}`\n"
           if message.chat.id == MIUI_CHAT:
               qwe.edit(f"**Search result**:\n{file_name}", disable_web_page_preview=True)
           else:
              qwe.edit(f"[Search result:](https://drive.google.com/drive/folders/{parent_id})\n{file_name}", disable_web_page_preview=True)
        else:
          qwe.edit("No files found")
    except Exception as e:
               qwe.edit(str(e))

@bot.on_message(filters.command(["done", "d"]) & filters.user(ADMINS))
def d(client, message):
    if message.reply_to_message:
         bot.send_message(message.chat.id, "The module is ready, [Download it here](dualstatusbar.in/miui)\nSend screenshot of about phone section after flashing*", reply_to_message_id=message.reply_to_message.message_id)
         message.delete()
         
@bot.on_message(filters.command(["delete","remove"]) & filters.user(ADMINS))
def serch(client, message):
    qwe = message.reply_text("Processing ")
    if len(message.command) < 2:
        qwe.edit("No name given !")
        return 
    
    try:
        service = gdrive_service()
        with open("roms.txt") as red:
               romname = json.load(red)    
        name = message.text.split(" ",1)[1]
        fq = re.search(r'\(([^\(]*)\)', name)
        if fq:
           trigger = (fq.group(0)[1:-1]).strip()
           trigger = trigger.replace(" ", "").lower()
           trigger = trigger.replace(" ", "").lower()
           with open("roms.txt") as red:
               romname = json.load(red)              
           try:
              parent_id = romname[trigger]
           except:
              qwe.edit(f"folder not found for `{trigger}`")
              return        
        else:                    
              qwe.edit(f"folder not found for `{trigger}`")
              return        
        query = f"parents = '{parent_id}'"
        res = service.files().list(q=query).execute()
        files = res.get("files")
        
        if files:
           for file in files:
                fname = (files[0]["name"]).lower().strip()
                if fname == name.lower().strip():           
                   fileId = (files[0]).get("id")
                   try:
                       service.files().delete(fileId=fileId).execute()
                       qwe.edit(f"**successfully deleted the file:**\n`{name}`")
                       hokey = True 
                   except Exception as e:
                       qwe.edit(str(e))
                   break 
                else:
                   hokey = None
           if not hokey:
                qwe.edit(f"**Unable to get the file:**\n`{name}`")
           
    except Exception as e:
               qwe.edit(str(e))

@bot.on_message(filters.command(["search", "s"], ["/", "!"]))
def serch(client, message):
    qwe = message.reply_text("Processing ")
    if len(message.command) < 3:
        qwe.edit("Wrong format!\n`/search <version_code> <device_name>`", parse_mode="md")
        return 
    
    try:
        service = gdrive_service()
        with open("roms.txt") as red:
               romname = json.load(red)    
               
        name = message.text.split(" ",1)[1]
        fq = re.search(r'\(([^\(]*)\)', name)
        if fq:
           trigger = (fq.group(0)[1:-1]).strip()
           trigger = trigger.replace(" ", "").lower()
           trigger = trigger.replace(" ", "").lower()
           with open("roms.txt") as red:
               romname = json.load(red)              
           try:
              parent_id = romname[trigger]
           except:
              qwe.edit(f"folder not found for `{trigger}`")
              return        
        else:         
           triggerp = name.split(' ',1)[1]
           trigger = (triggerp.replace(" ", "")).lower()
           with open("roms.txt") as red:
               romname = json.load(red)              
           try:
              parent_id = romname[trigger]
           except:
              qwe.edit(f"folder not found for `{triggerp}`")
              return        
        query = f"parents = '{parent_id}'"
        res = service.files().list(q=query).execute()
        files = res.get("files")
        files_list = ""
        if not files:
             qwe.edit("Not found !")
             return 
        for i in files:
             iname = i["name"]
             if (message.command[1]).lower() in (iname).lower():
               files_list += ">> `" + str(i["name"]) + "`\n"
        
        if files_list:       
            if message.chat.id == MIUI_CHAT:
                qwe.edit(f"**[DSB available in website](dualstatusbar.in/miui)**\n{files_list}", disable_web_page_preview=True)
            else:
                qwe.edit(f"[Results:](https://drive.google.com/drive/folders/{parent_id})\n{files_list}", disable_web_page_preview=True)
        else:
           qwe.edit("File not found .")

        
    except Exception as e:
        qwe.edit(str(e))
        
        
        


@bot.on_message(filters.command(["drive"]) & filters.user(ADMINS))
def main(client, m):
    if m.reply_to_message and m.reply_to_message.document:
            pass        
    else:
         m.reply_text("Reply to a document to upload!")
         return 
    qwe = m.reply_text("Downloading.. ")
    o = m.reply_to_message.download()
    
    filename = m.reply_to_message.document.file_name    
    
    fq = re.search(r'\(([^\(]*)\)', filename)
    if fq:
           trigger = (fq.group(0)[1:-1]).strip()
           trigger = trigger.replace(" ", "").lower()
           trigger = trigger.replace(" ", "").lower()
           with open("roms.txt") as red:
               romname = json.load(red)              
           try:
              parent_id = romname[trigger]
           except:
              qwe.edit(f"folder not found for `{trigger}`")
              return        
    else:
        qwe.edit("Unable to get folder name !")
        return 
            

    try:
        service = gdrive_service()
        
        folder_id = parent_id
        file_metadata = {
        "name": filename,
        "parents": [folder_id]
    }
        media = MediaFileUpload(f"./downloads/{filename}", resumable=True)
        file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()        
        qwe.edit(f"Successfully uploaded the file")
        
    except Exception as e:
        qwe.edit(str(e))
    os.system(f"""rm -rf downloads/"{filename}" """)




@bot.on_message(filters.command(["drive"]) & filters.user(ADMINS))
def main(client, m):
    if m.reply_to_message and m.reply_to_message.document:
            pass        
    else:
         m.reply_text("Reply to a document to upload!")
         return 
    qwe = m.reply_text("Downloading.. ")
    o = m.reply_to_message.download()
    
    filename = m.reply_to_message.document.file_name    
    
    fq = re.search(r'\(([^\(]*)\)', filename)
    if fq:
           trigger = (fq.group(0)[1:-1]).strip()
           trigger = trigger.replace(" ", "").lower()
           trigger = trigger.replace(" ", "").lower()
           with open("roms.txt") as red:
               romname = json.load(red)              
           try:
              parent_id = romname[trigger]
           except:
              qwe.edit(f"folder not found for `{trigger}`")
              return        
    else:
        qwe.edit("Unable to get folder name !")
        return 
            

    try:
        service = gdrive_service()
        
        folder_id = parent_id
        file_metadata = {
        "name": filename,
        "parents": [folder_id]
    }
        media = MediaFileUpload(f"./downloads/{filename}", resumable=True)
        file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()        
        qwe.edit(f"Successfully uploaded the file")
        
    except Exception as e:
        qwe.edit(str(e))
    os.system(f"""rm -rf downloads/"{filename}" """)











import os
from urllib.parse import quote

async def carbon(code):
   text = code
   url = f"https://api.safone.tech/carbon?code={quote(text)}"
   return url

@bot.on_message(filters.command(["karbon"])  & filters.user(ADMINS))
async def carbonn(bot, message):    
    ok = await message.reply_text("`Making Carbon...`") 
    code = None

    if message.reply_to_message:
          if message.reply_to_message.caption:
               code = message.reply_to_message
          elif message.reply_to_message.text:
              code = message.reply_to_message.text
    elif len(message.command) > 1:
        code = message.text.split(" ",1)[1]
                  
    if not code:
           return await ok.edit("`Nothing To Carbonize...`")
           
    carbon_url = await carbon(code)
    if message.from_user:
        user = message.from_user.mention
    else:
        user = message.sender_chat.title
 
    await message.reply_document(carbon_url)
    await ok.delete()


##### 

          
async def check_check(message, filename, mid):
    CLIENT_SECRET_FILE = "client_secrets.json"
    API_SERVICE_NAME = "drive"
    API_VERSION = "v3"
    SCOPES = ['https://www.googleapis.com/auth/drive.metadata.readonly',
          'https://www.googleapis.com/auth/drive.file']
    cred = None

    pickle_file = f'token_{API_SERVICE_NAME}_{API_VERSION}.pickle'
    # print(pickle_file)

    if os.path.exists(pickle_file):
        with open(pickle_file, 'rb') as token:
            cred = pickle.load(token)

    if not cred or not cred.valid:
        if cred and cred.expired and cred.refresh_token:
            cred.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
            cred = flow.run_local_server()

        with open(pickle_file, 'wb') as token:
            pickle.dump(cred, token)

    try:
        service = build(API_SERVICE_NAME, API_VERSION, credentials=cred)
        with open("roms.txt") as red:
               romname = json.load(red)    
               
        name = filename 
        fq = re.search(r'\(([^\(]*)\)', name)
        if fq:
           trigger = (fq.group(0)[1:-1]).strip()
           trigger = trigger.replace(" ", "").lower()
           trigger = trigger.replace(" ", "").lower()
           with open("roms.txt") as red:
               romname = json.load(red)              
           try:
              parent_id = romname[trigger]
           except:
              await message.reply_text(f"folder not found for `{trigger}`")
              return        
        else:         
           trigger = ((name.split(' ',1)[1]).replace(" ", "")).lower()
           with open("roms.txt") as red:
               romname = json.load(red)              
           try:
              parent_id = romname[trigger]
           except:
              await message.reply_text(f"folder not found for `{trigger}`")
              return        
        if "A11" in name:
            version = (name.split("A11")[0]).lower()
        elif "A12" in name:
            version = (name.split("A12")[0]).lower()
        elif "a12" in name:
            version = (name.split("a12")[0]).lower()
        elif "a11" in name:
            version = (name.split("a11")[0]).lower()
        elif "a13" in name:
            version = (name.split("a13")[0]).lower()
        elif "A13" in name:
            version = (name.split("A13")[0]).lower()
        else:
           version = None
           await message.reply_text(f"Android version is quite incorrect, isn't it?")
           return 
        query = f"parents = '{parent_id}'"
        res = service.files().list(q=query).execute()
        files = res.get("files")
        files_list = ""
        if files:             
          for i in files:
             iname = i["name"]
             if version in iname.lower():
               files_list += ">> `" + str(i["name"]) + "`\n"
        
        if len(files_list) > 1:
            files_list = "**Found something:**\n" + files_list
        else:
           files_list = "File not available in gdrive\nTap the button to upload!"
        serbtn = InlineKeyboardMarkup([
             [InlineKeyboardButton(
             text=f"Upload to gdrive", callback_data=f"{trigger}up_file"), InlineKeyboardButton(
        text=f"Cancel", callback_data="cancel")]])
        await bot.send_message(chat_id=message.chat.id, text=f"`{filename}`\n{files_list}", reply_markup=serbtn, reply_to_message_id=mid)

        
    except Exception as e:
        await message.reply_text(str(e))





      
@bot.on_message(filters.command(["nuke"]) & filters.chat([MIUI_CHAT1, MIUI_CHAT1]))
def nuke(client, message):
      os.system("rm -rf down/*")
      os.system("rm -rf downloads/*")
      os.system("rm -rf *@dualstatusbarMiui.zip")
      message.reply_text("Done")
      
@bot.on_message(filters.command(["done"]) & filters.chat([MIUI_CHAT1, MIUI_CHAT1]))
def done(client, message):
            msg = message.text
            string = msg.split(' ')[1]
            sls = string.rfind('/')
            slsl = int(sls) + 1
            msgid = string[slsl:]
          
            string1 = string.replace(string[sls:], "")
        
            sls = string1.rfind('/')
            slsl = int(sls) + 1
            chat_id = string1[slsl:]
               
            try:
               chat_id1 = int(chat_id)
               chat_id = f"-100{chat_id1}"
            except:
               chat_id = f"@{chat_id}"              
            print(chat_id)     
            if chat_id:
                    test = f"The module is ready, [Download it here](dualstatusbar.in/miui)\nSend screenshot pf about phone section after flashing*"
                    try:
                        bot.send_message(chat_id=chat_id, reply_to_message_id=int(msgid),
                                                text=test)
                        message.reply_text("success !")
                    except Exception as e:
                        uh = message.reply_text(str(e))
        
@bot.on_message(filters.command(["xml"]))
def down(client, message):
    if str(message.from_user.id) == OWNER:
        try:
            id = message.reply_to_message.document.file_id
            main_link = message.message_id
            qwe = message.reply_text("Downloading..")
            if ".zip" in str(message.reply_to_message.document.file_name).lower():
                ui_done = client.download_media(message.reply_to_message.document.file_id, file_name=f"downloads/xy{main_link}/systemui.zip")  
                os.system(f"cd downloads/xy{main_link} && unzip -o systemui.zip")     
                if os.path.isfile(f"downloads/xy{main_link}/SystemUI.apk"):
                     os.system(f"cd downloads/xy{main_link} && mv -f SystemUI.apk MiuiSystemUI.apk")
            else:
                ui_done = client.download_media(message.reply_to_message.document.file_id, file_name=f"downloads/xy{main_link}/MiuiSystemUI.apk")              
            qwe.edit("File downloaded .. !")
            os.system(f"cp -f downloads/xy{main_link}/MiuiSystemUI.apk downloads/xy{main_link}/test.zip")
            os.system(f"cd downloads/xy{main_link} && unzip -d . test.zip res/layout/*system_icons.xml")     
            if os.path.isfile(f"downloads/xy{main_link}/res/layout/system_icons.xml"):
                upDis(f"downloads/xy{main_link}/res/layout/system_icons.xml", message.chat.id, int(main_link)) 
            elif os.path.isfile(f"downloads/xy{main_link}/res/layout/miui_system_icons.xml"):
                upDis(f"downloads/xy{main_link}/res/layout/miui_system_icons.xml", message.chat.id, int(main_link)) 
                
            os.system(f"cd downloads/xy{main_link} && unzip -d . test.zip res/layout/*status_bar.xml")      
            if os.path.isfile(f"downloads/xy{main_link}/res/layout/status_bar.xml"):
                upDis(f"downloads/xy{main_link}/res/layout/status_bar.xml", message.chat.id, int(main_link)) 
            elif os.path.isfile(f"downloads/xy{main_link}/res/layout/miui_status_bar.xml"):
                upDis(f"downloads/xy{main_link}/res/layout/miui_status_bar.xml", message.chat.id, int(main_link)) 
            
        except Exception as cd:
            message.reply_text(str(cd))
        qwe.delete()
        os.system(f"rm -rf downloads/xy{main_link}")
        
        
        
        
@bot.on_message(filters.command(["debloat"]))
def down(client, message):
    if str(message.from_user.id) == OWNER:
        try:
            id = message.reply_to_message.document.file_id
            main_link = message.message_id
            qwe = message.reply_text("Downloading..")
          #  os.system(f"mkdir -p downloads/xy{main_link}")
            if ".zip" in str(message.reply_to_message.document.file_name).lower():
                ui_done = client.download_media(message.reply_to_message.document.file_id, file_name=f"downloads/xy{main_link}/systemui.zip")  
                os.system(f"cd downloads/xy{main_link} && unzip -o systemui.zip")     
                if os.path.isfile(f"downloads/xy{main_link}/SystemUI.apk"):
                     os.system(f"cd downloads/xy{main_link} && mv -f SystemUI.apk MiuiSystemUI.apk")
            else:
                ui_done = client.download_media(message.reply_to_message.document.file_id, file_name=f"downloads/xy{main_link}/MiuiSystemUI.apk")              
            qwe.edit("File downloaded .. !")
            
            os.system(f"mv -f downloads/xy{main_link}/MiuiSystemUI.apk downloads/xy{main_link}/test.zip")            
            os.system(f"cd downloads/xy{main_link} && unzip -d . test.zip res/layout/*")     
            os.system(f"cd downloads/xy{main_link} && unzip -d . test.zip resources.arsc")     
            os.system(f"cd downloads/xy{main_link} && unzip -d . test.zip AndroidManifest.xml")     
            os.system(f"cd downloads/xy{main_link} && unzip -d . test.zip META-INF/*")     
          #  os.system(f"cd downloads/xy{main_link} && unzip -d . test.zip *.dex")     
            
            os.system(f"cd downloads/xy{main_link} && zip -r -9 SystemUI.apk res resources.arsc AndroidManifest.xml META-INF")
            os.system(f"cd downloads/xy{main_link} && zip -m -9 SystemUI.zip SystemUI.apk")
            qwe.edit("Uploading..")
            upDis(f"downloads/xy{main_link}/SystemUI.zip", message.chat.id, int(main_link)) 
                
            
        except Exception as cd:
            message.reply_text(str(cd))
        qwe.delete()
        os.system(f"rm -rf downloads/xy{main_link}")
        
@bot.on_message(filters.command(["down"]))
async def down(client, message):
    if str(message.from_user.id) == OWNER:
        try:        
            await message.reply_to_message.download()
            
            await message.reply_text("Done !")
        except Exception as cd:
            await message.reply_text(str(cd))

@bot.on_message(filters.command(["up"]))
async def upp(client, message):
    if str(message.from_user.id) == OWNER:
         
        try:
            await client.send_document(chat_id=message.chat.id, document=str(message.text.split(' ', 1)[1]))
            await message.reply_text("Done !")
        except Exception as e:
            await message.reply_text(str(e))
            

@bot.on_message(filters.command(["module"]) & filters.chat(MIUI_CHAT1))
def up(client, message):
    
           try:
               mes_num = (message.reply_to_message.caption.markdown).split("\n")[1].split("](")[1].split("/")[5][:-1]
               bot.copy_message(message.chat.id, MIUI_BARN, int(mes_num))
           except Exception as e:
              message.reply_text(str(e))
           return    


from os import environ, execle, path, remove

@bot.on_message(filters.command(["restart"]))
async def restart(client, message):
    if message.sender_chat:
        user_id = message.sender_chat.id
    else:
        user_id = message.from_user.id
    if int(user_id) == 1602293216:
      ht = await message.reply_text(f"`ʀᴇsᴛᴀʀᴛɪɴɢ 🔁`")
      mid = ht.message_id
      chat_id = message.chat.id
      with open("re.txt", "w+") as rd:
        rd.write(f"{chat_id}_{mid}")
      args = [sys.executable, "dsb.py"]
      execle(sys.executable, *args, environ)  
      exit()
      return

   

keyboard = InlineKeyboardMarkup([
    [InlineKeyboardButton(
        text=f"1)A11 S", callback_data="small"), InlineKeyboardButton(
        text=f"2)A11 B", callback_data="small_f1"), InlineKeyboardButton(
        text=f"3)A11 L", callback_data="left"), InlineKeyboardButton(
        text=f"4)A11 R", callback_data="right")],
    [InlineKeyboardButton(
        text=f"5)1.3 S", callback_data="small_1.3"), InlineKeyboardButton(
        text=f"6)1.3 B", callback_data="poco_1.3"), InlineKeyboardButton(
        text=f"7)1.3 L", callback_data="left_1.3"), InlineKeyboardButton(
        text=f"8)1.3 R", callback_data="right_1.3")],
    [InlineKeyboardButton(
        text=f"9)1.85 S", callback_data="small_d"), InlineKeyboardButton(
        text=f"10)1.85 B", callback_data="big_d"), InlineKeyboardButton(
        text=f"11)1.85 L", callback_data="left_d"), InlineKeyboardButton(
        text=f"12)1.85 R", callback_data="right_d")],

    [InlineKeyboardButton(
        text=f"13)A12 S", callback_data="a12_small"), InlineKeyboardButton(
        text=f"14)A12 B", callback_data="a12_big"), InlineKeyboardButton(
        text=f"15)A12 L", callback_data="a12_left"), InlineKeyboardButton(
        text=f"16)A12 R", callback_data="a12_right")],

    [InlineKeyboardButton(
        text=f"17)0.95 S", callback_data="a12_22323"), InlineKeyboardButton(
        text=f"18)0.95 B", callback_data="a12_22324"), InlineKeyboardButton(
        text=f"19)0.95 L", callback_data="a12_22325"), InlineKeyboardButton(
        text=f"20)0.95 R", callback_data="a12_22326")],
    [InlineKeyboardButton(
        text=f"21)1.05 S", callback_data="a12_09s"), InlineKeyboardButton(
        text=f"22)1.05 B", callback_data="a12_09b"), InlineKeyboardButton(
        text=f"23)1.05 L", callback_data="a12_09l"), InlineKeyboardButton(
        text=f"24)1.05R", callback_data="a12_09r")],
    [InlineKeyboardButton(
        text=f"---------CANCEL ALL------", callback_data="cancell")]


])



keyboard1 = InlineKeyboardMarkup([
    [InlineKeyboardButton(
        text=f"Small", callback_data="small"), InlineKeyboardButton(
        text=f"Big", callback_data="small_f1")],
    [InlineKeyboardButton(
        text=f"Left", callback_data="left"), InlineKeyboardButton(
        text=f"Right", callback_data="right")],
    [InlineKeyboardButton(
        text=f"CANCEL", callback_data="cancell")]
    ])


keyboard2 = InlineKeyboardMarkup([
    [InlineKeyboardButton(
        text=f"Small", callback_data="small_1.3"), InlineKeyboardButton(
        text=f"Big", callback_data="poco_1.3")],
    [InlineKeyboardButton(
        text=f"Left", callback_data="left_1.3"), InlineKeyboardButton(
        text=f"Right", callback_data="right_1.3")],
    [InlineKeyboardButton(
        text=f"CANCEL", callback_data="cancell")]
    ])
    
    
    
keyboard3 = InlineKeyboardMarkup([
    [InlineKeyboardButton(
        text=f"Small", callback_data="small_d"), InlineKeyboardButton(
        text=f"Big", callback_data="big_d")],
    [InlineKeyboardButton(
        text=f"Left", callback_data="left_d"), InlineKeyboardButton(
        text=f"Right", callback_data="right_d")],
    [InlineKeyboardButton(
        text=f"CANCEL", callback_data="cancell")]
    ])
    
        
keyboard4 = InlineKeyboardMarkup([
    [InlineKeyboardButton(
        text=f"Small", callback_data="a12_small"), InlineKeyboardButton(
        text=f"Big", callback_data="a12_big")],
    [InlineKeyboardButton(
        text=f"Left", callback_data="a12_left"), InlineKeyboardButton(
        text=f"Right", callback_data="a12_right")],
    [InlineKeyboardButton(
        text=f"CANCEL", callback_data="cancell")]
    ])
    
                    
keyboard5 = InlineKeyboardMarkup([
    [InlineKeyboardButton(
        text=f"Small", callback_data="a12_22323"), InlineKeyboardButton(
        text=f"Big", callback_data="a12_22324")],
    [InlineKeyboardButton(
        text=f"Left", callback_data="a12_22325"), InlineKeyboardButton(
        text=f"Right", callback_data="a12_22326")],
    [InlineKeyboardButton(
        text=f"CANCEL", callback_data="cancell")]
    ])
    
keyboard6 = InlineKeyboardMarkup([
    [InlineKeyboardButton(
        text=f"Small", callback_data="a12_09s"), InlineKeyboardButton(
        text=f"Big", callback_data="a12_09b")],
    [InlineKeyboardButton(
        text=f"Left", callback_data="a12_09l"), InlineKeyboardButton(
        text=f"Right", callback_data="a12_09r")],
    [InlineKeyboardButton(
        text=f"CANCEL", callback_data="cancell")]
    ])
    
                                                                                                                                                                                                                            
def conv_filter(conversation_level):
    def func(_, __, message):
        return conversations.get(message.from_user.id) == conversation_level

    return filters.create(func, "ConversationFilter")



######
@bot.on_message(filters.command("ping") & filters.user(ADMINS))
async def ping(_, m: Message):
    chat_id = m.chat.id    
    start = time.time()
    replymsg = await m.reply_text("....", quote=True)
    delta_ping = time.time() - start
    await replymsg.edit_text(f"<b>Pong!</b>\n{delta_ping * 1000:.3f} ms")
    return



@bot.on_message(filters.command("smell") & filters.user(ADMINS))
def smell(c,m):
   if m.reply_to_message:        
        m.reply_to_message.reply_text("I smell dsb in your MiuiSystemUI, 🤨 \nDon't spam if you have dsb already, you nub!!")
   m.delete()
    
def execute(client, m):
    if m.text.startswith('$'):
        cmd = m.text[1:]
        tes = m.reply_text('`Processing ...`')
        idk = str(rain(0000000000, 9999999999))

        output=os.system(f"{cmd} > null/{idk}.txt")
        if output or str(output) == "0":
           with open(f"null/{idk}.txt", 'r') as se:
             output = se.read()
        try:
            tes.edit(str(output))
        except Exception as e:
            if str(e) == """Telegram says: [400 MESSAGE_TOO_LONG] - The message text is over 4096 characters (caused by "messages.EditMessage")""":
               tes.delete()
               m.reply_document(f"null/{idk}.txt")
            elif str(e) == """Telegram says: [400 MESSAGE_EMPTY] - The message sent is empty or contains invalid characters (caused by "messages.EditMessage")""":
               tes.edit("Empty output !")
            else:
                tes.edit(str(e))
        finally:
           os.system(f"rm -rf null/{idk}.txt")




def ex(gf: int, yes_or_no, is_sexy: bool, how_cool: str, msg, mname: str, mid: int, cap: str = None):
    path = f"down/{gf}"
    name = str(mname)
    sel = yes_or_no
   
    if "12" in str(how_cool):
        os.system(f"cp -f files/othera12 template/utils/other")
        os.system(f"aapt p -f -M files/a12/AndroidManifest.xml \-I files/121.apk -I {path}/MiuiSystemUI.apk -I files/122.apk -S scripts/xmls/{sel}/ms1/res \-F {path}/dsb1.zip > styles.txt")
        os.system(f"aapt p -f -M files/a12/AndroidManifest.xml \-I files/121.apk -I {path}/MiuiSystemUI.apk -I files/122.apk -S scripts/xmls/{sel}/ms2/res \-F {path}/dsb2.zip >> styles.txt")
        os.system(f"aapt p -f -M files/a12/AndroidManifest.xml \-I files/121.apk -I {path}/MiuiSystemUI.apk -I files/122.apk -S scripts/xmls/{sel}/ms3/res \-F {path}/dsb3.zip > styles.txt")
        os.system(f"aapt p -f -M files/a12/AndroidManifest.xml \-I files/121.apk -I {path}/MiuiSystemUI.apk -I files/122.apk -S scripts/xmls/{sel}/ms4/res \-F {path}/dsb4.zip >> styles.txt")
        os.system(f"aapt p -f -M files/a12/AndroidManifest.xml \-I files/121.apk -I {path}/MiuiSystemUI.apk -I files/122.apk -S scripts/xmls/{sel}/ms5/res \-F {path}/dsb5.zip > styles.txt")
        os.system(f"aapt p -f -M files/a12/AndroidManifest.xml \-I files/121.apk -I {path}/MiuiSystemUI.apk -I files/122.apk -S scripts/xmls/{sel}/ms6/res \-F {path}/dsb6.zip >> styles.txt")
       
    else:
        os.system(f"cp -f files/othera11 template/utils/other")
        os.system(f"aapt p -f -M files/AndroidManifest.xml \-I files/1.apk -I {path}/MiuiSystemUI.apk -I files/2.apk -S scripts/xmls/{sel}/ms1/res \-F {path}/dsb1.zip > styles.txt")
        os.system(f"aapt p -f -M files/AndroidManifest.xml \-I files/1.apk -I {path}/MiuiSystemUI.apk -I files/2.apk -S scripts/xmls/{sel}/ms2/res \-F {path}/dsb2.zip >> styles.txt")
        os.system(f"aapt p -f -M files/AndroidManifest.xml \-I files/1.apk -I {path}/MiuiSystemUI.apk -I files/2.apk -S scripts/xmls/{sel}/ms3/res \-F {path}/dsb3.zip > styles.txt")
        os.system(f"aapt p -f -M files/AndroidManifest.xml \-I files/1.apk -I {path}/MiuiSystemUI.apk -I files/2.apk -S scripts/xmls/{sel}/ms4/res \-F {path}/dsb4.zip >> styles.txt")
        os.system(f"aapt p -f -M files/AndroidManifest.xml \-I files/1.apk -I {path}/MiuiSystemUI.apk -I files/2.apk -S scripts/xmls/{sel}/ms5/res \-F {path}/dsb5.zip > styles.txt")
        os.system(f"aapt p -f -M files/AndroidManifest.xml \-I files/1.apk -I {path}/MiuiSystemUI.apk -I files/2.apk -S scripts/xmls/{sel}/ms6/res \-F {path}/dsb6.zip >> styles.txt")
   
    for i in range(1, 7):       
        os.system(f"mkdir -p {path}/s{i}")    
        os.system(f"cd {path}/ && unzip -d s{i} dsb{i}.zip")
    
    os.system("rm -rf template/*.txt")
    
    # A11
    if how_cool == "small":
        os.system("cp -f files/small template/utils/backup1")
        name = f"{name} A11"
    elif how_cool == "left":
        os.system("cp -f files/left template/utils/backup1")
        name = f"{name} A11"
    elif how_cool == "right":
        os.system("cp -f files/right template/utils/backup1")
        name = f"{name} A11"       
        
        
    # A12    
    elif how_cool == "a12s":
        os.system("cp -f files/smalla12 template/utils/backup1")
        name = f"{name} A12"    
    elif how_cool == "a12b":
        os.system("cp -f files/biga12 template/utils/backup1")
        name = f"{name} A12"
    elif how_cool == "a12l":
        os.system("cp -f files/lefta12 template/utils/backup1")
        name = f"{name} A12"
    elif how_cool == "a12r":
        os.system("cp -f files/righta12 template/utils/backup1")
        name = f"{name} A12"
    elif how_cool == "a120.95" or how_cool == "a121.05":
        os.system("cp -f files/smalla12 template/utils/backup1")
        name = f"{name} A12"
    else:
        bot.send_message(MIUI_CHAT1, "Backup1 isn't available ", reply_to_message_id =msg.message_id)
    
    
    os.system("cd template/utils/ && rm -rf backup2 other")
    os.system("cp -rf files/jairaj1 template/utils/")
    os.system("cp -rf files/jairaj2 template/utils/")
    os.system("cd template/utils && rm -rf jairaj1/MiuiSystemUI/res/layout/*.xml && rm -rf jairaj2/MiuiSystemUI/res/layout/*.xml")
   
    
    if "12" in str(how_cool):
          os.system(f"cd template && touch miuia12")
          os.system(f"cp -rf drawable* template/utils/jairaj1/MiuiSystemUI/res/")
          os.system(f"cp -rf drawable* template/utils/jairaj2/MiuiSystemUI/res/")
          for j in range(1, 7):
               os.system(f"cd {path}/s{j}/res/layout-v22/ && mv -f status_barr.xml status_bar.xml")
    else:
        os.system(f"cd template && rm -f miuia12")
        os.system(f"rm -rf template/utils/jairaj1/MiuiSystemUI/res/drawable-anydpi-v24")
        os.system(f"rm -rf template/utils/jairaj2/MiuiSystemUI/res/drawable-anydpi-v24")
        
    os.system(f"cd {path} && mkdir -p binary/names/ ")
    for k in range(1, 7):
       
       os.system(f"cd {path}/binary && mkdir -p L{k}/res/layout/ R{k}/res/layout/")    
       os.system(f"""cd {path}/binary/names && touch L{k}names.txt R{k}names.txt""")
       os.system(f"cp -f {path}/s{k}/res/layout-v22/* {path}/binary/L{k}/res/layout/")
       os.system(f"cp -f {path}/s{k}/res/layout-v22/* {path}/binary/R{k}/res/layout/")
    
    
    os.system(f"cd {path}/binary && tar -zcvf jaimod *")
    os.system(f"cd {path}/binary && zip -P 698J@i##754Andy##Gonza## jai jaimod")
    os.system(f"cp -f {path}/binary/jai.zip template/binary")
    os.system(f"cp -f new_template/advnames template/")
    os.system(f"rm -rf template/utils/*.apk")
    os.system(f"rm -rf template/system/product/overlay/*.apk")
    
    os.system(f"cp -f {path}/s2/res/layout-v22/* template/utils/jairaj1/MiuiSystemUI/res/layout/")
    os.system(f"cp -f {path}/s3/res/layout-v22/* template/utils/jairaj2/MiuiSystemUI/res/layout/")
  
    os.system(f"cd template/utils && tar -cf other jairaj1 jairaj2")    
    
    if how_cool == "a12l":
        os.system("cp -f files/lefta12 template/utils/backup1")
    elif how_cool == "a12r":
        os.system("cp -f files/righta12 template/utils/backup1")
    elif how_cool == "a12_09" or how_cool == "a12_22323":
        os.system("cp -f files/smalla12 template/utils/backup1")
      #  os.system("cp -f files/righta12 template1/utils/backup1")
    #    os.system("cp -f files/lefta12 template2/utils/backup1")
        
    elif str(how_cool) == "small":
         os.system("cp -f files/small template/utils/backup1")
    elif str(how_cool) == "big":
         os.system("cp -f files/big template/utils/backup1")
    elif str(how_cool) == "right":
         os.system("cp -f files/right template/utils/backup1")
    elif str(how_cool) == "left":
         os.system("cp -f files/left template/utils/backup1")
      
    os.system(f"cd template/utils && rm -rf jairaj1 jairaj2 *.apk *.zip *.xz")
    
    if is_sexy:
         os.system(f"cd template/utils && rm -rf backup2")
    othersize = os.path.getsize("template/utils/other") / 1024
    mesid = msg.message_id
    if int(othersize) < 30:
         bot.send_message(MIUI_CHAT1, "module creation failed ", reply_to_message_id =mesid)
         # return 
    othersize1 = os.path.getsize("template/binary") / 1024
    mesid = msg.message_id - 1
    if int(othersize1) < 7:
         bot.send_message(MIUI_CHAT1, f"Advanced styles creation failed {othersize1:.2f}", reply_to_message_id =mesid)
         # return 
    os.system(f'cd template && zip -r "small@dualstatusbarMiui.zip" * && mv small@dualstatusbarMiui.zip ../"{name} @dualstatusbarMiui.zip"')
    try:
       hm1 = msg.edit_caption(f"{msg.caption.markdown.split('You')[0]}Meking ....")      
       chat_i = msg.chat.id
    except Exception as e:
       print(e)
#    cap = cap.split("\n")[1]
    get_old_link = bot.get_messages(MIUI_CHAT1, int(msg.message_id))
    log_doc = bot.send_document(MIUI_LOG, f"{name} @dualstatusbarMiui.zip", caption=f"{cap}\n{get_old_link.link}")
    
    edit_btn = InlineKeyboardMarkup([
                [InlineKeyboardButton(text=f"Done    [{cap}]", callback_data=f"done_message__{get_old_link.caption}")]])
    wtf_ = hm1.caption.markdown.split('\n')[0]
    edit_old_cap = f"{wtf_}\n[{name} @dualstatusbarMiui.zip]({log_doc.link})"
    hm1.edit_caption(edit_old_cap, reply_markup=edit_btn)
  #  upDis(f"styles.txt", MIUI_CHAT1, int(mesid))    
    

@bot.on_message(filters.text & filters.reply & filters.chat(MIUI_CHAT1))
async def ren(c, m):
   if m.reply_to_message and m.reply_to_message.from_user.id==BOT_ID:
        if (m.reply_to_message.caption.split("\n")[1]).endswith("dualstatusbarMiui.zip") and await check_format(m.text):
             get_link = (str(m.reply_to_message.caption.markdown).split("zip](")[1]).split("\n")[0][:-1]
             get_chat = f"-100{get_link.split('/')[-2]}"
             get_re = await bot.get_messages(int(get_chat), int(get_link.split("/")[-1]))
             one_m = await m.reply_text("Processing ...")
             old_cap_was = m.reply_to_message.caption.markdown
             new_name= f"{m.text} @dualstatusbarMiui.zip"   
             try:
                await m.reply_to_message.edit_caption(f"{old_cap_was}\nRename in progress 🔄", reply_markup=m.reply_to_message.reply_markup)
             finally:
                if not os.path.isfile(f'{get_re.document.file_name}'):                
                    await get_re.download()
                    os.rename(f'downloads/{get_re.document.file_name}',  f"{m.text} @dualstatusbarMiui.zip")
                else:
                   os.rename(f'{get_re.document.file_name}',  f"{m.text} @dualstatusbarMiui.zip")
             need_cap = old_cap_was.split("\n")[0]
             await m.reply_to_message.edit_caption(f"{need_cap}\n[{new_name}]({get_link})", reply_markup=m.reply_to_message.reply_markup)
             await one_m.edit("Still processing ...")
             try:
                await bot.edit_message_media(MIUI_LOG, get_re.message_id, InputMediaDocument(new_name))
             except:
                pass
             try:                
                await bot.edit_message_caption(MIUI_LOG, get_re.message_id, get_re.caption)                
             finally:
                try:
                   await one_m.delete()
                finally:
                   await check_check(one_m, new_name, m.reply_to_message.message_id)
                   await m.delete()
           
        


async def check_format(filename):
        name = filename 
        fq = re.search(r'\(([^\(]*)\)', name)
        if fq:          
           return True
       # elif filename== "/p" and copy_data.get(1):
         #   return True
        else:                    
              return False

def upDis(name, chat_id: int, rmi: int, cap: str = None):
    try:
        bot.send_document(chat_id, name, reply_to_message_id = rmi, caption = cap)
    except Exception as e:
         bot.send_message(chat_id, str(e), reply_to_message_id = rmi)  
         
         
def tmpbtw():
       os.system("cp -f template/utils/*.apk template/system/product/overlay/")
         

#### main ####
format = {}

@bot.on_message(filters.command(["format"]) & filters.user(ADMINS))
def form(client, message):
     user_id=message.from_user.id
     if user_id == int(OWNER):
         if not format.get(user_id):
             format.update({user_id: "all"})
             message.reply_text("Format changed to :- show all buttons.")
         else:
             format.pop(user_id)
             message.reply_text("Format changed to :- show individual buttons.")
        
@bot.on_message(filters.command(["a", "allow"]) & filters.user(ADMINS))
def allow(client, message):
        alperms = message.chat.permissions
        user_id=message.reply_to_message.from_user.id
        chat_id = message.chat.id
        client.restrict_chat_member(chat_id=chat_id,
                                                      user_id=user_id,
                                                      permissions=ChatPermissions(
                                                          can_send_messages=alperms.can_send_messages,
                                                          can_send_media_messages=True,
                                                          can_invite_users=alperms.can_invite_users,
                                                          can_send_polls=alperms.can_send_polls,
                                                          can_change_info=alperms.can_change_info,
                                                          can_pin_messages=alperms.can_pin_messages,
                                                          can_send_other_messages=alperms.can_send_other_messages,
                                                          can_add_web_page_previews=alperms.can_add_web_page_previews)
                                                      )
        message.delete()
        client.send_message(chat_id=chat_id, text="Your restrictions have been removed.\nYou can spam again .", reply_to_message_id=message.reply_to_message.message_id)
        
gandu = {}

@bot.on_message(filters.document & ~filters.edited & filters.chat([MIUI_CHAT, MIUI_CHAT1]))
def make_dbs(client, message):
    if message.document and ("dualstatusbarmiui.zip" in str(message.document.file_name).lower() or "dualstatusbar.zip" in str(message.document.file_name).lower()):
        message.delete()
        message.reply_text(f"Hello retard {message.from_user.mention()}\n Kindly Reboot brain and read /rules You are not allowed to share dsb modules directly, share pling links only, If you are trying to report an issue then you need to share the module name only, The module which you shared is-\n{message.document.file_name}")
        return

    if message.document and (".apk" in str(message.document.file_name).lower() or ".zip" in str(message.document.file_name).lower()):
        
        alperms = message.chat.permissions
        user_id = message.from_user.id
        chat_id = message.chat.id
     
        if user_id not in ADMINS:
             if gandu.get(user_id):             
             
                  tim1 = gandu.get(user_id)
                  if (tim1 + 43200) < int(time):
                      return 
                  else:
                      gandu.update({user_id: int(time.time())})
             else:
                 gandu.update({user_id: int(time.time())})
        check1 = message.reply_text("Verifying MiuiSystemUI ...")        
       # try:
          #  client.restrict_chat_member(chat_id=chat_id,
                                                    #  user_id=user_id,
                                                   #   until_date=int(
                                                       #   time.time()) + (12 * 3600),
                                                  #    permissions=ChatPermissions(
                                                        #  can_send_messages=alperms.can_send_messages,
                                                       #   can_send_media_messages=False,
                                                        #  can_invite_users=alperms.can_invite_users,
                                                       #   can_send_polls=alperms.can_send_polls,
                                                        #  can_change_info=alperms.can_change_info,
                                                       #   can_pin_messages=alperms.can_pin_messages,
                                                       #   can_send_other_messages=alperms.can_send_other_messages,
                                                       #   can_add_web_page_previews=alperms.can_add_web_page_previews)
                                                    #  )
       # except:
          #  pass
        caps = f"[{message.message_id}]({message.link})"
        fs = message.copy(MIUI_CHAT1, caption=caps)
        fs.pin()
        main_link = message.message_id
        b_cap = fs.caption.markdown
        fs.edit_caption(f"{b_cap}\n`Downloading ...`")
        os.system("rm -rf *ui.zip")
        if ".zip" in str(message.document.file_name).lower():
            ui_done = client.download_media(message.document.file_id, file_name=f"down/{main_link}/systemui.zip")  
            os.system(f"cd down/{main_link} && unzip -o systemui.zip")     
            if os.path.isfile(f"down/{main_link}/SystemUI.apk"):
                os.system(f"cd down/{main_link} && mv -f SystemUI.apk MiuiSystemUI.apk")
        else:
            ui_done = client.download_media(message.document.file_id, file_name=f"down/{main_link}/MiuiSystemUI.apk")              
        mname = fs.caption
        
        fs.edit_caption(f"{b_cap}\nFile downloaded !, processing now...")
        os.system(f"cp -f down/{main_link}/MiuiSystemUI.apk down/{main_link}/test.zip")
        os.system(f"cd down/{main_link} && unzip -d . test.zip res/layout/*system_icons.xml")      
        os.system(f"cd down/{main_link} && unzip -d . test.zip DebugProbesKt.bin")        
                    
        #:check_dsb(main_link)
        os.system(f"cd down/{main_link} && unzip -d . test.zip res/layout/*status_bar.xml")      
        if os.path.isfile(f"down/{main_link}/res/layout/miui_status_bar.xml"):
               csize = os.path.getsize(f"down/{main_link}/res/layout/miui_status_bar.xml")                     
               check2 = message.reply_text("**MiuiSystemUI** received and Sent to Admins, Module will only be made if [it's a Valid request](https://t.me/MiuiDSB_Support/47079) and not available in [downloads](dualstatusbar.in/miui) !!", disable_web_page_preview=True )
               check1.delete()
        elif os.path.isfile(f"down/{main_link}/res/layout/status_bar.xml"):
                csize = os.path.getsize(f"down/{main_link}/res/layout/status_bar.xml")                   
                check2 = message.reply_text("**MiuiSystemUI** received and Sent to Admins, Module will only be made if [it's a Valid request](https://t.me/MiuiDSB_Support/47079) and not available in [downloads](dualstatusbar.in/miui) !!", disable_web_page_preview=True )
                check1.delete()
        else:
            message.reply_text("Kindly share your **MiuiSystemUI.apk** or **[SystemUI.zip](https://t.me/dsbaddons/179)** (From addons)\nCheck out `#systemui` note for path.", disable_web_page_preview=True)
            fs.edit_caption(f"{b_cap}\nError in processing the file ..")
            check1.delete()
            gandu.pop(user_id)
            return
        cdsize = int(csize) / 1024 
                   
        if int(cdsize) > 5 and user_id != int(OWNER):
            message.reply_text("I smell dsb in your MiuiSystemUI, 🤨 \nDon't spam if you have dsb already, you nub!!")
            fs.delete()
            check2.delete()
            gandu.pop(user_id)
            return
        try:
            if os.path.isfile(f"down/{main_link}/res/layout/miui_system_icons.xml"):
                Psize = os.path.getsize(f"down/{main_link}/res/layout/miui_system_icons.xml")      
            elif os.path.isfile(f"down/{main_link}/res/layout/system_icons.xml"):
                Psize = os.path.getsize(f"down/{main_link}/res/layout/system_icons.xml")      
            size = int(Psize) / 1024 
            size = "{:.2f}".format(size)
            key_board = keyboard
            if str(size).startswith("1.5"):
                Recommended = "\n(**1-4** options are recommended !)\n"
                key_board = keyboard1
            elif str(size).startswith("1.3") or str(size).startswith("1.29"):
                Recommended = "\n(**5-8** options are recommended !)\n"
                key_board = keyboard2
            elif "1.05" in str(size) or "1.06" in str(size):
                Recommended = "\n(**21-24** options are recommended !)\n"
                key_board = keyboard6
            elif "0.95" in str(size) or "0.94" in str(size):
                Recommended = "\n(**17-20** options are recommended !)\n"
                key_board = keyboard5
            elif "1.1" in str(size):
                 Recommended = "\n(**13-16** options are recommended !)\n"
                 key_board = keyboard4
            elif "1.85" in str(size):
                 Recommended = "\n(**9-12** options are recommended !)\n"
                 key_board = keyboard3
            elif "2.2" in str(size) or "2.3" in str(size) or "3." in str(size):
               #  key_board = None
                 Recommended = "**\nI feel A10 here.**"
                 message.reply_text("**MIUI A10** users plz use our  **Nouvelle substratum** to build Dual status bar !!",
                      reply_markup= InlineKeyboardMarkup([
    [InlineKeyboardButton(text="DOWNLOAD", url="https://t.me/nouvelle_subs/20")],
    [InlineKeyboardButton(text="HOW I CAN BUILD", url="https://t.me/nouvelle_support/3736")],
    [InlineKeyboardButton(text=f"I'M NOOB", url="https://t.me/nouvelle_support/5521")]
    ]))
                 fs.delete()
             
                 if user_id != int(OWNER):
                       return
            else:
                Recommended = "**\nNew xml ig ?**"
              
            if os.path.isfile(f"down/{main_link}/MiuiSystemUI.apk"):
               is_ui = "✅"
            else:
               is_ui = "❌"
            if os.path.isfile(f"down/{main_link}/DevicesAndroidOverlay.apk"):
               is_1 = "✅"
            else:
               is_1 = "❌"
            if os.path.isfile(f"down/{main_link}/DevicesOverlay.apk"):
               is_2 = "✅"
            else:
               is_2 = "❌"
            name = str(mname)          
            
            if format.get(int(OWNER)):
                 key_board = keyboard
            if len(key_board.inline_keyboard) < 5:
                texT = str(size)
#            """`{}`
#MiuiSystemUI.apk : {}            
#DevicesAndroidOverlay.apk : {}
#DevicesOverlay.apk : {}
#Name : '`{}`
#""".format(size, is_ui, is_1, is_2, name)            
               
            else:
                texT = f"{size}\n{Recommended}"
                # """`{}` {}
#MiuiSystemUI.apk : {}            
#DevicesAndroidOverlay.apk : {}
#DevicesOverlay.apk : {}
#Name : '`{}`'
#""".format(size, Recommended, is_ui, is_1, is_2, name)            
            if os.path.isfile(f"down/{main_link}/logs.txt"):
           
                client.send_document(chat_id=message.chat.id, document=f"down/{main_link}/logs.txt", caption =texT, reply_markup=keyboard)
            else:
                fs.edit_caption(f"{b_cap}\n{texT}", reply_markup=key_board)
      
        except Exception as y:
            if str(y) == "local variable 'Psize' referenced before assignment":
                fs.edit_caption(f"{b_cap}\nxmls not found!")
            else:
                fs.edit_caption(f"{b_cap}\n{y}")
   
    else:
       fs.edit_caption("File not found !")





######

@bot.on_callback_query()
def call(client, msg):    
    # print(msg.message.reply_to_message)
    if msg.message.reply_to_message:
       mid = msg.message.reply_to_message.caption
       mname = msg.message.reply_to_message.caption
    else:
       mid = str(msg.message.caption).split("\n")[0]
       mname = mid
    m = msg
    if str(m.data).endswith('up_file'):
             m.message.edit("Processing..")
             try:
                old_t = m.message.reply_to_message.caption.markdown
                m.message.reply_to_message.edit(f"{old_t}\nUpload in progress 🔄 ", reply_markup=m.message.reply_to_message.reply_markup)
             finally:
                 filename = m.message.reply_to_message.caption.split("\n")[1]
             trigger = m.data.split("up_file")[0]
             with open("roms.txt") as red:
                 romname = json.load(red)                    
             folder_id = romname[trigger]
             service = gdrive_service()
             if not os.path.isfile(filename):
                 get_link = (str(m.reply_to_message.caption.markdown).split("](")[1])[:-1]
                 get_chat = f"-100{get_link.split('/')[-2]}"
                 get_re = bot.get_messages(int(get_chat), int(get_link.split("/")[-1]))
                 get_re.download(f"./{filename}")
             file_metadata = {
              "name": filename,
              "parents": [folder_id]
                     }
             media = MediaFileUpload(f"./{filename}", resumable=True)
             file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()        
             m.message.edit(f"Successfully uploaded the file\n`{filename}` to gdrive.")
             os.system(f"rm -rf {filename}")
          #   old_t = m.message.reply_to_message.caption.markdown.split("\n")[0]
             if (m.message.reply_to_message.caption.split("\n")[1]).lower() == filename.lower():
                 m.message.reply_to_message.edit(f"{old_t}\nSuccessfully uploaded ✅", reply_markup=m.message.reply_to_message.reply_markup)
                 m.message.delete()
             else:
                m.message.edit("Filename didn't match\n`{filename}`")
             
    if str(msg.data) == 'cancell':
        os.system("rm -rf down/{mid}")
        msg.edit_message_text('cancelled')
        
    elif str(msg.data) == 'cancel':   
         msg.message.delete()
         
    elif str(msg.data) == 'small':   
        
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 (Small Notch)`\n`processing .` ⚙️")
            print("going to dc rc")
            dc_rc(f"down/{mid}", "a11s")
            ex(mid, 1, False, "small", ca, mname, mid, cap)
         
        except Exception as r:
            msg.edit_message_text(str(r))

    elif str(msg.data) == 'small_f1':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 popo F1  `\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11b")
            ex(mid, 2, True, "big", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))

    elif str(msg.data) == 'right"':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 Right notch `\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11r")
            ex(mid, 3, False, "right", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'left':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 Left notch `\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11l")
            ex(mid, 4, False, "left", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))

    elif str(msg.data) == 'small_1.3':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 1.3 (small) `\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11s")
            ex(mid, 5, False, "small", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'poco_1.3':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 (big Notch)`\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11b")
            ex(mid, 6, True, "big", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'left_1.3':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 (left Notch)`\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11l")
            ex(mid, 7, False, "left", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'right_1.3':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 (right Notch)`\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11r")
            ex(mid, 8, False, "right", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))

    elif str(msg.data) == 'small_d':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 (Small Notch)`\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11s")
            ex(mid, 9, False, "small", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'big_d':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 (Small Notch)`\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11s")
            ex(mid, 9, False, "big", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'left_d':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 (Small Notch)`\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11s")
            ex(mid, 9, False, "left", ca, mname, mid,cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'right_d':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A11 (Small Notch)`\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}", "a11s")
            ex(mid, 9, False, "right", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
            
            
    elif str(msg.data) == 'a12_small':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 (Small Notch)`\n`processing .` ⚙️")          
            print("going to dc rc")
            dc_rc(f"down/{mid}")
            ex(mid, 10, True, "a12s", ca, mname, mid, cap)            
        except Exception as r:
            msg.edit_message_text(str(r))            
    elif str(msg.data) == 'a12_big':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 (poco Notch)`\n`processing ..` ⚙️")
            print("going to dc rc")
            dc_rc(f"down/{mid}")
            ex(mid, 11, True, "a12b", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))

    elif str(msg.data) == 'a12_left':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 (Small Notch)`\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}")
            ex(mid, 10, True, "a12l", ca, mname, mid, cap)        
        except Exception as r:
            msg.edit_message_text(str(r))
            
    elif str(msg.data) == 'a12_right':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 (poco Notch)`\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}")
            ex(mid, 10, True, "a12r", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
            
            
    elif str(msg.data) == 'a12_22323':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            if  os.path.isfile(f"down/{mid}/DebugProbesKt.bin"):
               ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A13 `\n`processing ..` ⚙️")
               dc_rc(f"down/{mid}")
               ex(mid, 16, True, "a12s", ca, mname, mid, cap)
            else:
               ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 1.1 whatever `\n`processing ..` ⚙️")
               dc_rc(f"down/{mid}")
               ex(mid, 13, True, "a12s", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_22324':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            if  os.path.isfile(f"down/{mid}/DebugProbesKt.bin"):
               ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A13 `\n`processing ..` ⚙️")
               dc_rc(f"down/{mid}")
               ex(mid, 16, True, "a12s", ca, mname, mid, cap)
            else:
               ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 1.1 whatever `\n`processing ..` ⚙️")
               dc_rc(f"down/{mid}")
               ex(mid, 15, True, "a12b", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_22325':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            if  os.path.isfile(f"down/{mid}/DebugProbesKt.bin"):
               ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A13 `\n`processing ..` ⚙️")
               dc_rc(f"down/{mid}")
               ex(mid, 16, True, "a12s", ca, mname, mid, cap)
            else:
               ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 1.1 whatever `\n`processing ..` ⚙️")
               dc_rc(f"down/{mid}")
               ex(mid, 13, True, "a12l", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_22326':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            if  os.path.isfile(f"down/{mid}/DebugProbesKt.bin"):
               ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A13 `\n`processing ..` ⚙️")
               dc_rc(f"down/{mid}")
               ex(mid, 16, True, "a12s", ca, mname, mid, cap)
            else:
               ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 1.1 whatever `\n`processing ..` ⚙️")
               dc_rc(f"down/{mid}")
               ex(mid, 13, True, "a12r", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))


    elif str(msg.data) == 'a12_09s':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 0.95 `\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}")
            ex(mid, 12, True, "a12s", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_09b':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 0.95 `\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}")
            ex(mid, 14, True, "a12b", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_09l':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 0.95 `\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}")
            ex(mid, 12, True, "a12l", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_09r':
        try:
            try:
              cap = (msg.message.caption).split("\n")[1]
            except:
              cap = None
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A12 0.95 `\n`processing ..` ⚙️")
            dc_rc(f"down/{mid}")
            ex(mid, 12, True, "a12r", ca, mname, mid, cap)
        except Exception as r:
            msg.edit_message_text(str(r))
            
            
    elif "done_message" in str(msg.data):
        try:
           idm = str(msg.data).split("__")[1].split("\n")[0]
           chat_id = msg.message.chat.id
           mes_id = msg.message.message_id
           for_sec = bot.send_message(text="Select timer :  Default is 15 sec", chat_id = msg.message.chat.id, reply_markup=sche_done, reply_to_message_id=msg.message.message_id)
           det = datetime.datetime.now(tz)+timedelta(seconds=15)
           print(det)           
           mi_id = (msg.message.caption).split('\n')[0]
           sj.add_job(del_mes, "date", run_date=det, args=[
               f"{MIUI_CHAT1}_{for_sec.message_id}_{mi_id}"], id=f"{MIUI_CHAT1}_{for_sec.message_id}_del")
           new_cap = (msg.message.caption.markdown).split("Timer")[0]
           msg.message.edit_caption(f"{new_cap.strip()}\nTimer: 15 sec", reply_markup=msg.message.reply_markup)
           
        except Exception as e:
           msg.edit_message_text(str(e))
           
    elif str(msg.data).startswith("sch_"):
           sss = msg.data.split("_")     
           chat_id = MIUI_CHAT
           user_id = (msg.message.reply_to_message.caption).split("\n")[0]
           if sss[1] == "cancell":
                ifjobs = sj.get_job(f"{chat_id}_{user_id}_e")
                if ifjobs:
                   sj.remove_job(f"{chat_id}_{user_id}_e")
                   msg.answer("Cancelled scheduled message for this user" ,show_alert=True)
                else:
                   msg.answer("There wasn't scheduled msg for this user .", show_alert=True)
                msg.message.delete()
                new_cap = (msg.message.reply_to_message.caption.markdown).split("Timer")[0]
                msg.message.reply_to_message.edit_caption(f"{new_cap}", reply_markup=msg.message.reply_to_message.reply_markup)

           else:              
              add_j(MIUI_CHAT, user_id, sss[1], msg.message.reply_to_message.message_id)
              t_s = int(int(sss[1]) / 3600)
              msg.answer(f"Timer set: {t_s} h", show_alert=True)
              new_cap = (msg.message.reply_to_message.caption.markdown).split("Timer")[0]
              msg.message.reply_to_message.edit_caption(f"{new_cap}\nTimer: {t_s} h", reply_markup=msg.message.reply_to_message.reply_markup)
              msg.message.delete()

               
    elif str(msg.data) == 'post_post':
         user_id = msg.from_user.id
         data = postdb.get(user_id)
         if data:
              qmsg = msg.message.edit("Posting...")
              
              bot.send_photo(MIUI_CHANNEL, caption=mid.markdown, photo = data, parse_mode="md", reply_markup=InlineKeyboardMarkup(
                                                 [
                                                     [InlineKeyboardButton(
                                                        text=f"""Download Dsb""",
                                                         url=f"www.dualstatusbar.in/miui",
                                                     )]]))
              qmsg.edit("Posted successfully ✅")
              postdb.pop(user_id)              
              msg.message.reply_to_message.delete()
         
    elif str(msg.data) == 'post_cancel':
         user_id = msg.from_user.id
         data = postdb.get(user_id)
         if data:
            postdb.pop(user_id)
            msg.message.edit("Post cancelled !")
            msg.message.reply_to_message.delete()
            
    ### old 

@bot1.on_message(conv_filter("name") & filters.chat(MIUI_CHAT3))
def age_handler(client, message):
    if str(message.text) != '/cancell' and not message.document:
        user_infos = infos.get(message.from_user.id)
        message.reply_text('send overlay apk')
        infos.get(message.from_user.id).update({"name": str(message.text)})
        conversations.update({message.from_user.id: 'over'})
        user_inputs.update({message.from_user.id: message.text})
        print(infos)
    else:
        if conversations.get(message.from_user.id):
            conversations.pop(message.from_user.id)
        message.reply_text("cancelled")
        if infos.get(message.from_user.id):
            infos.pop(message.from_user.id)


@bot1.on_message(conv_filter("over") & filters.chat(MIUI_CHAT3))
def age_handler(client, message):
    if message.document or str(message.text) != "/cancell":        
        message.reply_text('sending AndroidOverlay.apk ?')
        if message.document:
            doc = message.document.file_id
            infos.get(message.from_user.id).update({"overlay1": True})
            client.download_media(doc, file_name=f"down/{message.from_user.id}/DevicesAndroidOverlay.apk")
        else:
           infos.get(message.from_user.id).update({"overlay1": False})  
        conversations.update({message.from_user.id: 'next'})      
    else:
        if conversations.get(message.from_user.id):
            conversations.pop(message.from_user.id)
        message.reply_text("cancelled")
        if infos.get(message.from_user.id):
            infos.pop(message.from_user.id)


@bot1.on_message(conv_filter("next") & filters.chat(MIUI_CHAT3))
def age_handler(client, message):
    user_info = infos.get(message.from_user.id)
    id = message.from_user.id
    msg = message
    main_link = id
    if message.document:
        doc1 = message.document.file_id
        client.download_media(doc1, file_name=f"down/{main_link}/DevicesOverlay.apk")
        infos.get(message.from_user.id).update({"overlay2": True})
    else:
        infos.get(message.from_user.id).update({"overlay2": False})
    q = message.reply_text("Processing ..")
    if os.path.isfile(f"down/{main_link}/MiuiSystemUI.apk"):
        q.edit("File downloaded !, processing now...")
        os.system(f"cp down/{main_link}/MiuiSystemUI.apk down/{message.from_user.id}/test.zip")
        os.system(f"cd down/{main_link} && unzip -d . test.zip res/layout/*system_icons.xml")     
      
          #:check_dsb(main_link)
        os.system(f"cd down/{main_link} && unzip -d . test.zip res/layout/*status_bar.xml")      
        if os.path.isfile(f"down/{main_link}/res/layout/miui_status_bar.xml"):
               csize = os.path.getsize(f"down/{main_link}/res/layout/miui_status_bar.xml")      
        elif os.path.isfile(f"down/{main_link}/res/layout/status_bar.xml"):
                csize = os.path.getsize(f"down/{main_link}/res/layout/status_bar.xml")   
        cdsize = int(csize) / 1024   
        if int(cdsize) > 6 and user_id != int(OWNER):
            message.reply_text("I smell dsb in your MiuiSystemUI, 🤨 !!")
            check1.delete()
            return
        try:
            if os.path.isfile(f"down/{main_link}/res/layout/miui_system_icons.xml"):
                Psize = os.path.getsize(f"down/{main_link}/res/layout/miui_system_icons.xml")      
            elif os.path.isfile(f"down/{main_link}/res/layout/system_icons.xml"):
                Psize = os.path.getsize(f"down/{main_link}/res/layout/system_icons.xml")   
            size = int(Psize) / 1024     
               
            if str(size).startswith("1.5"):
                Recommended = "\n(**1-4** options are recommended !)\n"
            elif str(size).startswith("1.3"):
                Recommended = "\n(**5-8** options are recommended !)\n"
            elif "1.05" in str(size):
                Recommended = "\n(**17-20** options are recommended !)\n"
            elif "0.95" in str(size):
                Recommended = "\n(**21-24** options are recommended !)\n"
            elif "1.1" in str(size):
                 Recommended = "\n(**13-16** options are recommended !)\n"
            elif "1.85" in str(size):
                 Recommended = "\n(**9-12** options are recommended !)\n"
            elif "2.2" in str(size):
                 Recommended = "**I feel A10 here.**"
            else:
                Recommended = "**New xml ig ?**"
            size = int(Psize) / 1024       
            if os.path.isfile(f"down/{main_link}/MiuiSystemUI.apk"):
               is_ui = "✅"
            else:
               is_ui = "❌"
            if os.path.isfile(f"down/{main_link}/DevicesAndroidOverlay.apk"):
               is_1 = "✅"
            else:
               is_1 = "❌"
            if os.path.isfile(f"down/{main_link}/DevicesOverlay.apk"):
               is_2 = "✅"
            else:
               is_2 = "❌"
            name = user_info['name']
            texT = """Apk code is `{:.2f}` {}
MiuiSystemUI.apk : {}            
DevicesAndroidOverlay.apk : {}
DevicesOverlay.apk : {}
Name : '`{}`'
""".format(size, Recommended, is_ui, is_1, is_2, name)            
            if os.path.isfile(f"down/{main_link}/logs.txt"):
                q.delete()
                client.send_document(chat_id=message.chat.id, document=f"down/{id}/logs.txt", caption =texT, reply_markup=keyboard)
            else:
                q.edit(texT, reply_markup=keyboard)
      
        except Exception as y:
            q.edit(str(y))
        conversations.pop(message.from_user.id)       
    else:
       q.edit("File not found !")

@bot1.on_message(filters.forwarded & filters.chat(MIUI_CHAT3))
def _(client, message):
    if message.document and str(message.document.file_name).endswith("UI.apk"):
        os.system(f"rm -rf down/{message.from_user.id}")
        if infos.get(message.from_user.id):      
            infos.pop(message.from_user.id)       
        if conversations.get(message.from_user.id):
            conversations.pop(message.from_user.id)
        id = message.from_user.id
        os.system(f"mkdir -p down/{id}")    
        infos.update({message.from_user.id: {"ui": message.document.file_name}})
        s = message.reply_text('`Downloading ...`')        
        os.system("rm -rf *ui.zip")
        ui_done = client.download_media(message.document.file_id, file_name=f"down/{id}/MiuiSystemUI.apk")       
        s.delete()  
        conversations.update({message.from_user.id: "name"})
        message.reply_text('Send info !')
        print(infos)
                

@bot1.on_callback_query()
def call(client, msg):
    mname = infos.get(msg.from_user.id)["name"]
    mid = msg.from_user.id
    sel = "...."
    if str(msg.data) == 'cancell':
        if conversations.get(msg.from_user.id):
            conversations.pop(msg.from_user.id)
        if infos.get(msg.from_user.id):
            infos.pop(msg.from_user.id)
        msg.edit_message_text('cancelled')
        

    elif str(msg.data) == 'small':   
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing .` ⚙️")
            print("going to dc rc")
            dc_rc(f"down/{msg.from_user.id}", "a11s")
            ex(msg.from_user.id, 1, False, "small", ca, mname, mid)         
        except Exception as r:
            msg.edit_message_text(str(r))

    elif str(msg.data) == 'small_f1':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11b")
            ex(msg.from_user.id, 2, True, "big", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))

    elif str(msg.data) == 'right"':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11r")
            ex(msg.from_user.id, 3, False, "right", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'left':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11l")
            ex(msg.from_user.id, 4, False, "left", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))

    elif str(msg.data) == 'small_1.3':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11s")
            ex(msg.from_user.id, 5, False, "small", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'poco_1.3':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11b")
            ex(msg.from_user.id, 6, True, "big", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'left_1.3':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11l")
            ex(msg.from_user.id, 7, False, "left", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'right_1.3':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11r")
            ex(msg.from_user.id, 8, False, "right", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))

    elif str(msg.data) == 'small_d':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11s")
            ex(msg.from_user.id, 9, False, "small", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'big_d':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11s")
            ex(msg.from_user.id, 9, False, "big", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'left_d':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11s")
            ex(msg.from_user.id, 9, False, "left", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'right_d':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}", "a11s")
            ex(msg.from_user.id, 9, False, "right", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
            
            
    elif str(msg.data) == 'a12_small':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing .` ⚙️")          
            print("going to dc rc")
            dc_rc(f"down/{msg.from_user.id}")
            ex(msg.from_user.id, 10, True, "a12s", ca, mname, mid)            
        except Exception as r:
            msg.edit_message_text(str(r))            
    elif str(msg.data) == 'a12_big':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            print("going to dc rc")
            dc_rc(f"down/{msg.from_user.id}")
            ex(msg.from_user.id, 11, True, "a12b", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))

    elif str(msg.data) == 'a12_left':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}")
            ex(msg.from_user.id, 10, True, "a12l", ca, mname, mid)            
        except Exception as r:
            msg.edit_message_text(str(r))
            
    elif str(msg.data) == 'a12_right':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel} `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}")
            ex(msg.from_user.id, 10, True, "a12r", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
            
            
    elif str(msg.data) == 'a12_22323':
        try:
            if os.path.isfile(f"down/{main_link}/DebugProbesKt.bin"):
                   ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A13 {sel}  `\n`processing ..` ⚙️")
                   dc_rc(f"down/{msg.from_user.id}")
                   ex(msg.from_user.id, 16, True, "a12s", ca, mname, mid)
            else:
                 ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
                 dc_rc(f"down/{msg.from_user.id}")
                 ex(msg.from_user.id, 13, True, "a12s", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_22324':
        try:
            if os.path.isfile(f"down/{main_link}/DebugProbesKt.bin"):
                   ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A13 {sel}  `\n`processing ..` ⚙️")
                   dc_rc(f"down/{msg.from_user.id}")
                   ex(msg.from_user.id, 16, True, "a12s", ca, mname, mid)
            else:
                ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
                dc_rc(f"down/{msg.from_user.id}")
                ex(msg.from_user.id, 13, True, "a12b", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_22325':
        try:
            if os.path.isfile(f"down/{main_link}/DebugProbesKt.bin"):
                   ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A13 {sel}  `\n`processing ..` ⚙️")
                   dc_rc(f"down/{msg.from_user.id}")
                   ex(msg.from_user.id, 16, True, "a12s", ca, mname, mid)
            else:
                ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
                dc_rc(f"down/{msg.from_user.id}")
                ex(msg.from_user.id, 13, True, "a12l", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_22326':
        try:
            if os.path.isfile(f"down/{main_link}/DebugProbesKt.bin"):
                   ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ A13 {sel}  `\n`processing ..` ⚙️")
                   dc_rc(f"down/{msg.from_user.id}")
                   ex(msg.from_user.id, 16, True, "a12s", ca, mname, mid)
            else:
                ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
                dc_rc(f"down/{msg.from_user.id}")
                ex(msg.from_user.id, 13, True, "a12r", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))


    elif str(msg.data) == 'a12_09s':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}")
            ex(msg.from_user.id, 12, True, "a12s", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_09b':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}")
            ex(msg.from_user.id, 12, True, "a12b", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_09l':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}")
            ex(msg.from_user.id, 12, True, "a12l", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
    elif str(msg.data) == 'a12_09r':
        try:
            ca = msg.message.edit_caption(f"{msg.message.caption.markdown}\nYou have selected \n`➡️ {sel}  `\n`processing ..` ⚙️")
            dc_rc(f"down/{msg.from_user.id}")
            ex(msg.from_user.id, 12, True, "a12r", ca, mname, mid)
        except Exception as r:
            msg.edit_message_text(str(r))
            

def gdrive_service1():
    CLIENT_SECRET_FILE = "client_secrets1.json"
    API_SERVICE_NAME = "drive"
    API_VERSION = "v3"
    SCOPES = ['https://www.googleapis.com/auth/drive.metadata.readonly',
          'https://www.googleapis.com/auth/drive.file']
    cred = None

    pickle_file = f'token_{API_SERVICE_NAME}_{API_VERSION}1.pickle'
    # print(pickle_file)

    if os.path.exists(pickle_file):
        with open(pickle_file, 'rb') as token:
            cred = pickle.load(token)

    if not cred or not cred.valid:
        if cred and cred.expired and cred.refresh_token:
            cred.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
            cred = flow.run_local_server()

        with open(pickle_file, 'wb') as token:
            pickle.dump(cred, token)

    try:
        service = build(API_SERVICE_NAME, API_VERSION, credentials=cred)
        return service 
    except:
       return None

spt = {}
import time
pb = "█" 
pb1 = "▁"

@bot.on_message(filters.command(["m"]) & filters.user(ADMINS))
async def main(client, m):
    if m.reply_to_message:
            pass        
    else:
         await m.reply_text("Reply to a document to upload!")
         return 
    qwe =await m.reply_text("` Downloading... `")
    newName = None
    if " " in m.text:
        newName = m.text.split(" ",1)[1]
    st = time.time()
    spt.update({2: (st)})
    async def progress(current, total):
        dp1 = f"{current * 100 / total}"          
      
        dp = int(float(dp1))
        et = time.time()
        
        if spt.get(1):
           st = spt.get(1)
     
        else:
           st = spt.get(2)
     
        mt = (et) - (st)
   
        if mt == 0:
           mt = 1
        if spt.get(3):
        
          spe = (current - spt.get(3)) / mt
        else:
            spe = current / mt
        mbps = f"{(spe / 1024) / 1024:.2f}" + " Mbps"
     
        spt.update({1: et})
        spt.update({3: current})
        
        if spt.get(4):
           print(spt.get(4))
        if (spt.get(4) and ((int(time.time()) - spt.get(4)) >= 3)) or not spt.get(4): 
               
         if 7 <= dp <= 12:
            try:                              
               await qwe.edit(f"Downloading  \n[{pb}{pb1}{pb1}{pb1}{pb1}{pb1}{pb1}{pb1}{pb1}{pb1}]  {mbps}")
               spt.update({4: int(time.time())})
            except Exception as e:
             #  print(e)
               pass
         elif 17 <= dp <= 22:
          try:
            await qwe.edit(f"Downloading  \n[{pb}{pb}{pb1}{pb1}{pb1}{pb1}{pb1}{pb1}{pb1}{pb1}]  {mbps}")
            spt.update({4: int(time.time())})
          except Exception as e:
             #  print(e)
               pass
         elif 27 <= dp <= 32:
          try:
            await qwe.edit(f"Downloading  \n[{pb}{pb}{pb}{pb1}{pb1}{pb1}{pb1}{pb1}{pb1}{pb1}]  {mbps}")
            spt.update({4: int(time.time())})
          except Exception as e:
              # print(e)
               pass
         elif 37 <= dp <= 42:
          try:
            await qwe.edit(f"Downloading  \n[{pb}{pb}{pb}{pb}{pb1}{pb1}{pb1}{pb1}{pb1}{pb1}]  {mbps}")
            spt.update({4: int(time.time())})
          except Exception as e:
            #   print(e)
               pass
         elif 47 <= dp <= 52:
          try:
            await qwe.edit(f"Downloading  \n[{pb}{pb}{pb}{pb}{pb}{pb1}{pb1}{pb1}{pb1}{pb1}]  {mbps}")
            spt.update({4: int(time.time())})
          except Exception as e:
             #  print(e)
               pass
         elif 57 <= dp <= 62:
          try:
            await qwe.edit(f"Downloading  \n[{pb}{pb}{pb}{pb}{pb}{pb}{pb1}{pb1}{pb1}{pb1}]  {mbps}")
            spt.update({4: int(time.time())})
          except Exception as e:
              # print(e)
               pass
         elif 67 <= dp <= 72:
          try:
            await qwe.edit(f"Downloading  \n[{pb}{pb}{pb}{pb}{pb}{pb}{pb}{pb1}{pb1}{pb1}]  {mbps}")
            spt.update({4: int(time.time())})
          except Exception as e:
             #  print(e)
               pass
         elif 77 <= dp <= 82:
          try:
            await qwe.edit(f"Downloading  \n[{pb}{pb}{pb}{pb}{pb}{pb}{pb}{pb}{pb1}{pb1}]  {mbps}")
            spt.update({4: int(time.time())})
          except Exception as e:
            #   print(e)
               pass
         elif 87 <= dp <= 92:
          try:
            await qwe.edit(f"Downloading  \n[{pb}{pb}{pb}{pb}{pb}{pb}{pb}{pb}{pb}{pb1}]  {mbps}")
            spt.update({4: int(time.time())})
          except Exception as e:
             #  print(e)
               pass
         elif 97 <= dp <= 100:
          try:
            await qwe.edit(f"Downloading  \n[{pb}{pb}{pb}{pb}{pb}{pb}{pb}{pb}{pb}{pb}]  {mbps}")
            spt.update({4: int(time.time())})
          except Exception as e:
             #  print(e)
               pass
  
    if m.reply_to_message.video:
        filename = m.reply_to_message.video.file_name
  
    elif m.reply_to_message.document:
        filename = m.reply_to_message.document.file_name    
   #sync def prog(current, total):
      #  print("{current * 100 / total:.2f} %")
    o = await m.reply_to_message.download(progress=progress)
    
    if newName:
       os.system(f"""cd downloads && mv -f "{filename}" "{newName}" """)       
    else:
        newName = filename
    parent_id = "16Q-lsM0WKJabqM163N_NkpW-DnDHClCF"
            

    try:
        service = gdrive_service1()
        
        folder_id = parent_id
        file_metadata = {
        "name": newName,
        "parents": [folder_id]
    }
        await qwe.edit("Uploading...")
        media = MediaFileUpload(f"./downloads/{newName}", resumable=True)
        file = service.files().create(supportsTeamDrives=True, body=file_metadata, media_body=media, fields='id').execute()        
        id = file.get("id")
        await qwe.edit(f"Successfully uploaded the file\n`{newName}`\nLink:- https://drive.google.com/file/d/{id}/view?usp=drivesdk")
        os.system(f"""rm -rf downloads/"{newName}" """)

    except Exception as e:
        await qwe.edit(str(e))
 #   



@bot.on_message(filters.user(1602293216))
def sync(client, m):
    if m.text and m.text.startswith('$'):
        execute(client, m)
    
def add_j(chat_id, user_id, secs, old_id):
        ifjobs = sj.get_job(f"{chat_id}_{user_id}_e")
        if ifjobs:
            sj.remove_job(f"{chat_id}_{user_id}_e")
        det = datetime.datetime.now(tz)+timedelta(seconds=int(secs))
        s_job = sj.add_job(kicksch, "date", run_date=det, args=[
            f"{chat_id}_{user_id}_{old_id}"], id=f"{chat_id}_{user_id}_e")
        print(s_job)


def kicksch(infos):      
      print(infos)
      info = str(infos).split('_')
      chat_id = info[0]
      mes_id = int(info[1])
      bot.send_message(MIUI_CHAT, "The module is ready, [Download it here](dualstatusbar.in/miui)\nSend screenshot of about phone section after flashing*", reply_to_message_id=mes_id)
      try:
        msg = bot.get_messages(chat_id=MIUI_CHAT1, message_ids=int(info[2]))     
        new_cap = (msg.caption.markdown).split("Timer")[0] 
        msg.edit_caption(f"{new_cap.strip()}\nTimer: Completed ✅", reply_markup= msg.reply_markup)
        msg.unpin()
      except Exception as e:
         print(e)
         
def del_mes(infos):
      infos = str(infos).split('_')
      chat_id = infos[0]
      mes_id = infos[1]
      try:         
         mes = bot.get_messages(chat_id, int(mes_id))
         ac_mes = mes.reply_to_message
      finally:
         is_deled = bot.delete_messages(chat_id, int(mes_id))
         if is_deled:
             bot.send_message(chat_id = MIUI_CHAT, text="The module is ready, [Download it here](dualstatusbar.in/miui)\nSend screenshot of about phone section after flashing*", reply_to_message_id = int(infos[2]))             
             new_cap = (ac_mes.caption.markdown).split("Timer")[0]
             ac_mes.edit_caption(f"{new_cap.strip()}\nTimer : Completed  ✅", reply_markup=ac_mes.reply_markup)
             ac_mes.unpin()
 
    
bot.start()
bot1.start()
sj.start()
print("started")
try:
        with open("re.txt", "r") as red:
            mid = red.read()
        chat_id = mid.split('_')[0]
        msg_id = mid.split('_')[1]
        bot.edit_message_text(chat_id=chat_id,
                              message_id=int(msg_id), text="Restarted !")
        os.remove("re.txt")
except:
    pass
idle()
bot.stop()
bot1.stop()
