#Scripts by @Jai_08
ui_print " ********************************************************" 
ui_print " 🇩​​​​​🇺​​​​​🇦​​​​​🇱​​​​​ 🇸​​​​​🇹​​​​​🇦​​​​​🇹​​​​​🇺​​​​​🇸​​​​​ 🇧​​​​​🇦​​​​​🇷​​​​​  " 
ui_print " "
ui_print " Choose DSB style which you need to install..."
ui_print " In both Styles left Dsb is for clock" 
ui_print " "
ui_print " Style 1 -  Right DSB for network traffic (optional) " 
ui_print " Style 2 -  Right DSB for battery icon "
ui_print " "
ui_print " Note - Some roms don't support network traffic" 
ui_print " "
ui_print " Choose a Style to proceed...!! "  
ui_print "   Vol+ = Style 1 , Vol- = Style 2  "
ui_print " "
if $VKSEL; then
     JDSB=true
     ui_print " Selected - Style 1" 
else
	 JDSB=false
	  ui_print " Selected - Style 2" 
fi
ui_print " "
ui_print " This module also consists lot of advanced styles"  
ui_print " Use @dsbaddons, to customize your Dsb"  
ui_print " " 
ui_print " *********************************************************"
ui_print " Note - If you face any bootloop or blackscreen then - "
ui_print " You can flash this same module in recovery to remove it"
ui_print " "
ui_print " Any issues? Reach out on support group" 
ui_print " Support Group - @dualstatusbar on telegram  "
ui_print " *********************************************************"