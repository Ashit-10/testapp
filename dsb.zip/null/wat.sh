echo wtf
echo ./deploy
