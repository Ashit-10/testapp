from pyrogram.raw.functions.messages import GetStickerSet
from pyrogram.raw.functions.stickers import AddStickerToSet, RemoveStickerFromSet, RenameStickerSet
from pyrogram.raw.types import InputStickerSetShortName
from pyrogram.file_id import FileId
from pyrogram import raw
from PIL import Image
import math
import os
from moviepy.editor import VideoFileClip as vfclip


async def rename_stkr_pack(c, sticker_pack, title):
    try:
        okay = await c.invoke(
            RenameStickerSet(
                stickerset=raw.types.InputStickerSetShortName(short_name=sticker_pack.set.short_name),
                title=str(title)
            )
        ) 
    except Exception as e:
        print(str(e))
        okay = None
    return okay

async def make_stkr_size_for_wp(photo_file,save_file, maxsize, extension):
    try:
            im = Image.open(photo_file)
            # maxsize = (512, 512)
            im = im.resize(maxsize)
            im.thumbnail(maxsize)
            im.save(save_file, extension)     
            return True   
    except Exception as e:
        return e


async def get_stkr_set(c, packname):
    try:
        sticker_set = await c.invoke(
                    GetStickerSet(
                        stickerset=InputStickerSetShortName(
                            short_name=packname
                        ),
                        hash=0
                    )
                )
    except Exception as e:
        sticker_set = str(e), None
    return sticker_set

async def add_stkr_to_set(c, packname, docc, sticker_emoji):
    try:
        okay = await c.invoke(AddStickerToSet(
            stickerset=InputStickerSetShortName(short_name=packname),
            sticker=raw.types.InputStickerSetItem(document=docc,
            emoji = sticker_emoji)))
    except Exception as e:
        okay = str(e)    
    return okay


async def del_stkr_from_set(c, sticker):
    try:
        okay = await c.invoke(RemoveStickerFromSet(
            sticker=sticker
        ))
    except Exception as e:
        okay = str(e)
    
    return okay


async def make_doc(file_id):
    try:
        doc = FileId.decode(file_id)
        docc = raw.types.InputDocument(
            id=doc.media_id,
            access_hash=doc.access_hash,
            file_reference=doc.file_reference)
    except:
        try:
          docc = raw.types.InputDocument(
            id=file_id.id,
            access_hash=file_id.access_hash,
            file_reference=file_id.file_reference)
        except:
           docc = None
    return docc

async def create_stkr_pack(c, packname, user_id, title, sticker, emoji):
    try:
        okay = await c.invoke(
            raw.functions.stickers.CreateStickerSet(
                user_id= await c.resolve_peer(user_id),
                title=title,
                short_name=packname,
                stickers=[raw.types.InputStickerSetItem(document=sticker,
            emoji = emoji)],
            )
        )
    except Exception as e:
        okay = str(e)
    return okay

async def up_doc(c, doc, user_id):
    try:
        okay = await c.invoke(
            raw.functions.messages.UploadMedia(
                peer=await c.resolve_peer(user_id),
                media=raw.types.InputMediaUploadedDocument(
                    mime_type= c.guess_mime_type(doc)
                        or "image/png",
                    file=await c.save_file(doc),
                    attributes=[
                        raw.types.DocumentAttributeFilename(
                            file_name=os.path.basename(doc)
                        )
                    ],
                ),
            )
        )
    except Exception as e:
        print("error of up_doc", e)
        okay=None
    return okay


async def make_stkr_size(folder, file_name, exten, *args):
    if args and args[0] == "wp":
        maxsize = args[1]
    else:
            maxsize = (512, 512)
    photo_file = folder + "/" + file_name
    try:
            im = Image.open(photo_file)
            if (im.width and im.height) < 512:
                size1 = im.width
                size2 = im.height
                if im.width > im.height:
                    scale = 512 / size1
                    size1new = 512
                    size2new = size2 * scale
                else:
                    scale = 512 / size2
                    size1new = size1 * scale
                    size2new = 512
                size1new = math.floor(size1new)
                size2new = math.floor(size2new)
                sizenew = (size1new, size2new)
                im = im.resize(sizenew)
            else:
                im.thumbnail(maxsize)

            new_file = folder + "/" + file_name.split(".")[0] + "." + exten
            if exten == "png":
                exten = "PNG"

            im.save(new_file, exten)     
            return True   
    except Exception as e:
        return e
    


async def sendinfo(vid):
     clip = vfclip(str(vid)) 
     clip1 = clip.subclip(0, 10)
     print("got dur", clip.duration)
     a = clip1.w
     b = clip1.h
     c = clip.duration #- 0.2
     print(a, b ,c, "  - sending to main")
     
     return a, b, c


v_dt = "3.0"

async def convert_webm(idk, rmsg, *args):
          if args:
            v_dt = args[0]
            v_dt1 = args[0]
          else:
            v_dt = "3.0"
            v_dt1 = v_dt
          v_h, v_w, v_d = 512, 512, v_dt
          try:
            get_info = rmsg.video
          except:
              get_info = rmsg.document
        #   print(get_info)
          if get_info:
            v_w = get_info.width
            v_h = get_info.height
            v_d = get_info.duration
            print("before duration from get info", v_d)
          else:
            try:
                vid_clip = await sendinfo(f"downloads/{idk}.mkv")
         
                v_w = vid_clip[0]
                v_h = vid_clip[1]
                v_d = vid_clip[2]
                if int(v_d) > 3:
                   v_d = v_dt
            except Exception as e:
               print(e)
          if str(v_d)[0:3] == "0.0":
              v_d = v_dt1
          if int(float(v_d)) >= 3:
              v_d = v_dt

          print(v_d)
          if v_h and v_w:
            if v_w > v_h:
               print(f"1st {v_d}")
               os.system(f"webm -t {v_d} -vw 512 -l 0.028 -an -i downloads/{idk}.mkv")
            elif v_w < v_h:
               print(f"2nd {v_d}", idk)
               os.system(f"webm -t {v_d} -vh 512 -l 0.028 -an -i downloads/{idk}.mkv")
            elif v_w == v_h:
               print(f"3rd {v_d}")
               os.system(f"webm -t {v_d} -vh 512 -l 0.028 -an -i downloads/{idk}.mkv")
   
            os.system(f"mv -f {idk}*.webm downloads/{idk}.webm")
          else:
             print("did not got the weidth and height")
             print(f"4th {v_d}")
             os.system(f"webm -t {v_d} -vh {v_h} -{v_w} 512 -l 0.028 -an -i downloads/{idk}.mkv")   
             os.system(f"mv -f {idk}*.webm downloads/{idk}.webm")    
          return 




def webmex(vid, dur, vw, vh):
     print(vid, "video file name")
     if not dur:
         dur = v_dt
     if not vw:
        vw = "512"
     if not vh:
        vh = "512"
     if int(float(dur)) >= 3:
        dur = v_dt
    
     h_or_w = "vw"
     if vw > vh:
         h_or_w = "vw"
     elif vh > vw:
         h_or_w = "vh"
     print(dur, "printing duration")
     os.system(f"webm -t {dur} -{h_or_w} 512 -l 0.028 -an -i {vid}.mkv")
     os.system(f"mv -f {vid}*.webm {vid}.webm") 
     if not os.path.isfile(f"{vid}*.webm"):
          dur = float(dur) - 1
          os.system(f"webm -t {dur} -{h_or_w} 512 -l 0.028 -an -i {vid}.mkv")
          os.system(f"mv -f {vid}*.webm {vid}.webm")
