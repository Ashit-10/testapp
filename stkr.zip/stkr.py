from os import environ, execle
import random
from random import randint as rain
from pyrogram import *
from pyrogram.types import *
import json
import sys
# from time import time
import time

from utils import *
import asyncio


# bot_token = "5214279030:AAGl8vB850XGdjAkTCq ZxsfoWHNIYubx46E"

bot_token = "5303865333:AAExvQrJMMOBgZIIANd1jSkAjIvBsqRfSzo" 

bot_token2= "7168897543:AAG4Eb_r6L-Ri85NvYTwW3wqYqoWDA3lK0Q"

# botname = "The_avengers_robot"

botname = "Sticker_kang_robot"
 
owner = 1602293216
mychat = -1001716284663
log_channel = -1001349019437
logchat = -1001756825711

dephendor = 740538095

admins = [owner, dephendor, 809293242]
channel = "@sticker_kang_bot_channel"
video_msg_link = "t.me/sticker_kang_bot_channel/19"
ss_link = "t.me/sticker_kang_bot_channel/16"




api_id = 6810439 
api_hash = '66ac3b67cce1771ce129819a42efe02e'

api_id2 = 2613713
api_hash2 = "f615f10d7410ce9ba757f211cf1fb84b"

bot = Client(
    "sticker_bot",
    bot_token=bot_token,
    api_id=api_id,
    api_hash=api_hash
)

bot_man = Client(
    "sticker_man",
    api_id=api_id,
    api_hash=api_hash
)

bot2 = Client(
    "redirect_bot",
    bot_token=bot_token2,
    api_id=api_id2,
    api_hash=api_hash2
)


emojiss = ["🌚", "😎", "😃", "😁", "😅", "🤗", "😇", "👀", "❤️", "👌", "👀", "🌈",
           "😐", "🤨", "😒", "😱", "🤣", "👌", "😆", "😍", "🧐", "😑"]



max_file_size = 10000 # ~ 10mb
max_file_size_in_mb = 10

start_btn_callback  = InlineKeyboardMarkup([
    [InlineKeyboardButton(
        text=f"Start me", callback_data="start")]
])

start_btn=InlineKeyboardMarkup([[
   InlineKeyboardButton(
     text="Start", 
     url=f"t.me/{botname}?start")
     ]])

@bot.on_message(filters.command("convert"))
def cont(c, m):
     if m.from_user:
        user_id = m.from_user.id
     else:
        return
#     print(m.reply_to_message)
     if m.reply_to_message and m.reply_to_message.animation:
       fmsg = m.reply_text("Downloading ...")
       m.reply_to_message.download(f"downloads/output_{user_id}.mkv")
       try:
           rmsg = m.reply_to_message
           h = rmsg.animation.height
           w = rmsg.animation.width
           m.reply_video(f"downloads/output_{user_id}.mkv", width=w, height=h)
           fmsg.edit("Converted Gif to video")
       except Exception as e:
            print(e)
            fmsg.edit("Error")
     elif m.reply_to_message and m.reply_to_message.sticker and "webm" in m.reply_to_message.sticker.mime_type:
       # if "video" in m.reply_to_message.mime_type:
       #    fmsg = m.reply_text("Downloading ...")
       #    m.reply_to_message.download(f"dowloads/output_{user_id}.mkv")
        
        
        fmsg = m.reply_text("Processing ...\nIt will take 5-10 seconds.")
        m.reply_to_message.download(f"downloads/{user_id}.webm")
        os.system(f"rm -f downloads/output_{user_id}.mkv")
        os.system(f"ffmpeg -i downloads/{user_id}.webm -c:a copy -c:v vp9 -b:v 1M downloads/output_{user_id}.mkv")
        try:
           rmsg = m.reply_to_message.sticker
           m.reply_video(f"downloads/output_{user_id}.mkv", width=rmsg.width, height=rmsg.height)
           fmsg.edit("Converted sticker to video")
        except:
           fmsg.edit("Error .")
     os.system(f"rm -f downloads/{user_id}.webm downloads/output_{user_id}.mkv")
    
     send_logs_sync(f"#convert {m.from_user.id} {m.from_user.first_name}  @{m.from_user.username}")


async def send_logs(msg, *args):
    try:
        await bot.send_message(log_channel, f"{msg} {args}") #, parse_mode=enums.ParseMode.DISABLED)
    except:
        await bot.send_message(log_channel, f"{msg} {args}", parse_mode=enums.ParseMode.DISABLED)
    finally:
       return

@bot.on_message(filters.command("rename"))
async def _rename(c, m):
   if m.from_user: 
    try:
        await add_user(m, m.from_user.id, m.from_user.first_name, m.from_user.username)
    except:
        pass
    user_id = m.from_user.id
    await send_logs(f"{user_id}, @{m.from_user.username} renamed his pack.")
    if m.reply_to_message and m.reply_to_message.sticker:
        rmsg = m.reply_to_message
        packname = rmsg.sticker.set_name
        if (str(user_id) in packname or user_id == owner) and (botname in packname):
            if " " in m.text:
                new_name = m.text.split(" ", 1)[1]
                if new_name and len(new_name) < 40:
                    sticker = await get_stkr_set(c, packname)
                    if new_name == sticker.set.title:
                        await m.reply_text("Old name and new name are same, please give another name.")
                    else:
                        okay = await rename_stkr_pack(c, sticker, new_name)
                        if okay:
                            await m.reply_text(f"Old sticker pack has been renamed. \nHere :  [{okay.set.title}](t.me/addstickers/{okay.set.short_name})")
                        else:
                            await m.reply_text("Error .\nTry again later.")

                else:
                    await m.reply_text("New name should not be bigger than 50 letters.")        
            else:
                await m.reply_text("New name is not found.")
            
        else:
            await m.reply_text("This is not your sticker pack or not created my me.")



    else:
        await m.reply_text("Reply to a sticker with a new name from the sticker pack which you want to rename.")
   
@bot.on_message(filters.command("kang"))
async def _kang(c, m):
  # print(m)
   if m.from_user: 
    try:
        await add_user(m, m.from_user.id, m.from_user.first_name, m.from_user.username)
    except:
        pass
   
   # if ("SUPERGROUP" not in str(m.chat.type)) or (not m.chat.username): 
     #   await m.reply_text("This bot has just been updated with new codes. Report any issues to @dephendor") # reply_markup = start_btn)
    if m.reply_to_message:
        rmsg = m.reply_to_message
#        3_logs(rmsg)
        if rmsg.photo:
            await kang(c, m)

        elif rmsg.sticker and "image" in rmsg.sticker.mime_type:
            await kang(c, m)
        elif rmsg.sticker and rmsg.sticker.is_animated:
            await kangani(c, m)
        elif rmsg.video and "video" in rmsg.video.mime_type:
            await kangwebm(c, m)
        elif rmsg.document and "video" in rmsg.document.mime_type:
            await kangwebm(c, m)
        elif rmsg.document and "image" in rmsg.document.mime_type:
            await kang(c, m)
        elif rmsg.sticker and "webm" in rmsg.sticker.mime_type:
            await kangwebm(c, m)
        elif rmsg.animation:
            await kangwebm(c,m)
        else:
            await m.reply_text("I cant kang that")
    else:
        await m.reply_text("please reply to a image/sticker to kang it.")

@bot.on_message(filters.command(["packkang", "pkang"]))
async def _kang(c, m):
   if m.from_user: 
    try:
        await add_user(m, m.from_user.id, m.from_user.first_name, m.from_user.username)
    except:
        pass
   
   # if ("SUPERGROUP" not in str(m.chat.type)) or (not m.chat.username): 
  #      await m.reply_text("This bot has just been updated with new codes. Report any issues to @dephendor") # reply_markup = start_btn)
    if m.reply_to_message:
        rmsg = m.reply_to_message
        if rmsg.photo:
            await kang(c, m)
            return
        if not rmsg.sticker:
            await m.reply_text("Please reply to a sticker to pack kang it.")
            return
        stkr_pack = rmsg.sticker.set_name
        sticker_set = await get_stkr_set(c, stkr_pack)
        total_stkrs = sticker_set.set.count
        if " " in m.text:
            num = m.text.split(" ", 1)[1]
            num1 = None
            num2 = total_stkrs
            if "-" in num:
                try:
                    num1 = int(num.split("-")[0])
                    num2 = int(num.split("-")[1])
                    if num1 <= 0 or num2 > 120 or num1 > total_stkrs or num1 > total_stkrs:
                        await m.reply_text(f"Invalid numbers given. First number should be 1 or more and second number should be within 120.")
                        return
                except:
                    await m.reply_text("Format error.\nfor example:\n`/packkang 5-10`")
                    return
            else:
                try:
                    num1 = int(num)
                except:
                    await m.reply_text("Format error.\nfor example:\n`/packkang 5-10`")
                    return
        else:
            num1 = 1
            num2 = total_stkrs
                    
        user_id = m.from_user.id
        if rmsg.sticker and "image" in rmsg.sticker.mime_type:
            pkanging = pkang_data.get(str(user_id))
            if pkanging:
                await m.reply_text("Your one pack-kang is running currently , comeback later.")
            else:
                pkang_data.update({str(user_id) : "packkang"})
                try:
                    await kang(c, m, "packkang", sticker_set, num1, num2)
                finally:
                    pkang_data.pop(str(user_id))
            return

        elif rmsg.sticker and rmsg.sticker.is_animated:
            pkanging = pkang_data.get(str(user_id))
            if pkanging:
                await m.reply_text("Your one pack-kang is running currently , comeback later.")
            else:
                pkang_data.update({str(user_id) : "packkang"})
                try:
                    await kangani(c, m, "packkang", sticker_set, num1, num2)
                finally:
                    pkang_data.pop(str(user_id))
            return
            
        
        elif rmsg.sticker and "webm" in rmsg.sticker.mime_type:
            pkanging = pkang_data.get(str(user_id))
            if pkanging:
                await m.reply_text("Your one pack-kang is running currently , comeback later.")
            else:
                pkang_data.update({str(user_id) : "packkang"})
                try:
                     await kangwebm(c, m, "packkang", sticker_set, num1, num2)
                finally:
                    pkang_data.pop(str(user_id))
            return
            
        else:
            await m.reply_text("I cant pack kang that")
    else:
        await m.reply_text("please reply to a image/sticker to pack kang it.")



pkang_data = {}

async def kang(c, m, *args):
    if args and args[0] == "packkang":
        pack_mode = True
    else:
        pack_mode = False
        
    fmsg = await m.reply_text("Processing ...")

    exten = "png"
    user_id = m.from_user.id
    chat_id = m.chat.id
    user_name = str(m.from_user.first_name)
    name = user_name[:50]
    packnum = 0
    packname = "kang_" + str(user_id) + "_by_" + botname  
    msg_id = ""
    packname_found = 0
    max_stickers = 120
    while packname_found == 0:
        try:
            sticker_set = await get_stkr_set(c, packname)

            all_stickers = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in sticker_set.documents]
            file_ids = [s.file_id for s in all_stickers]
            if len(file_ids) >= max_stickers:
                packnum += 1
                packname = "kang_" + str(packnum) + "_" + str(user_id) + "_by_" + botname
            else:
                packname_found = 1    
        except Exception as e:
            packname_found = 1

    idk = str(rain(0000000000, 9999999999))
    kangsticker = f"{idk}.{exten}"
    if not pack_mode:
        rmsg = m.reply_to_message
        if rmsg.sticker:
            file_id = rmsg.sticker.file_id
        elif rmsg.photo:
            file_id = rmsg.photo.file_id
        elif rmsg.document:
            if rmsg.document.mime_type == "image/png":
                file_id = rmsg.document.file_id
            else:
                ""
        else:
            m.reply_text("I cant kang that")
        await asyncio.sleep(1)
        ok = await rmsg.download(kangsticker)

        # Packkang
    else:
        await send_logs(f"#packkang {m.from_user.first_name} @{m.from_user.username}\nt.me/addstickers/{packname}\n{m.link}")
        os.system(f"mkdir downloads/{user_id}")
        count = args[1].set.count
        i = 1
        try:
            i = args[2]
            count = args[3]
        finally:
            j = i
            all_stickers_to = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in args[1].documents]
            file_ids_to = [s.file_id for s in all_stickers_to]
            
            for lo in range(i, count + 1):
                pack_before = packname
                file_name = f"downloads/{user_id}/{i}.png"
                emoji = args[1].documents[i - 1].attributes[1].alt
                await c.download_media(message=file_ids_to[i - 1], file_name=file_name)
                suc, pack = await loop_kang(c, file_name, emoji, user_id, packnum, packname, "")

                if suc:
                    if int(i) % 3 == 0:
                        await fmsg.edit(f"To avoid flood wait error bot will kang slowly.\nKanging {i}/{count}")
                    packname = pack
                    await asyncio.sleep(2)
                else:
                    if pack == "PACK_SHORT_NAME_OCUPIED":
                        await fmsg.edit(f"Total sticker kanged: {i - 1}\nError occured: {pack}, try again with command `/packkang {i}-{count}`")
                    elif pack == "FLOOD_WAIT_ERROR":
                        try:
                            await fmsg.edit(f"Abroating due to flood wait error, please try again later with command -> `/packkang {i}-{count}`")
                        except:
                            return
                    else:
                        await fmsg.edit(f"Total sticker kanged: {i-1}\nError occured: {pack}, try again with command `/packkang {i}-{count}`")
                    await send_logs(f"packkang error {user_id}, {pack}")
                    break

                if i >= count:
                    break
                i += 1
            if botname in str(pack):
                sticker_set = await get_stkr_set(c, pack_before)
                await fmsg.edit(f"Pack kanged ({count - j + 1} stickers): [{sticker_set.set.title}](t.me/addstickers/{pack_before})\nYou can change your pack name with `/rename` command.")
                
        os.system(f"rm -r downloads/{user_id}")
        return        

    photo_resize = await make_stkr_size("downloads", kangsticker, exten)
    print(f"t.me/addstickers/{packname}")

    try:
        sticker_emoji = m.text.split(' ')[1]
    except:
            try:
                sticker_emoji = rmsg.sticker.emoji
                if not sticker_emoji:
                    sticker_emoji = random.choice(emojiss)
            except:
                sticker_emoji = random.choice(emojiss)


    file_id = await up_doc(c, f"downloads/{kangsticker}", user_id)
    try:
        stkr_doc = await make_doc(file_id.document)
    except:
        pass
    added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)
    try:
        a = added_stkr.set
        await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{sticker_emoji}'")
    except:
        print(added_stkr)
        if "STICKERSET_INVALID" in str(added_stkr):
            await fmsg.edit("Creating a new sticker pack ...")
            okay, added_stkr = await make_pack(c, name, packnum, packname, user_id, stkr_doc, sticker_emoji)

            if not okay:
                if added_stkr == "PEER_ID_INVALID":
                    await m.reply_text("Seems like you have never started me, start me in pm.", reply_markup = start_btn)
                    await fmsg.delete()
                    return

                elif added_stkr == "USER_IS_BLOCKED":
                    await m.reply_text("Seems like you have blocked me, start/unblock me in pm.", reply_markup = start_btn)
                    await fmsg.delete()
                else:
                    await c.send_message(mychat, f"Error in kang stkr , {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                    await m.reply_text(f"Error: {added_stkr}\n\nReported to the developer, will be fixed it soon.")
                    await fmsg.delete()
            else:
                await fmsg.edit(f"New sticker set created: [your pack](t.me/addstickers/{packname})")
        
        elif "PEER_ID_INVALID" in str(added_stkr):
            await m.reply_text("Seems like you have never started me, start me in pm.", reply_markup = start_btn)
            await fmsg.delete()
            return
        
        elif "STICKER_PNG_BIG" in str(added_stkr):
            # ok = await rmsg.download(kangsticker)
            photo_resize = await make_stkr_size("downloads", kangsticker, "WebP")
            kangsticker = f"{idk}.WebP"
            # re_stkr = await c.send_sticker(logchat, f"downloads/{kangsticker}")
            try:
                file_id = await up_doc(c, f"downloads/{kangsticker}", user_id)
                stkr_doc = await make_doc(file_id.document)
                added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)
                a = added_stkr.set
                await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{sticker_emoji}'")

            except:
                await fmsg.edit("Error occured, please kang the sticker given below ->")
                await m.reply_sticker(f"downloads/{kangsticker}")

        elif "USER_IS_BLOCKED" in str(added_stkr):
                    await m.reply_text("Seems like you have blocked me, start/unblock me in pm.", reply_markup = start_btn)
                    await fmsg.delete()

        elif "Telegram says" in str(added_stkr):
            okay, added_stkr = await error_hand(c, added_stkr, name, packnum, packname, user_id, stkr_doc, sticker_emoji)
            if okay:
                await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{added_stkr}'")
            else:
                await c.send_message(mychat, f"Error in kang stkr, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                await m.reply_text(f"Error: {added_stkr}\n\nReported to the developer, will be fixed it soon.")
                await fmsg.delete()
                await send_err(rmsg)

        elif "NoneType" in str(added_stkr):
            re_sent1 = await c.send_document(logchat, f"downloads/{kangsticker}", caption=f"{user_id}\nt.me/addstickers/{packname}")
            sticker_emoji = random.choice(emojiss) #texts[2]
            kangsticker = f"{idk}.png"
            await c.download_media(message=re_sent1, file_name=kangsticker)
            await make_stkr_size("downloads", kangsticker, "PNG")
            file_id1 = re_sent1.document.file_id
            stkr_doc1 = await make_doc(file_id1)
            added_stkr = await add_stkr_to_set(c, packname, stkr_doc1, sticker_emoji)
            try:
                a = added_stkr.set
                await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{sticker_emoji}'")
            except:
                okay, added_stkr = await error_hand(c, added_stkr, name, packnum, packname, user_id, stkr_doc, sticker_emoji)
            if okay:
                await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{sticker_emoji}'")
            
            elif "PEER_ID_INVALID" in str(added_stkr):
                await m.reply_text("Seems like you have never started me, start me in pm.", reply_markup = start_btn)
                await fmsg.delete()
                return

            elif "USER_IS_BLOCKED" in str(added_stkr):
                    await m.reply_text("Seems like you have blocked me, start/unblock me in pm.", reply_markup = start_btn)
                    await fmsg.delete()
            else:
                await c.send_message(mychat, f"Error in kang stkr, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                await m.reply_text(f"Error: {added_stkr}\nReported to the developer, will be fixed it soon.")             

            await send_err(rmsg)
        
        else:
            await fmsg.edit(str(added_stkr))
            await c.send_message(mychat, f"Error in kang stkr, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
            await m.reply_text(f"Error: {added_stkr}\nReported to the developer, will be fixed it soon.")

    os.system(f"rm downloads/{kangsticker}")


async def send_err(rmsg):
    try:
        await rmsg.forward(mychat)
    except:
        await rmsg.copy(mychat)


async def loop_kang(c, file_name, emoji, user_id, packnum, packname, stkr_type):
    file_id = await up_doc(c, file_name, user_id)
    try:
        stkr_doc = await make_doc(file_id.document)
    except Exception as e:
        if "Nonetype" in str(e):
            return False, "FLOOD_WAIT_ERROR"
        else:
            return False, str(e)
    added_stkr = await add_stkr_to_set(c, packname, stkr_doc, emoji)

    if "Telegram says" in str(added_stkr):
        packname = "kang_" + str(packnum + 1) + "_" + str(user_id) + stkr_type + "_by_" + botname
        okay, added_stkr = await make_pack(c, str(user_id), packnum, packname, user_id, stkr_doc, emoji)
        if "Telegram says" in str(added_stkr):
            try:
                added_stkr = await add_stkr_to_set(c, packname, stkr_doc, emoji)
                return True, added_stkr.set.short_name
            except:
                return False, added_stkr
        else:
            try:
                return True, added_stkr.set.short_name
            except:
                await send_logs(f"{user_id} t.me/addstickers/{packname}\n{added_stkr}")
                return False, added_stkr

    elif not "Telegram says" in str(added_stkr):
        return True, added_stkr.set.short_name
    else:
        print("loop kang error", added_stkr)
        return False, added_stkr

async def error_hand(c, added_stkr, name, packnum, packname, user_id, stkr_doc, sticker_emoji):
    if "STICKER_FILE_INVALID" in str(added_stkr):
        return False, "Sticker file invalid."
    
    if "STICKER_EMOJI_INVALID" in str(added_stkr):
        sticker_emoji = random.choice(emojiss)
        added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)
        try:
            a = added_stkr.set
            return True, sticker_emoji
        except:
            return False, added_stkr
        
    if "PEER_ID_INVALID" in str(added_stkr):
        return False, "PEER_ID_INVALID"
    
    if "PACK_TITLE_INVALID" in str(added_stkr):
        title = str(user_id) + "'s" + " sticker kang pack " + str(packnum)
        sent_for, added_stkr = await make_pack(c, name, packnum, packname, user_id, stkr_doc, sticker_emoji)
        if sent_for:
            return True, added_stkr
        else:
            return False, added_stkr
    
    else:
        await send_logs("error not found\n", str(added_stkr))

        return False, str(added_stkr)

async def kangwebm(c, m, *args):
    if args and args[0] == "packkang":
        pack_mode = True
    else:
        pack_mode = False
        
    fmsg = await m.reply_text("Processing ...")
    user_id = m.from_user.id
    user_name = str(m.from_user.first_name)
    chat_id = m.chat.id
    name = user_name[:30]

    packnum = 0
    packname = "kang_" + str(user_id) + "video_by_" + botname  
    msg_id = ""
    packname_found = 0
    max_stickers = 120
    while packname_found == 0:
        try:
            sticker_set = await get_stkr_set(c, packname)

            all_stickers = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in sticker_set.documents]
            file_ids = [s.file_id for s in all_stickers]
            if len(file_ids) >= max_stickers:
                packnum += 1
                packname = "kang_" + str(packnum) + "_" + str(user_id) + "_video_by_" + botname
            else:
                packname_found = 1    
        except Exception as e:
            packname_found = 1


    idk = str(rain(0000000000, 9999999999))
    kangsticker = f"{idk}.webm"
    rmsg = m.reply_to_message
    await fmsg.edit("Downloading...")
    await asyncio.sleep(1)
    if not pack_mode:
        if rmsg.sticker:
            await rmsg.download(f"{idk}.webm")
        elif rmsg.animation or rmsg.video or rmsg.document:
            if rmsg.video:
                if int(rmsg.video.file_size) / 1024 > max_file_size:
                    fsize = int(rmsg.video.file_size) / 1024
                    await fmsg.edit(f"file size is too big. ({int(fsize)} kb) Send file with in {max_file_size_in_mb}mb")
                    return
                else:
                    await rmsg.download(f"{idk}.mkv")
                    try:
                        width = rmsg.video.width
                        height = rmsg.video.height
                    except:
                        pass
            elif rmsg.document:
                if int(rmsg.document.file_size) / 1024 > max_file_size:
                    fsize = int(rmsg.document.file_size) / 1024 
                    await fmsg.edit(f"file size is too big.({int(fsize)} kb) Send file with in {max_file_size_in_mb} mb")
                    return
                else:
                    await rmsg.download(f"{idk}.mkv")
                    try:
                        width = rmsg.document.width
                        height = rmsg.document.height
                    except:
                        pass
            elif rmsg.animation:
                if int(rmsg.animation.file_size) / 1024 > max_file_size:  

                    fsize = int(rmsg.animation.file_size) / 1024
                    await fmsg.edit(f"file size is too big.({int(fsize)} kb) Send file with in {max_file_size_in_mb} mb")
                    return
                else:
                    await rmsg.download(f"{idk}.mkv")
                    try:
                        width = rmsg.animation.width
                        height = rmsg.animation.height
                    except:
                        pass
            await fmsg.edit("Converting ..., It will take 10 - 15 seconds .")
            await convert_webm(idk, rmsg)
    else:
        await send_logs(f"#packkang_video {m.from_user.first_name} @{m.from_user.username}\nt.me/addstickers/{packname}\n{m.link}")
        os.system(f"mkdir downloads/{user_id}")
        count = args[1].set.count
        i = 1
        try:
            i = args[2]
            count = args[3]
        finally:
            j = i
            all_stickers_to = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in args[1].documents]
            file_ids_to = [s.file_id for s in all_stickers_to]
            
            for lo in range(i, count + 1):
                pack_before = packname
                file_name = f"downloads/{user_id}/{i}.webm"
                emoji = args[1].documents[i - 1].attributes[1].alt
                await c.download_media(message=file_ids_to[i - 1], file_name=file_name)
                suc, pack = await loop_kang(c, file_name, emoji, user_id, packnum, packname, "_video")

                if suc:
                    if int(i) % 3 == 0:
                        await fmsg.edit(f"To avoid flood wait error bot will kang slowly.\nKanging {i}/{count}")
                    packname = pack
                    await asyncio.sleep(2)
                else:
                    if pack == "PACK_SHORT_NAME_OCUPIED":
                        await fmsg.edit(f"Total sticker kanged: {i - 1}\nError occured: {pack}, try again with command `/packkang {i}-{count}`")
                    elif pack == "FLOOD_WAIT_ERROR":
                        try:
                            await fmsg.edit(f"Abroating due to flood wait error, please try again later with command -> `/packkang {i}-{count}`")
                        except:
                            return
                    else:
                        await fmsg.edit(f"Total sticker kanged: {i-1}\nError occured: {pack}, try again with command `/packkang {i}-{count}`")
                    await send_logs(f"packkang error {user_id}, {pack}")
                    break

                if i >= count:
                    break
                i += 1
            if botname in str(pack):
                sticker_set = await get_stkr_set(c, pack_before)
                await fmsg.edit(f"Pack kanged ({count - j + 1} stickers): [{sticker_set.set.title}](t.me/addstickers/{pack_before})\nYou can change your pack name with `/rename` command.")
                
        os.system(f"rm -r downloads/{user_id}")
        return        


    
    try:
        sticker_emoji = m.text.split(' ')[1]
    except:
            try:
                sticker_emoji = rmsg.sticker.emoji
            except:
                sticker_emoji = random.choice(emojiss)
    print(f"t.me/addstickers/{packname}")
      
    if os.path.isfile(f"downloads/{kangsticker}"):
        file_id = await up_doc(c, f"downloads/{kangsticker}", user_id)
    else:
        try:
            re_sent = await c.send_document(logchat, f"downloads/{idk}.mkv", caption=f"{user_id}\nt.me/addstickers/{packname}")
            # await send_logs("re downloaded the webm doc")
            re_rmsg = await re_sent.download(f"{idk}.mkv")
            await convert_webm(idk, re_sent)
            file_id = await up_doc(c, f"downloads/{kangsticker}", user_id)

        except Exception as e:
            await fmsg.edit(f"There is some issue with the file. Please send as document.\n{str(e)}")
            return
    
    stkr_doc = await make_doc(file_id.document)

    added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)

    try:
        a = added_stkr.set
        await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{sticker_emoji}'")
    except:
        print(added_stkr)
        if "STICKERSET_INVALID" in str(added_stkr) or "STICKERS_TOO_MUCH" in str(added_stkr):
            await fmsg.edit("Creating a new sticker pack ...")
            okay, added_stkr = await make_pack(c, name, packnum, packname, user_id, stkr_doc, sticker_emoji)

            if not okay:
                if added_stkr == "PEER_ID_INVALID":
                    await m.reply_text("Seems like you have never started me, start me in pm.", reply_markup = start_btn)
                    await fmsg.delete()
                    return
                elif "USER_IS_BLOCKED" in str(added_stkr):
                    await m.reply_text("Seems like you have blocked me, start/unblock me in pm.", reply_markup = start_btn)
                    await fmsg.delete()
                if "LONG" in str(added_stkr):
                    idk1 = str(rain(0000000000, 9999999999))
                    kangsticker1 = f"{idk1}.webm"
                    sticker_emoji = random.choice(emojiss)
                    re_sent = await c.send_document(logchat, f"downloads/{idk}.mkv", caption=f"{user_id}\nt.me/addstickers/{packname}")
                    # await send_logs("re downloaded the webm video")
                    re_rmsg = await re_sent.download(f"{idk1}.mkv")
                    await convert_webm(idk1, re_sent, "2.9")
                    file_id = await up_doc(c, f"downloads/{kangsticker1}", user_id)
                    stkr_doc = await make_doc(file_id.document)

                    added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)

                    try:
                        a = added_stkr.set
                        await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji {sticker_emoji}")
                        
                    except:
                            try:
                                    idk2 = str(rain(0000000000, 9999999999))
                                    kangsticker2 = f"{idk2}.webm"
                                    re_sent1 = await c.send_video(logchat, f"downloads/{idk1}.mkv", width= width, height = height, caption=f"{user_id}\nt.me/addstickers/{packname}")
                                    # await send_logs("re downloaded the webm video")
                                    re_rmsg = await re_sent.download(f"{idk2}.mkv")
                                    await convert_webm(idk2, re_sent1, "2.8")
                                    file_id = await up_doc(c, f"downloads/{kangsticker2}", user_id)
                                    stkr_doc = await make_doc(file_id.document)
                                    added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)
                                    a = added_stkr.set
                                    await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji {sticker_emoji}")
                            
                            except:
                                    await fmsg.edit(f"Error: {added_stkr}\nTry sending the file as a video.")
                                    await c.send_message(mychat, f"Error in kang webm, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                                    await send_err(rmsg)



                else:
                    await c.send_message(mychat, f"Error in kang webm, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                    await m.reply_text(f"Error: {added_stkr}\n\nReported to the developer, will be fixed it soon.")
                    await fmsg.delete()
                    await send_err(rmsg)
            else:
                await fmsg.edit(f"New sticker set created: [your pack](t.me/addstickers/{packname})")
        
        elif "PEER_ID_INVALID" in str(added_stkr):
            await m.reply_text("Seems like you have never started me, start me in pm.", reply_markup = start_btn)
            await fmsg.delete()
            return

        elif "USER_IS_BLOCKED" in str(added_stkr):
                    await m.reply_text("Seems like you have blocked me, start/unblock me in pm.", reply_markup = start_btn)
                    await fmsg.delete()

        elif "Telegram says" in str(added_stkr):
            if "LONG" in str(added_stkr):
                idk1 = str(rain(0000000000, 9999999999))
                kangsticker1 = f"{idk1}.webm"
                sticker_emoji = random.choice(emojiss)
                re_sent = await c.send_document(logchat, f"downloads/{idk}.mkv", caption=f"{user_id}\nt.me/addstickers/{packname}")
                # await send_logs("re downloaded the webm video")
                re_rmsg = await re_sent.download(f"{idk1}.mkv")
                await convert_webm(idk1, re_sent, "2.9")
                file_id = await up_doc(c, f"downloads/{kangsticker1}", user_id)
                stkr_doc = await make_doc(file_id.document)

                added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)

                try:
                   a = added_stkr.set
                   await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji {sticker_emoji}")
                
                except:
                   try:
                        idk2 = str(rain(0000000000, 9999999999))
                        kangsticker2 = f"{idk2}.webm"
                        re_sent1 = await c.send_video(logchat, f"downloads/{idk1}.mkv", width= width, height = height, caption=f"{user_id}\nt.me/addstickers/{packname}")
                        # await send_logs("re downloaded the webm video")
                        re_rmsg = await re_sent.download(f"{idk2}.mkv")
                        await convert_webm(idk2, re_sent1, "2.8")
                        file_id = await up_doc(c, f"downloads/{kangsticker2}", user_id)
                        stkr_doc = await make_doc(file_id.document)
                        added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)
                        a = added_stkr.set
                        await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji {sticker_emoji}")
                
                   except:
                        await fmsg.edit(f"Error: {added_stkr}\nTry sending the file as a video.")
                        await c.send_message(mychat, f"Error in kang webm, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                        await send_err(rmsg)
            else: 
                okay, added_stkr = await error_hand(c, added_stkr, name, packnum, packname, user_id, stkr_doc, sticker_emoji)
                if okay:
                    await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{added_stkr}'")
                else:
                    await c.send_message(mychat, f"Error in kang webm, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                    await m.reply_text(f"Error: {added_stkr}\n\nReported to the developer, will be fixed it soon.")
                    await fmsg.delete()
                    await send_err(rmsg)
        else:
            await fmsg.edit(str(added_stkr))
            await c.send_message(mychat, f"Error in kang webm, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
            await m.reply_text(f"Error: {added_stkr}\nReported to the developer, will be fixed it soon.")
            await send_err(rmsg)

    os.system(f"rm downloads/{kangsticker}")







async def make_pack(c, name, packnum, packname, user_id, stkr_doc, sticker_emoji):
    if not packnum:
        packnum = ""
    title = name + "'s" + " sticker kang pack " + str(packnum)
    create_pack = await create_stkr_pack(c, packname, user_id, title, stkr_doc, sticker_emoji)
    try:
        a = create_pack.set 
        return True, create_pack
    except:
            if "STICKER_EMOJI_INVALID" in str(create_pack):
                    sticker_emoji = random.choice(emojiss)
                    create_pack = await create_stkr_pack(c, packname, user_id, title, stkr_doc, sticker_emoji)
            
            if "PACK_TITLE_INVALID" in str(create_pack):
                title = str(user_id) + "'s" + " sticker kang pack " + str(packnum)
                create_pack = await create_stkr_pack(c, packname, user_id, title, stkr_doc, sticker_emoji)

            if "SHORTNAME_OCCUPY_FAILED" in str(create_pack) or "STICKERS_TOO_MUCH" in str(create_pack):
                packnum += 1
                split_name = packname.split("kang_", 1)
                packname = split_name[0] + "kang_" + str(packnum) + "_" + split_name[1]
                create_pack = await create_stkr_pack(c, packname, user_id, title, stkr_doc, sticker_emoji)

            if "PEER_ID_INVALID" in str(create_pack):
                return False, "PEER_ID_INVALID"
            
            if "USER_IS_BLOCKED" in str(create_pack):
                return False, "USER_IS_BLOCKED"
            
            try:
                a = create_pack.set 
                return True, create_pack
            except:
                return False, create_pack

async def kangani(c, m, *args):
    if args and args[0] == "packkang":
        pack_mode = True
    else:
        pack_mode = False
        
    fmsg = await m.reply_text("Processing ...")
    user_id = m.from_user.id
    user_name = str(m.from_user.first_name)
    chat_id = m.chat.id
    name = user_name[:30]

    packnum = 0
    packname = "kang_" + str(user_id) + "_animation_by_" + botname  
    msg_id = ""
    packname_found = 0
    max_stickers = 50
    while packname_found == 0:
        try:
            sticker_set = await get_stkr_set(c, packname)

            all_stickers = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in sticker_set.documents]
            file_ids = [s.file_id for s in all_stickers]
            if len(file_ids) >= max_stickers:
                packnum += 1
                packname = "kang_" + str(packnum) + "_" + str(user_id) + "_animation_by_" + botname
            else:
                packname_found = 1    
        except Exception as e:
            packname_found = 1


    idk = str(rain(0000000000, 9999999999))
    kangsticker = f"{idk}.tgs"
    rmsg = m.reply_to_message
    await asyncio.sleep(1)
    if pack_mode:
        await send_logs(f"#packkang_animation {m.from_user.first_name} @{m.from_user.username}\nt.me/addstickers/{packname}\n{m.link}")
        os.system(f"mkdir downloads/{user_id}")
        count = args[1].set.count
        i = 1
        try:
            i = args[2]
            count = args[3]
        finally:
            j = i
            all_stickers_to = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in args[1].documents]
            file_ids_to = [s.file_id for s in all_stickers_to]
            
            for lo in range(i, count + 1):
                pack_before = packname
                file_name = f"downloads/{user_id}/{i}.tgs"
                emoji = args[1].documents[i - 1].attributes[1].alt
                await c.download_media(message=file_ids_to[i - 1], file_name=file_name)
                suc, pack = await loop_kang(c, file_name, emoji, user_id, packnum, packname, "_animation")

                if suc:
                    if int(i) % 3 == 0:
                        await fmsg.edit(f"To avoid flood wait error bot will kang slowly.\nKanging {i}/{count}")
                    packname = pack
                    await asyncio.sleep(2)
                else:
                    if pack == "PACK_SHORT_NAME_OCUPIED":
                        await fmsg.edit(f"Total sticker kanged: {i - 1}\nError occured: {pack}, try again with command `/packkang {i}-{count}`")
                    elif pack == "FLOOD_WAIT_ERROR":
                        try:
                            await fmsg.edit(f"Abroating due to flood wait error, please try again later with command -> `/packkang {i}-{count}`")
                        except:
                            return
                    else:
                        await fmsg.edit(f"Total sticker kanged: {i-1}\nError occured: {pack}, try again with command `/packkang {i}-{count}`")
                    await send_logs(f"packkang error {user_id}, {pack}")
                    break

                if i >= count:
                    break
                i += 1
            if botname in str(pack):
                sticker_set = await get_stkr_set(c, pack_before)
                await fmsg.edit(f"Pack kanged ({count - j + 1} stickers): [{sticker_set.set.title}](t.me/addstickers/{pack_before})\nYou can change your pack name with `/rename` command.")
                
        os.system(f"rm -r downloads/{user_id}")
        return        
    
    await rmsg.download(f"{idk}.tgs")

    try:
        sticker_emoji = m.text.split(' ')[1]
    except:
            try:
                sticker_emoji = rmsg.sticker.emoji
            except:
                sticker_emoji = random.choice(emojiss)
    
    print(f"t.me/addstickers/{packname}")

    file_id = await up_doc(c, f"downloads/{kangsticker}", user_id)
    stkr_doc = await make_doc(file_id.document)

    added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)
    print(added_stkr)
    try:
        a = added_stkr.set
        await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{sticker_emoji}'")
    except:
        print(added_stkr)
        if "STICKERSET_INVALID" in str(added_stkr):
            await fmsg.edit("Creating a new sticker pack ...")
            okay, added_stkr = await make_pack(c, name, packnum, packname, user_id, stkr_doc, sticker_emoji)

            if not okay:
                print(okay)
                if added_stkr == "PEER_ID_INVALID":
                    await m.reply_text("Seems like you have never started me, start me in pm.", reply_markup = start_btn)
                    await fmsg.delete()
                    return
                elif "USER_IS_BLOCKED" in str(added_stkr):
                    await m.reply_text("Seems like you have blocked me, start/unblock me in pm.", reply_markup = start_btn)
                    await fmsg.delete()

                elif "NoneType" in str(added_stkr):
                    a = await c.send_document(logchat, f"downloads/{kangsticker}", caption=f"{user_id}\nt.me/addstickers/{packname}")
                    await c.download_media(a, kangsticker)
                    file_id = await up_doc(c, f"downloads/{kangsticker}", user_id)
                    stkr_doc = await make_doc(file_id.document)
                    sticker_emoji = random.choice(emojiss)
                    added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)
                    try:
                        a = added_stkr.set
                        await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{sticker_emoji}'")
                    except:
                        await c.send_message(mychat, f"Error in kang animation, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                        await m.reply_text(f"Error: {added_stkr}\n\nReported to the developer, will be fixed it soon.")
                        await fmsg.delete()
                else:
                    await c.send_message(mychat, f"Error in kang animation, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                    await m.reply_text(f"Error: {added_stkr}\n\nReported to the developer, will be fixed it soon.")
                    await fmsg.delete()
            else:
                await fmsg.edit(f"New sticker set created: [your pack](t.me/addstickers/{packname})")
        
        elif "PEER_ID_INVALID" in str(added_stkr):
            await m.reply_text("Seems like you have never started me, start me in pm.", reply_markup = start_btn)
            await fmsg.delete()
            return
        elif "USER_IS_BLOCKED" in str(added_stkr):
                    await m.reply_text("Seems like you have blocked me, start/unblock me in pm.", reply_markup = start_btn)
                    await fmsg.delete()

        elif "NoneType" in str(added_stkr):
            a = await c.send_document(logchat, f"downloads/{kangsticker}", caption=f"{user_id}\nt.me/addstickers/{packname}")
            await c.download_media(a, kangsticker)
            file_id = await up_doc(c, f"downloads/{kangsticker}", user_id)
            stkr_doc = await make_doc(file_id.document)
            sticker_emoji = random.choice(emojiss)
            added_stkr = await add_stkr_to_set(c, packname, stkr_doc, sticker_emoji)
            try:
                a = added_stkr.set
                await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{sticker_emoji}'")
            except:
                await c.send_message(mychat, f"Error in kang animation, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                await m.reply_text(f"Error: {added_stkr}\n\nReported to the developer, will be fixed it soon.")
                await fmsg.delete()
        elif "Telegram says" in str(added_stkr):
            okay, added_stkr = await error_hand(c, added_stkr, name, packnum, packname, user_id, stkr_doc, sticker_emoji)
            if okay:
                await fmsg.edit(f"Sticker has been successfully added to [your pack](t.me/addstickers/{packname}) with emoji '{added_stkr}'")
            else:
                await c.send_message(mychat, f"Error in kang animation, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
                await m.reply_text(f"Error: {added_stkr}\n\nReported to the developer, will be fixed it soon.")
                await fmsg.delete()
                await send_err(rmsg)
        else:
            await fmsg.edit(str(added_stkr))
            await c.send_message(mychat, f"Error in kang animation, {user_id}  {user_name}  {m.from_user.username} \n {added_stkr}")
            await m.reply_text(f"Error: {added_stkr}\nReported to the developer, will be fixed it soon.")
            await send_err(rmsg)

    os.system(f"rm downloads/{kangsticker}")


@bot.on_message(filters.command("ping"))
async def ping(_, m):
    if m.from_user and m.from_user.id == owner:
        start = time.time()
        replymsg = await m.reply_text("....", quote=True)
        delta_ping = time.time() - start
        await replymsg.edit_text(f"<b>Pong!</b>\n{delta_ping * 1000:.3f} ms")
    return


@bot.on_message(filters.command(["mypacks"]))
async def packs(c, m):
    if m.from_user:
        user_id = m.from_user.id
        packnum = 0
        packname = "kang_" + str(user_id) + "_by_" + botname  
        packname_found = 0
        max_stickers = 120
        image_stkr_pack = ""
        while packname_found == 0:
            try:
                sticker_set = await get_stkr_set(c, packname)
                all_stickers = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in sticker_set.documents]
                file_ids = [s.file_id for s in all_stickers]
                # await send_logs(len(file_ids))
                image_stkr_pack += f"[{sticker_set.set.title}](t.me/addstickers/{packname})\n"

                # if len(file_ids) >= max_stickers:
                packnum += 1
                packname = "kang_" + str(packnum) + "_" + str(user_id) + "_by_" + botname
                # else:
                #     packname_found = 1    
                
            except Exception as e:
                # await send_logs(e)
                packname_found = 1

        packnum = 0
        packname = "kang_" + str(user_id) + "video_by_" + botname  
        packname_found = 0
        # max_stickers = 50
        video_stkr_pack = ""
        while packname_found == 0:
            try:
                sticker_set = await get_stkr_set(c, packname)
                all_stickers = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in sticker_set.documents]
                file_ids = [s.file_id for s in all_stickers]
                video_stkr_pack += f"[{sticker_set.set.title}](t.me/addstickers/{packname})\n"

                # await send_logs(len(file_ids))
                # if len(file_ids) >= max_stickers:
                packnum += 1
                packname = "kang_" + str(packnum) + "_" + str(user_id) + "_video_by_" + botname
                # else:
                #     packname_found = 1  
                  
            except Exception as e:
                # await send_logs(e)
                packname_found = 1     

        packnum = 0
        packname = "kang_" + str(user_id) + "_animation_by_" + botname  
        packname_found = 0
        max_stickers = 50
        anim_stkr_pack = ""
        while packname_found == 0:
            try:
                sticker_set = await get_stkr_set(c, packname)
                all_stickers = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in sticker_set.documents]
                file_ids = [s.file_id for s in all_stickers]
                anim_stkr_pack += f"[{sticker_set.set.title}](t.me/addstickers/{packname})\n"

                # await send_logs(len(file_ids))
                # if len(file_ids) >= max_stickers:
                packnum += 1
                packname = "kang_" + str(packnum) + "_" + str(user_id) + "_animation_by_" + botname
                # else:
                #     packname_found = 1   
                 
            except Exception as e:
                # await send_logs(e)
                packname_found = 1   
        if not image_stkr_pack and not video_stkr_pack and not anim_stkr_pack:
            await m.reply_text("You dont have any stickers packs made by me.")
        else:
            await m.reply_text(f"Sticker packs of {m.from_user.first_name}:\n{image_stkr_pack}\n{video_stkr_pack}\n{anim_stkr_pack}", disable_web_page_preview=True)

@bot.on_message(filters.command(["restart"]))
async def restart(client, message):
    if message.sender_chat:
        user_id = message.sender_chat.id
    else:
        user_id = message.from_user.id
    if int(user_id) == owner:
      ht = await message.reply_text(f"restarted.")
      
      chat_id = message.chat.id
      args = [sys.executable, "stkr.py"]
      execle(sys.executable, *args, environ)  
      exit()
      return

async def add_user(m, id, name, username):
    with open("sticker_users.txt", "r") as op:
        names = json.load(op)

    names[str(id)] = username
    with open("sticker_users.txt", "w") as opw:
        json.dump(names, opw)

    channel = m.chat.username
    channel_name = m.chat.title
    
    await send_logs(f"channel: {channel_name}, `{m.chat.id}`, @{channel}\n\nUser: @{m.from_user.username}, `{m.from_user.id}`, {m.from_user.first_name}")
    if channel and channel_name:
        await bot.send_message(logchat, f"@{channel}")



@bot.on_message(filters.command("nuke"))
async def unuke(c, m):
    if m.from_user.id == owner:
        os.system("rm -rf downloads/*")
        await m.reply_text("Done.")

@bot.on_message(filters.command("rmsg"))
async def msg_user(c, m):
    if m.from_user.id == owner:
        try:
            text = m.text.split(" ", 1)[1]
            r_id = text.split("/")[-1]
            chat = text.split("/")[-2]
         #   print(r_id, chat)
            try:
                chat = int(chat)
                if not "-100" in str(chat):
                    chat = "-100" + str(chat)
            except:
                chat = f"@{chat}"
            await m.reply_to_message.copy(str(chat), reply_to_message_id=int(r_id))
            await m.reply_text("Success.")
        except Exception as e:
            await m.reply_text(str(e), parse_mode=enums.ParseMode.DISABLED)

@bot.on_message(filters.command("dmsg"))
async def del_msg_usr(c, m):
    if m.from_user.id == owner:
        try:
            text = m.text.split(" ", 1)[1]
            r_id = text.split("/")[-1]
            chat = text.split("/")[-2]
         #   print(r_id, chat)
            try:
                chat = int(chat)
                if not "-100" in str(chat):
                    chat = "-100" + str(chat)
            except:
                chat = f"@{chat}"
            await c.delete_messages(chat, int(r_id) )
            await m.reply_text("success")
        except Exception as e:
            await m.reply_text(str(e))


@bot.on_message(filters.command("smsg"))
async def msg_usr(c, m):
    if m.from_user.id == owner:
        try:
            user_id = int(m.text.split()[1])
            msg = m.reply_to_message
            await msg.copy(user_id)
            await m.reply_text("success.")
        except Exception as e:
            await m.reply_text(str(e))

stkr_msg = f'''
I can kang and make stickers including (images, videos, gifs, documents) having maximum size upto {max_file_size_in_mb} mb.

`/kang`: reply to a sticker or image or video or document to kang it to your pack.

`/delsticker`: reply to a sticker to delete it from your pack.

`/delsticker number-number`: Deletes stickers from your pack from given number to number. (For eg: `/delsticker 1-10` , It will delete 1st sticker to 10th stickers of the pack)

`/packkang`: Kangs whole pack .

`/packkang number-number`: Kangs stickers only from given number to number. (For eg: `/packkang 6-69` , It will kang 6th sticker to 69th sticker of the given pack)

`/rename`: give a new name along with command and reply to one of the sticker of the set to change pack name.

`/mypacks`: Shows your sticker packs created by me.

`/wpsticker`: Makes sticker pack for whatsapp.

More commands will be added soon.
To report issues PM @dephendor

join our channel for updates:  https://t.me/sticker_kang_bot_channel


Thanks for using me :) , Have a nice day.

'''

@bot.on_message(filters.command(["start", "help"]))
async def start_me(c, m):

    if m.from_user:
        fname = m.from_user.first_name
    elif m.sender_chat:
        fname = m.sender_chat.title
    await m.reply_text(f"Hello, {fname}\n{stkr_msg}")
    await send_logs(f"{m.from_user.id}  @{m.from_user.username} started me.")

@bot.on_message(filters.command("users"))
async def usr(c, m):
    if m.from_user.id == owner:
        with open("sticker_users.txt", "r") as op:
            names = json.load(op)
        nums = len(names)
        await m.reply_text(f"Total users = {nums}")
        await m.reply_document("sticker_users.txt")
        await m.reply_document("sticker_ids.txt")

@bot.on_message(filters.command("delsticker"))
async def del_stkr(c, m):
    if m.reply_to_message:
        rmsg = m.reply_to_message
        if rmsg.sticker:
            user_id = m.from_user.id
            packname = rmsg.sticker.set_name
            if (str(user_id) in str(packname) or user_id == owner) and (botname in str(packname)):

                if " " in m.text:
                    stkr_pack = rmsg.sticker.set_name
                    sticker_set = await get_stkr_set(c, stkr_pack)
                    all_stickers_to = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in sticker_set.documents]
                    file_ids_to = [s.file_id for s in all_stickers_to]

                    num1, num2 = None, len(file_ids_to)
                    await send_logs(f"#delete trying to pack delete {m.from_user.id} @{m.from_user.username}\nt.me/addstickers/{rmsg.sticker.set_name}")
                    tmsg = m.text.split(" ",1)[1]
                    try:
                        if not "-" in str(tmsg):
                            num1 = int(tmsg)
                        else:
                            num1 = int(tmsg.split("-")[0])
                            num2 = int(tmsg.split("-")[1])
                    except:
                        await m.reply_text("Invalid arguments.\nfor eg: `/delsticker 2-5`")
                        return
                    if num1 and num2:
                        if num1 <= 0 or num2 > 120 or num1 > len(file_ids_to) or num2 > len(file_ids_to):
                            await m.reply_text(f"Given numbers are not valid for this pack. Number should be greater than 1 and less than 120.")
                            return
                        
                        
                        fmsg = await m.reply_text("Deleting ...")
                        del_num = 0
                        for d in range(num1, num2 + 1):
                            stkr_doc = await make_doc(file_ids_to[d-1])
                            suc = await del_stkr_from_set(c, stkr_doc)
                            if suc:
                                del_num += 1
                                if int(d) % 3 == 0:
                                    await fmsg.edit(f"To avoid flood wait error bot will delete slowly.\nDeleting {d}/{num2}")

                            await asyncio.sleep(2)
                            d += 1
                            if d > num2:
                                break
                        await fmsg.edit(f"{del_num} stickers successfully deleted from [Your pack](t.me/addstickers/{rmsg.sticker.set_name})")
                        return

                else:
                    file_id=rmsg.sticker.file_id
                    stkr_doc = await make_doc(file_id)
                    suc = await del_stkr_from_set(c, stkr_doc)

                if "STICKERSET_NOT_MODIFIED" in str(suc):
                    await m.reply_text("This sticker does not exist in your pack.")
                elif suc:
                    await m.reply_text("successfully deleted this sticker from your pack.")
                
                else:
                    await m.reply_text("This is not your sticker pack or not created by me.")
                    
            else:
                    await m.reply_text("This is not your sticker pack or not created by me.")
        else:
            await m.reply_text("Please reply to a sticker to delete from your sticker set.")



@bot2.on_message(filters.command(["start", "help", "kang", "packkang", "pkang", "delsticker", "rename", "mypacks"]))
async def _red(c, m):
    text = f"I am sleeping now\nGo to @Sticker_kang_robot"
    await m.reply_text(text)
    print("redirect bot", m.from_user.id, m.from_user.username)
@bot.on_callback_query()
def call(c, m):  
    if m.data == "start":
        print(m.data)



from PIL import Image as pi_image
import numpy
import cv2



async def img_transform(img_file_name, need_w):
    size = need_w
    img_cv = cv2.imread(img_file_name)
    try:
        h = img_cv.shape[0]
        w = img_cv.shape[1]
    except:
        return None
    free_dist = int((size - h) / 2)
    # print(free_dist, w, h)
    source_coords = [(0, 0), (need_w, 0), (need_w, need_w), (0, need_w)]
    target_coords = [(0,free_dist), (size,free_dist), (size, size + free_dist), (0,size + free_dist)]
    matrix = []
    for s, t in zip(source_coords, target_coords):
            matrix.append([t[0], t[1], 1, 0, 0, 0, -s[0]*t[0], -s[0]*t[1]])
            matrix.append([0, 0, 0, t[0], t[1], 1, -s[1]*t[0], -s[1]*t[1]])
    A = numpy.matrix(matrix, dtype=numpy.float32)
    B = numpy.array(source_coords).reshape(8)
    res = numpy.dot(numpy.linalg.inv(A.T * A) * A.T, B)

    img = pi_image.open(img_file_name)
    img = img.convert("RGBA")
    coeffs = numpy.array(res).reshape(8)

    new_image = img.transform((size, size), pi_image.PERSPECTIVE, coeffs,
                    pi_image.BICUBIC)

    new_image.save(img_file_name)
    return True


time_user = {}



def error_handler(default_response):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                # Call the original function
                return func(*args, **kwargs)
            except Exception as e:
                # Handle the exception and provide the default response
                print(f"Exception occurred: {e}")
                return default_response
        return wrapper
    return decorator


wp_msg =f"""1. Install the transfer app from [app store](https://apps.apple.com/ru/app/sticker-maker-studio/id1443326857) or [play store](https://play.google.com/store/apps/details?id=com.marsvard.stickermakerforwhatsapp)
2. Tap the received file and open with this app.
3. click on add pack to whatsapp.
----- Done -------
"""

@bot.on_message(filters.command("how_to_add_wp_stickers"))
async def wa_how(c, m):
      await m.reply_text(f"[Check out guide video]({video_msg_link})\n[Some screenshots]({ss_link})\n{wp_msg}", disable_web_page_preview=True)
      

@error_handler("Whatsapp sticker kang error")
@bot.on_message(filters.command(["whatsapp_sticker", "wpsticker"]))
async def wa(c, m):
        if not m.reply_to_message:
              await m.reply_text("Reply to a sticker to make whatsapp sticker pack.")
              return 
        user = m.from_user
        user_id = user.id
        if_user = time_user.get(str(user_id))
        max_minute = 6
        
        ext = "webp"

        if "SUPERGROUP" in str(m.chat.type).upper():
          group = True
        else:
          group= False
        if not m.reply_to_message:
            await m.reply_text("Please reply to a sticker to make whatsapp sticker pack.")
            return
        if not m.reply_to_message.sticker:
           await m.reply_text("Please reply to a sticker.")
           return
        if "webp" in m.reply_to_message.sticker.mime_type:
            ext = "webp"
        elif "tgs" in m.reply_to_message.sticker.mime_type:
             ext = "tgs"
             if user_id not in admins:
                await m.reply_text("Please reply to a image/video sticker to make whatsapp sticker pack.")
                return
        elif "webm" in m.reply_to_message.sticker.mime_type:
              ext = "webm"
        #       await m.reply_text("Please reply to a image sticker to make whatsapp sticker pack.")
        #       return
        else:
             await m.reply_text("Reply to a sticker to make whatsapp sticker pack.")
             return
             
        try:
            await c.send_message(user_id, "Making whatsapp stickers for you, I will send files here.")
        except:
            await m.reply_text("seems like you have blocked me, start me to receive files.", reply_markup=start_btn)
            return
        fmsg = await m.reply_text("processing ...")
        print(m.reply_to_message.sticker.mime_type)
        uname = m.from_user.first_name 
        username = m.from_user.username
        await send_logs(f"#wpsticker `{user_id}`  @{username} {uname}")
        await add_user(m, user_id, uname, username)

        if if_user and (user_id != owner):
              more = (int(time.time()) - int(float(if_user))) / 60
              wait_more = max_minute - more
              if not more > max_minute:
                   await m.reply_text(f"You just used the command few minutes ago,kindly wait {int(wait_more)} minutes.(This is to avoid spam)")
                   await fmsg.delete()
                   return
              else:
                    time_user.pop(str(user_id))
        else:
              time_user.update({str(user_id) : str(time.time())})
        user_id = m.from_user.id
        rmsg = m.reply_to_message
        os.system(f"rm -rf downloads/{user_id}")
        pack = rmsg.sticker.set_name
        sticker_set = await get_stkr_set(c, pack)
        all_stickers_to = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in sticker_set.documents]
        file_ids_to = [s.file_id for s in all_stickers_to]

        count = len(file_ids_to)
        os.system(f"mkdir downloads/{user_id}")
        pack_title = sticker_set.set.title
        print(pack_title, count)
        # for thumbnail
        file_name = f"downloads/{user_id}/unnamed.{ext}"
        should_name = f"downloads/{user_id}/unnamed.png"
        emoji = sticker_set.documents[0].attributes[1].alt
 
        await c.download_media(message=file_ids_to[0], file_name=file_name)
        if ext == "tgs":
             os.system(f"lottie_convert.py --frame 1 {file_name} {should_name}") 
             photo_resize = await make_stkr_size_for_wp(should_name, should_name, (96, 96), "PNG")
        elif ext == "webm":
              os.system(f"ffmpeg -i {file_name} -vframes 1 -filter:v scale=96:96 -y {should_name}")
        else:
                photo_resize = await make_stkr_size_for_wp(file_name, should_name, (96, 96), "PNG")

        link = f"https://t.me/addstickers/{pack}"
        name = pack_title            
        author = "@sticker_kang_robot"
        thumbnail = f"unnamed.{ext}"
        info = "App created by @ed_asriyan."

       
        if count > 30: 
           if (count % 30) == 0:
              pack_nums = int(count/30)
           else:
                pack_nums = int(count / 30) + 1
        else:
                pack_nums = 1

        folds = []
        for packs in range(1, pack_nums+1):
                fold_name = f"downloads/{user_id}/{packs}"
                os.system(f"mkdir {fold_name}")
                folds.append(fold_name)
                os.system(f"cp downloads/{user_id}/unnamed.png {fold_name}/")
                with open(f"{fold_name}/title.txt", "w+") as wr2:
                        wr2.write(f"{pack_title} pack - {packs}")
                        
        stkr_json = []
        old_stkr_ids = []
        from_count = 0
        if count > 30:
              pack_text = f"\nThis pack has {count} stickers, but whatsapp supports 30 stickers per pack, so it will be divided into {len(folds)} packs. "
        else:
              pack_text = ""

        with open("sticker_ids.txt", "r") as red:
             ids_data = json.load(red)
        try:
                old_stkr_ids = ids_data[pack]["ids"]
                from_count = (30 * len(old_stkr_ids)) 
                for r in range(len(old_stkr_ids)):
                     folds.pop(0)

        except Exception as e:
             print("Old id was not there", e)
        minu =int(count / 20)
        await fmsg.edit(f"Converting ...{pack_text}\nIt will take {minu} minutes. ")
        x = 0
        i = 1
        fuked = False
        # return
        for lo in range(from_count, count):
                try:
                    fname = f"{pack}_sticker_kang_robot_{i}.{ext}"
                    should_name = f"{pack}_sticker_kang_robot_{i}.webp"
                    try: 
                            folder = folds[x]
                    except:
                        break
                    file_name = f"{folder}/{fname}"
                    emoji = sticker_set.documents[lo].attributes[1].alt
                    await asyncio.sleep(0.5)
                    id_down = await bot2.download_media(message=file_ids_to[lo], file_name=file_name)
                    print(id_down)

                except Exception as e:
                    await fmsg.edit(f"Error occored:\nSome stickers are left unfinished.Try with any other sticker pack.")
                    await send_logs(str(e), user_id, m.from_user.username, link)
                    fuked = True
                    break 
             
                if ext == "webp" and os.path.isfile(file_name):
                        photo_resize = await img_transform(f"{file_name}", 512)
                        if not photo_resize:
                            xmsg = await fmsg.edit(f"Error occored:\nSome stickers({lo}) are left unfinished.Try with any other sticker pack.")
                            await send_logs("Error in wpsticker", user_id, m.from_user.username, link) 
                            fuked = True
                            break
                elif ext == "webm":
                #       os.system(f"ffmpeg -i {folder}/{fname} -s 512:512 -filter:v fps=15 -quality 50 -an -y {folder}/{should_name}")
                      os.system(f"ffmpeg -i {folder}/{fname} -vcodec libwebp -filter:v fps=15 -fs 470000 -preset default -an -vsync 0 -s 512:512 -y {folder}/{should_name}")
                      fsize = (os.stat(f"{folder}/{should_name}")).st_size
                      if fsize/1024 > 495:
                           os.system(f"ffmpeg -i {folder}/{fname} -vcodec libwebp -filter:v fps=15 -fs 450000 -preset default -an -vsync 0 -s 512:512 -y {folder}/{should_name}")
                      os.system(f"rm -f {folder}/{fname}")
                #       if 
                      
                elif ext == "tgs":
                      os.system(f"lottie_convert.py {folder}/{fname} {folder}/{pack}_sticker_kang_robot_{i}.gif") 
                      os.system(f"mv {folder}/{pack}_sticker_kang_robot_{i}.gif {folder}/{pack}_sticker_kang_robot_{i}.mkv")
                      os.system(f"ffmpeg -i {folder}/{pack}_sticker_kang_robot_{i}.mkv -vcodec libwebp -filter:v fps=20 -fs 460000 -preset default -an -vsync 0 -s 512:512 -y {folder}/{should_name}")
                      os.system(f"rm -f {folder}/{fname} {folder}/{pack}_sticker_kang_robot_{i}.mkv")

                else:
                    xmsg = await fmsg.edit(f"Error occored:\nSome stickers are left unfinished.Try with any other sticker pack.")
                    await send_logs("Path error", user_id, m.from_user.username, link)
                    fuked = True
                    break
                
                stkr_json.append({"file":fname, "emoji":emoji})
                try:
                    if (lo % 10) == 0:
                        more_mins = minu - (lo / 20) + 1 
                        await fmsg.edit(f"{pack_text}**\nConverting {lo}/{count}..\nIt will take less than {more_mins:.2} minutes.**")
                except:
                    pass
                all_files = os.listdir(folder)
                if lo == count or len(all_files) >= 32:
                        x += 1
                        i = 0
                        full_info = {"link":link,"name":name,"author":author,"thumbnail":thumbnail,"stickers":stkr_json,"info":info}
                        stkr_json = []
                        with open(f"{folder}/info.json", "w+") as wr:
                                json.dump(full_info, wr)

    
                i += 1
                if x > len(folds):
                        break

        if fuked:
            to_log = await m.reply_to_message.forward(logchat)
            print("sent to log chat")
            await man_work(m, pack, to_log.id, xmsg, m.chat.id, m.id)
            return
        with open(f"downloads/{user_id}/link.txt", "w+") as wr1:
                wr1.write(link)

        with open(f"downloads/{user_id}/author.txt", "w+") as wr3:
                wr3.write(author)

        p = len(old_stkr_ids) + 1
        suc = None
        file_name = None


        if old_stkr_ids:
             for id in old_stkr_ids:
                  try:
                        print(id)
                        await c.send_document(chat_id=user_id, document=id) 
                  except Exception as e:
                       print(e)
        send_stkr_ids = []
        for z in folds:
                files = os.listdir(z)
                for file in files:
                    if "_1.webp" in file:
                        file_name = z + "/" + file
                        break
                if file_name:
                    should_name = z + "/unnamed.png"
                    photo_resize = await make_stkr_size_for_wp(file_name, should_name, (96, 96), "PNG")
                    print(photo_resize)
                os.system(f"cp downloads/{user_id}/author.txt {z}/")
                os.system(f"cp downloads/{user_id}/link.txt {z}/")
                os.system(f"cd {z} && zip -r {pack}_{p}.wastickers *")
                try: 
                    send_stkr_doc = await c.send_document(user_id, f'{z}/{pack}_{p}.wastickers')
                    suc = True
                    send_stkr_ids.append(send_stkr_doc.document.file_id)
                except Exception as e:
                   print(e)
                   if "BLOCKED" in str(e):
                      await m.reply_text("You have blocked me , start me .", reply_markup = start_btn)
                      break
                p += 1
        if suc:
            await c.send_message(user_id, f"Download this app from [App Store](https://apps.apple.com/ru/app/sticker-maker-studio/id1443326857) or [Play Store](https://play.google.com/store/apps/details?id=com.marsvard.stickermakerforwhatsapp) to transfer stickers to whatsapp.\ncheck  /how_to_add_wp_stickers for more details.", disable_web_page_preview=True)
        if suc and group:
           await m.reply_text("Successfully made whatsapp sticker packs and sent you in Private message.")
           await fmsg.delete()
        else:
           await fmsg.delete()
        os.system(f"rm -rf downloads/{user_id}")
        await save_stkr_data(pack, send_stkr_ids, count, old_stkr_ids)


async def save_stkr_data(pack, pack_ids, total_stkrs, old_stkr_ids):
     if old_stkr_ids:
          total_stkrs = total_stkrs - (30 * len(old_stkr_ids))
     ids_num = int(total_stkrs/30)

     try:
          pack_ids.pop(ids_num)
     except:
          pass
     for id in pack_ids:
          old_stkr_ids.append(id)
     with open("sticker_ids.txt", "r") as red:
          old_ids = json.load(red)

     old_ids[pack] = {"ids": old_stkr_ids}
    #  print(old_ids)

     with open("sticker_ids.txt", "w") as wr:
          json.dump(old_ids, wr)



man_json = {}

async def man_work(m, pack, msg_id, xmsg, gc_id, rmsg_id):
        rmsg = m.reply_to_message
        await bot_man.forward_messages("@tgtowabot", logchat, msg_id)
        man_json.update({pack : str(m.from_user.id)})
        man_json.update({f"{pack}_x" : xmsg})
        man_json.update({f"{pack}_gc" : int(gc_id)})
        man_json.update({f"{pack}_rmsg_id" : int(rmsg_id)})
        

@bot_man.on_message(filters.command("hi"))
async def aa(c, m):
    if m.from_user and m.from_user.id == owner:
        await m.reply_text("hello")

@bot_man.on_message(filters.chat("@tgtowabot"))
async def aa(c, m):
    if m.document:
        file_name = (str(m.document.file_name).split(" ")[0]).strip()
        from_json = man_json.get(file_name)
        if from_json:
            await m.forward(logchat)

@bot.on_message(filters.chat(logchat))
async def aa(c, m):
    if m.document and m.from_user.id == dephendor:
        try:
            file_name = (str(m.document.file_name).split(" ")[0]).strip()
            chat = int(man_json.get(file_name))
            asyncio.sleep(2)
            await m.copy(chat, caption="")
        except Exception as e: 
            print(e)

        if_already = man_json.get(f"{file_name}_already")
        if not if_already:
            xmsg = man_json.get(f"{file_name}_x")
            await xmsg.delete()
            try:
                group = str(man_json.get(f"{file_name}_gc"))
                rmsg_id = int(man_json.get(f"{file_name}_rmsg_id"))
                if not group.startswith("-100"):
                    group = "-100" + group
                await c.send_message(int(group), "Successfully sent you sticker packs in private message.", reply_to_message_id=rmsg_id)
            except:
                pass
            print("sent to user")
            man_json.update({f"{file_name}_already" : int(rmsg_id)})
            await c.send_message(chat, f"Download this app from [App Store](https://apps.apple.com/ru/app/sticker-maker-studio/id1443326857) or [Play Store](https://play.google.com/store/apps/details?id=com.marsvard.stickermakerforwhatsapp) to transfer stickers to whatsapp.\ncheck `/how_to_add_wp_stickers` for more details.\n3edit: Ed Asriyan", disable_web_page_preview=True)


        # remove from man json

# @bot_man.on_message(filters.chat(-1001756825711))
async def _fwd(c, m):
    if m.from_user.username == botname and m.document:
       await  m.reply_text("/ukang")

@bot.on_message(filters.command("sticker_broadcast"))
async def brd(c, m):
    if m.from_user and m.from_user.id == owner:
        fmsg =await  m.reply_text("Processing ...")
        with open("sticker_users.txt", "r") as r:
            users_list = json.load(r)
        succ, failed = 0, 0
        j = 1
        for user in users_list:
            if j > 808:
                try:
                    id = int(user)
                    await m.reply_to_message.copy(id)
                    await asyncio.sleep(2)
                    succ += 1
                except:
                    failed += 1
            j += 1

        await fmsg.edit(f"Broadcast successfull.\nTotal users: {len(users_list) - 480}\nsuccess: {succ}\nfailed: {failed}")

def send_logs_sync(msg, *args):
    try:
        bot.send_message(log_channel, f"{msg} {args}", parse_mode=enums.ParseMode.DISABLED)
    finally:
        return
    
bot.start()
bot2.start()
bot_man.start()
print("started")
send_logs_sync("Bot started")
idle()
bot.stop()
bot2.stop()
bot_man.stop()
