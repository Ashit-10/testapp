import os
from pyrogram import *
from pyrogram.types import *
import json
from PIL import Image as pi_image

from utils import *

bot_token = "5214279030:AAHwXVkouOpHANC1EiK6edh_ux4cFqoZ-OY"
botname = "The_avengers_robot"
owner = 1602293216
mychat = -1001716284663
log_channel = -1001349019437
logchat = -1001756825711

api_id = 6810439 
api_hash = '66ac3b67cce1771ce129819a42efe02e'

bot = Client(
    "wa_sticker_bot",
    bot_token=bot_token,
    api_id=api_id,
    api_hash=api_hash
)

from PIL import Image as pi_image
import numpy
import cv2

async def img_transform(img_file_name, need_w):
    size = need_w
    img_cv = cv2.imread(img_file_name)
    h = img_cv.shape[0]
    w = img_cv.shape[1]
    free_dist = int((size - h) / 2)
    # print(free_dist, w, h)
    source_coords = [(0, 0), (need_w, 0), (need_w, need_w), (0, need_w)]
    target_coords = [(0,free_dist), (size,free_dist), (size, size + free_dist), (0,size + free_dist)]
    matrix = []
    for s, t in zip(source_coords, target_coords):
            matrix.append([t[0], t[1], 1, 0, 0, 0, -s[0]*t[0], -s[0]*t[1]])
            matrix.append([0, 0, 0, t[0], t[1], 1, -s[1]*t[0], -s[1]*t[1]])
    A = numpy.matrix(matrix, dtype=numpy.float32)
    B = numpy.array(source_coords).reshape(8)
    res = numpy.dot(numpy.linalg.inv(A.T * A) * A.T, B)

    img = pi_image.open(img_file_name)
    img = img.convert("RGBA")
    coeffs = numpy.array(res).reshape(8)

    new_image = img.transform((size, size), pi_image.PERSPECTIVE, coeffs,
                    pi_image.BICUBIC)

    new_image.save(img_file_name)



@bot.on_message(filters.command("wa"))
async def wa(c, m):
#        await send_logs(f"#whatsapp {user_id},  {fname}   @{username}
        user = m.from_user
        user_id = user.id
        ext = "webp"
        skip = False
        print(m.reply_to_message.sticker.mime_type)
        if "SUPERGROUP" in str(m.chat.type).upper():
          group = True
        else:
          group= False
        if not m.reply_to_message:
            await m.reply_text("Please reply to a image sticker to make whatsapp sticker pack.")
            return
        if not m.reply_to_message.sticker:
           await m.reply_text("Please reply to a sticker.")
           return
        if "webp" in m.reply_to_message.sticker.mime_type:
            ext = "webp"
        elif "tgs" in m.reply_to_message.sticker.mime_type:
             ext = "tgs"
             skip = True
        elif "webm" in m.reply_to_message.sticker.mime_type:
              ext = "webm"
        else:
             await m.reply_text("Whatsapp does not support video stickers.\nReply to a image sticker to make whatsapp sticker pack.")
             return
             
        
        fmsg = await m.reply_text("processing")
        user_id = m.from_user.id
        rmsg = m.reply_to_message
        os.system(f"rm -rf downloads/{user_id}")
        pack = rmsg.sticker.set_name
        sticker_set = await get_stkr_set(c, pack)
        all_stickers_to = [await Sticker._parse(bot, doc, {type(a): a for a in doc.attributes}) for doc in sticker_set.documents]
        file_ids_to = [s.file_id for s in all_stickers_to]

        count = len(file_ids_to)
        os.system(f"mkdir downloads/{user_id}")
        pack_title = sticker_set.set.title
        print(pack_title, count)
        # for thumbnail
        file_name = f"downloads/{user_id}/unnamed.{ext}"
        should_name = f"downloads/{user_id}/unnamed.png"
        emoji = sticker_set.documents[0].attributes[1].alt
        await c.download_media(message=file_ids_to[0], file_name=file_name)
        if ext == "tgs":
             os.system(f"lottie_convert.py {file_name} {should_name}")
        elif ext == "webm":
              os.system(f"ffmpeg -c:v libvpx-vp9 -i {file_name} {should_name}")
        else:
                photo_resize = await make_stkr_size_for_wp(should_name,(96, 96), "png")

        link = f"https://t.me/addstickers/{pack}"
        name = pack_title            
        author = "@tgtowabot"
        thumbnail = f"unnamed.{ext}"
        info = "Created by https://t.me/tgtowabot. If you have any questions or suggestions, write me at telegram: @ed_asriyan"

       
        if count > 30:
           if (count % 30) == 0:
              pack_nums = int(count/30)
           else:
                pack_nums = int(count / 30) + 1
        else:
                pack_nums = 1

        folds = []
        for packs in range(1, pack_nums+1):
                fold_name = f"downloads/{user_id}/{packs}"
                os.system(f"mkdir {fold_name}")
                folds.append(fold_name)
                os.system(f"cp downloads/{user_id}/unnamed.{ext} {fold_name}/")
                with open(f"{fold_name}/title.txt", "w+") as wr2:
                        wr2.write(f"{pack_title} pack - {packs}")
                        
        print(folds)
        stkr_json = []
        await fmsg.edit("Converting ...\nIt will take 5-10 seconds.")

        x = 0
        i = 1
        
        for lo in range(count):
                print(x)
                fname = f"{pack}_tgtowabot{i}.{ext}"
                should_name = f"{pack}_tgtowabot{i}.webp"
                try:
                        folder = folds[x]
                except:
                      break
                file_name = f"{folder}/{fname}"
                emoji = sticker_set.documents[lo].attributes[1].alt
                await c.download_media(message=file_ids_to[lo], file_name=file_name)
                if ext == "webp":
                        photo_resize = await img_transform(f"{folder}/{fname}", 512)
                elif ext == "webm":
                      os.system(f"ffmpeg -c:v libvpx-vp9 -i {folder}/{fname} {folder}/{should_name}")
                elif ext == "tgs":
                      os.system(f"lottie_convert.py {folder}/{fname} {folder}/{should_name} --webp-method 0  --webp-quality 0 --fps 30") 
                #       photo_resize = await img_transform(f"{folder}/{should_name}", 512)

                stkr_json.append({"file":fname, "emoji":emoji})

                all_files = os.listdir(folder)
                if lo == count or len(all_files) >= 32:
                        x += 1
                        i = 1
                        full_info = {"link":link,"name":name,"author":author,"thumbnail":thumbnail,"stickers":stkr_json,"info":info}
                        stkr_json = []
                        with open(f"{folder}/info.json", "w+") as wr:
                                json.dump(full_info, wr)


                i += 1
                if x > len(folds):
                        break

        
        with open(f"downloads/{user_id}/link.txt", "w+") as wr1:
                wr1.write(link)

        with open(f"downloads/{user_id}/author.txt", "w+") as wr3:
                wr3.write(author)

        p = 1
        suc = None
        for z in folds:
                os.system(f"cp downloads/{user_id}/author.txt {z}/")
                os.system(f"cp downloads/{user_id}/link.txt {z}/")
                os.system(f"cd {z} && zip -r {pack}_{p}.wastickers *")
                try: 
                    await c.send_document(user_id, f'{z}/{pack}_{p}.wastickers')
                    suc = True
                except Exception as e:
                   print(e)
                   if "BLOCKED" in str(e):
                      await m.reply_text("You have blocked me , start me .", reply_markup = start_btn)
                      break
                p += 1
        if suc:
            await c.send_message(user_id, f"Download this app from [App Store](https://apps.apple.com/ru/app/sticker-maker-studio/id1443326857) or [Play Store](https://play.google.com/store/apps/details?id=com.marsvard.stickermakerforwhatsapp) to transfer stickers to whatsapp.", disable_web_page_preview=True)       
      #  os.system(f"rm -rf downloads/{user_id}")
        if suc and group:
           await fmsg.edit("Successfully made you whatsapp sticker packs and sent you in Private message.")
        else:
           await fmsg.delete()





bot.run()
