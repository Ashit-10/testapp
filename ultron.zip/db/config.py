TELEGRAM_TOKEN = '2110447625:AAHY9-eImSdg0ofjwubFV1WEwrDvIyug_-w'

bot_id = '2114146261'

bot_username = "ina_mina_tika_bot"

my_bot_id =2110447625

