import os

TELEGRAM_TOKEN = "5042954820:AAH6KmIsSAu9TMrqDtsm7K9AXIYF0cYzFlA"
bot_id = '2114146261'
bot_username = "The_Ultron_Robot"


my_bot_id =5042954820

log_chat = -1001716284663
sudo_users = [1602293216]
